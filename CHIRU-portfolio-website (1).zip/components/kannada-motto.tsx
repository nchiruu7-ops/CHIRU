'use client'

import { useEffect, useRef } from 'react'

const breakdown = [
  {
    term: 'Svatma-Ramam',
    kannada: 'ಸ್ವಾತ್ಮಾರಾಮಂ',
    meaning:
      'One who constantly rejoices (Rama) entirely in his own innermost True Self (Svatma). He needs no external stimulation to be happy.',
  },
  {
    term: 'Nijanandam',
    kannada: 'ನಿಜಾನಂದಂ',
    meaning:
      'Existing in a state of continuous, absolute, intrinsic bliss (Sat-Chit-Ananda).',
  },
  {
    term: 'Shoka-Moha Vivarjitam',
    kannada: 'ಶೋಕಮೋಹ ವಿವರ್ಜಿತಮ್',
    meaning:
      'One who is entirely freed (Vivarjitam) from worldly attachments/illusions (Moha) and the grief (Shoka) that follows them.',
  },
  {
    term: 'Smarami Manase Nityam',
    kannada: 'ಸ್ಮರಾಮಿ ಮಾನಸೇ ನಿತ್ಯಂ',
    meaning:
      'I meditate upon and remember (Smarami) in my heart and mind (Manase) every single day (Nityam).',
  },
  {
    term: 'Sri Venkatachala Deshikam',
    kannada: 'ಶ್ರೀ ವೆಂಕಟಾಚಲ ದೇಶಿಕಮ್',
    meaning:
      'Upon the divine spiritual master (Deshika), Sri Venkatachala Avadhuta.',
  },
]

const grainUrl =
  "url(\"data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='160' height='160'><filter id='n'><feTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='3' stitchTiles='stitch'/></filter><rect width='100%' height='100%' filter='url(%23n)'/></svg>\")"

export function KannadaMotto() {
  const textRef = useRef<HTMLParagraphElement>(null)

  useEffect(() => {
    if (!textRef.current) return

    const text = textRef.current
    let animationId: number

    const animate = () => {
      const scrollY = window.scrollY
      const elementTop = text.getBoundingClientRect().top + scrollY

      if (scrollY > elementTop - window.innerHeight * 0.8) {
        const progress = Math.min(
          (scrollY - (elementTop - window.innerHeight * 0.8)) / 200,
          1
        )

        text.style.opacity = String(progress)
        text.style.transform = `
          translateY(${(1 - progress) * 40}px)
          scale(${0.95 + progress * 0.05})
          rotateX(${(1 - progress) * 10}deg)
        `

        const glowIntensity = progress * 0.8
        text.style.textShadow = `
          0 0 20px rgba(253, 224, 71, ${0.3 + glowIntensity}),
          0 0 40px rgba(253, 224, 71, ${0.2 + glowIntensity * 0.5}),
          0 0 60px rgba(239, 68, 68, ${0.1 + glowIntensity * 0.3})
        `
      }

      animationId = requestAnimationFrame(animate)
    }

    window.addEventListener('scroll', animate)
    animate()

    return () => {
      window.removeEventListener('scroll', animate)
      cancelAnimationFrame(animationId)
    }
  }, [])

  return (
    <section className="relative z-10 mx-auto max-w-7xl px-5 py-32 md:px-8 md:py-40">
      <div className="relative overflow-hidden rounded-[2rem] border border-flag-yellow/20 bg-charcoal/50 p-8 backdrop-blur-md sm:p-12 md:p-20">
        <div
          aria-hidden="true"
          className="pointer-events-none absolute -left-40 top-1/3 size-96 rounded-full bg-flag-yellow/10 blur-3xl"
        />
        <div
          aria-hidden="true"
          className="pointer-events-none absolute -right-40 bottom-0 size-96 rounded-full bg-flag-red/10 blur-3xl"
        />
        <svg
          aria-hidden="true"
          viewBox="0 0 200 200"
          fill="none"
          stroke="currentColor"
          strokeWidth="0.4"
          className="pointer-events-none absolute left-1/2 top-1/2 size-[40rem] -translate-x-1/2 -translate-y-1/2 text-flag-yellow opacity-[0.06]"
        >
          <circle cx="100" cy="100" r="96" />
          <circle cx="100" cy="100" r="74" />
          <circle cx="100" cy="100" r="48" />
          {[0, 1, 2, 3, 4, 5, 6, 7].map((i) => (
            <ellipse
              key={i}
              cx="100"
              cy="100"
              rx="92"
              ry="30"
              transform={`rotate(${i * 22.5} 100 100)`}
            />
          ))}
        </svg>
        <div
          aria-hidden="true"
          className="pointer-events-none absolute inset-0 opacity-[0.05] mix-blend-overlay"
          style={{ backgroundImage: grainUrl }}
        />

        <div className="relative">
          <div className="flex items-center justify-center gap-4">
            <span className="h-px w-12 bg-gradient-to-r from-transparent to-flag-yellow/70" />
            <span className="text-xs font-medium uppercase tracking-[0.3em] text-flag-yellow/80">
              Invocation
            </span>
            <span className="h-px w-12 bg-gradient-to-l from-transparent to-flag-yellow/70" />
          </div>

          <figure className="mx-auto mt-10 w-44 md:w-56">
            <div className="relative">
              <div className="absolute inset-0 rounded-t-full bg-flag-yellow/30 blur-2xl" />
              <div className="relative rounded-t-full rounded-b-3xl bg-gradient-to-b from-flag-yellow/70 via-flag-yellow/20 to-flag-red/70 p-[3px] shadow-[0_0_60px_-10px_rgba(253,224,71,0.35)]">
                <img
                  src="https://cdn.builder.io/api/v1/image/assets%2Fc143b621432544a187995c081e770f3f%2F681a19ed970d42f5bd9a2b945f8b5a72?format=webp&width=800&height=1200"
                  alt="Portrait of the guru, Sri Venkatachala Avadhuta"
                  loading="lazy"
                  className="aspect-[2/3] w-full rounded-t-full rounded-b-[1.4rem] object-cover"
                />
              </div>
            </div>
            <figcaption className="mt-5 text-center text-xs uppercase tracking-[0.3em] text-muted-foreground">
              SADHGURU Shri Venkatachala Avadhuta
            </figcaption>
          </figure>

          <div className="relative mx-auto mt-10 max-w-5xl rounded-3xl border border-flag-yellow/25 bg-gradient-to-b from-flag-yellow/10 via-transparent to-flag-red/10 px-6 py-12 text-center shadow-[0_0_80px_-20px_rgba(253,224,71,0.45)] sm:px-12">
            <span
              aria-hidden="true"
              className="absolute -top-px left-1/2 h-px w-1/2 -translate-x-1/2 bg-gradient-to-r from-transparent via-flag-yellow to-transparent"
            />
            <p
              ref={textRef}
              className="font-kannada text-4xl font-extrabold leading-tight text-transparent bg-clip-text bg-gradient-to-r from-flag-yellow via-flag-yellow to-flag-red sm:text-5xl lg:text-6xl"
              style={{
                perspective: '1000px',
                transformStyle: 'preserve-3d',
                opacity: 0,
                textShadow: '0 0 20px rgba(253, 224, 71, 0.3)',
                transition: 'none',
              }}
            >
              ಸ್ವಾತ್ಮಾರಾಮಂ ನಿಜಾನಂದಂ
              <br />
              ಶೋಕಮೋಹ ವಿವರ್ಜಿತಮ್ ।
              <br />
              ಸ್ಮರಾಮಿ ಮಾನಸೇ ನಿತ್ಯಂ
              <br />
              ಶ್ರೀ ವೆಂಕಟಾಚಲ ದೇಶಿಕಮ್ ॥
            </p>
            <div className="mx-auto mt-8 h-px w-40 bg-gradient-to-r from-transparent via-flag-yellow/70 to-transparent" />
            <p className="mt-8 text-base font-medium leading-relaxed text-muted-foreground md:text-lg">
              Svatmaramam Nijanandam Shoka Moha Vivarjitam |
              <br />
              Smarami Manase Nityam Venkatachala Deshikam ||
            </p>
          </div>

          <div className="mx-auto mt-20 max-w-5xl">
            <div className="text-center">
              <h3 className="text-2xl font-semibold md:text-3xl">
                Word-by-Word Spiritual Breakdown
              </h3>
              <p className="mx-auto mt-3 max-w-2xl text-sm leading-relaxed text-muted-foreground/80 md:text-base">
                Reflecting on each word of this verse brings the mind back to
                stillness and inner peace.
              </p>
            </div>

            <ol className="mt-12 grid gap-5 md:grid-cols-2">
              {breakdown.map((item, index) => (
                <li
                  key={item.term}
                  className={`group relative overflow-hidden rounded-2xl border border-border/50 bg-background/40 p-6 transition duration-300 hover:-translate-y-1 hover:border-flag-yellow/50 hover:shadow-[0_0_40px_-12px_rgba(253,224,71,0.35)] md:p-7 ${
                    index === breakdown.length - 1 ? 'md:col-span-2' : ''
                  }`}
                >
                  <div className="flex items-start gap-5">
                    <span className="flex size-11 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-flag-yellow to-flag-red text-sm font-bold text-charcoal">
                      {String(index + 1).padStart(2, '0')}
                    </span>
                    <div className="min-w-0">
                      <p className="font-kannada text-2xl font-bold text-flag-yellow">
                        {item.kannada}
                      </p>
                      <p className="mt-1 text-sm font-semibold uppercase tracking-wider text-foreground">
                        {item.term}
                      </p>
                      <p className="mt-3 text-sm leading-relaxed text-muted-foreground md:text-base">
                        {item.meaning}
                      </p>
                    </div>
                  </div>
                </li>
              ))}
            </ol>
          </div>

          <div className="mt-20 flex flex-col items-center gap-4 text-center">
            <div className="h-px w-40 bg-gradient-to-r from-transparent via-flag-red/60 to-transparent" />
            <p className="max-w-xl text-sm italic leading-relaxed text-muted-foreground md:text-base">
              Return to this verse each day, and let the mind settle into its
              own stillness.
            </p>
          </div>
        </div>
      </div>
    </section>
  )
}
