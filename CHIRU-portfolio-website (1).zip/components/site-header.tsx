'use client'

import { Menu, X } from 'lucide-react'
import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { useEffect, useRef, useState } from 'react'
import { navLinks, site } from '@/lib/site'
import { cn } from '@/lib/utils'

export function SiteHeader() {
  const pathname = usePathname()
  const [open, setOpen] = useState(false)
  const [scrolled, setScrolled] = useState(false)
  const progress = useRef<HTMLDivElement>(null)

  useEffect(() => {
    setOpen(false)
  }, [pathname])

  useEffect(() => {
    const onScroll = () => {
      const max = document.documentElement.scrollHeight - window.innerHeight
      const ratio = max > 0 ? window.scrollY / max : 0
      if (progress.current) progress.current.style.transform = `scaleX(${ratio})`
      setScrolled(window.scrollY > 12)
    }
    onScroll()
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  useEffect(() => {
    document.body.style.overflow = open ? 'hidden' : ''
    return () => {
      document.body.style.overflow = ''
    }
  }, [open])

  return (
    <header
      className={cn(
        'fixed inset-x-0 top-0 z-50 transition-colors duration-300',
        scrolled || open
          ? 'bg-charcoal/85 backdrop-blur-xl'
          : 'bg-transparent',
      )}
    >
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-5 md:h-20 md:px-8">
        <Link href="/" className="group flex items-center gap-3" aria-label={`${site.name} home`}>
          <span className="relative flex size-10 items-center justify-center overflow-hidden rounded-xl font-display text-lg font-extrabold text-charcoal transition-transform duration-300 group-hover:rotate-6">
            <span className="absolute inset-x-0 top-0 h-1/2 bg-flag-yellow" />
            <span className="absolute inset-x-0 bottom-0 h-1/2 bg-flag-red" />
            <span className="relative">C</span>
          </span>
          <span className="font-display text-2xl font-extrabold tracking-wide text-flag-gradient">
            {site.name}
          </span>
        </Link>

        <nav aria-label="Primary" className="hidden items-center gap-1 lg:flex">
          {navLinks.map((link) => {
            const active =
              link.href === '/' ? pathname === '/' : pathname.startsWith(link.href)
            return (
              <Link
                key={link.href}
                href={link.href}
                aria-current={active ? 'page' : undefined}
                className={cn(
                  'relative rounded-full px-4 py-2 text-sm font-medium transition-colors',
                  active
                    ? 'text-charcoal'
                    : 'text-muted-foreground hover:text-foreground',
                )}
              >
                {active && (
                  <span className="absolute inset-0 -z-10 rounded-full bg-gradient-to-b from-flag-yellow to-[#f08a1c]" />
                )}
                {link.label}
              </Link>
            )
          })}
        </nav>

        <button
          type="button"
          onClick={() => setOpen((v) => !v)}
          aria-expanded={open}
          aria-controls="mobile-nav"
          aria-label={open ? 'Close menu' : 'Open menu'}
          className="flex size-11 items-center justify-center rounded-full border border-border bg-card/60 lg:hidden"
        >
          {open ? <X className="size-5" /> : <Menu className="size-5" />}
        </button>
      </div>

      <div
        id="mobile-nav"
        className={cn(
          'grid overflow-hidden transition-[grid-template-rows] duration-300 lg:hidden',
          open ? 'grid-rows-[1fr]' : 'grid-rows-[0fr]',
        )}
      >
        <nav
          aria-label="Mobile"
          className="min-h-0 overflow-hidden"
          inert={!open}
        >
          <ul className="flex flex-col gap-1 px-5 pb-6 pt-2">
            {navLinks.map((link, i) => {
              const active =
                link.href === '/' ? pathname === '/' : pathname.startsWith(link.href)
              return (
                <li key={link.href}>
                  <Link
                    href={link.href}
                    aria-current={active ? 'page' : undefined}
                    style={{ transitionDelay: open ? `${i * 40}ms` : '0ms' }}
                    className={cn(
                      'flex items-center justify-between rounded-2xl px-4 py-3.5 font-display text-2xl font-bold transition-all',
                      open ? 'translate-x-0 opacity-100' : '-translate-x-4 opacity-0',
                      active ? 'bg-flag-yellow text-charcoal' : 'hover:bg-card',
                    )}
                  >
                    {link.label}
                    <span className="text-sm font-medium opacity-60">
                      0{i + 1}
                    </span>
                  </Link>
                </li>
              )
            })}
          </ul>
        </nav>
      </div>

      <div className="h-[3px] w-full bg-white/5">
        <div
          ref={progress}
          className="h-full origin-left bg-gradient-to-r from-flag-yellow via-flag-yellow to-flag-red will-change-transform"
          style={{ transform: 'scaleX(0)' }}
        />
      </div>
    </header>
  )
}
