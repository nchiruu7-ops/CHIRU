import { ArrowUpRight, Clapperboard, Users } from 'lucide-react'
import { Reveal } from '@/components/reveal'
import { TiltCard } from '@/components/tilt-card'
import { teamWork } from '@/lib/site'

export function TeamWork() {
  return (
    <section
      id="team-work"
      aria-labelledby="team-heading"
      className="relative z-10 mx-auto max-w-7xl px-5 py-20 md:px-8 md:py-28"
    >
      <Reveal>
        <p className="mb-4 inline-flex items-center gap-2 text-sm font-semibold uppercase tracking-[0.2em] text-flag-yellow">
          <Users className="size-4" /> in hand experience
        </p>
        <h2
          id="team-heading"
          className="max-w-3xl font-display text-4xl font-extrabold leading-tight tracking-tight text-balance md:text-6xl"
        >
          I was part of the <span className="text-flag-gradient">AI animation</span>&nbsp;team
        </h2>
        <div className="mt-5 max-w-2xl space-y-6">
          <p className="text-lg leading-relaxed text-muted-foreground">
            Served as a core AI Animator within a collaborative, fast-paced production team, contributing to the videos published on [Channel Name 1] and [Channel Name 2]. Because our content is the result of a collective team effort, individual video credits are shared globally through the channels themselves.
          </p>
          <div>
            <p className="text-sm font-semibold uppercase tracking-[0.2em] text-flag-yellow">
              Key Contributions:
            </p>
            <ul className="mt-3 space-y-3 text-lg leading-relaxed text-muted-foreground">
              <li className="flex gap-3">
                <span aria-hidden="true" className="mt-3 size-1.5 shrink-0 rounded-full bg-flag-yellow" />
                <span>Utilized cutting-edge AI animation tools to generate, refine, and animate visual assets based on team scripts and storyboard&apos;s.</span>
              </li>
              <li className="flex gap-3">
                <span aria-hidden="true" className="mt-3 size-1.5 shrink-0 rounded-full bg-flag-yellow" />
                <span>Partnered closely with editors, sound designers, and directors to maintain visual consistency and meet strict publishing schedule&apos;s.</span>
              </li>
              <li className="flex gap-3">
                <span aria-hidden="true" className="mt-3 size-1.5 shrink-0 rounded-full bg-flag-yellow" />
                <span>Streamlined the animation pipeline to help the team scale video output without sacrificing creative quality.</span>
              </li>
            </ul>
          </div>
        </div>
      </Reveal>

      <p className="mt-8 max-w-2xl text-lg leading-relaxed text-muted-foreground">
        Discover the AI-animated stories I previously co-created as part of the team. Watch the videos and subscribe to the channels below to support their creative journey!
      </p>

      <ul className="mt-8 grid gap-6 md:grid-cols-2">
        {teamWork.channels.map((c, i) => (
          <li key={c.handle}>
            <Reveal delay={i * 120} className="h-full">
              <TiltCard className="h-full rounded-[2rem]" max={6}>
                <a
                  href={c.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="group relative flex h-full flex-col overflow-hidden rounded-[2rem] border border-border bg-card p-8"
                >
                  <span
                    aria-hidden="true"
                    className="absolute inset-x-0 top-0 h-1.5 bg-flag-stripe"
                  />
                  <span
                    aria-hidden="true"
                    className="absolute -right-10 -top-10 size-40 rounded-full bg-flag-yellow/10 blur-2xl transition-colors group-hover:bg-flag-red/20"
                  />
                  <span className="flex size-14 items-center justify-center rounded-2xl bg-gradient-to-b from-flag-yellow to-flag-red text-charcoal">
                    <Clapperboard className="size-7" />
                  </span>
                  <h3 className="mt-6 font-display text-3xl font-extrabold">{c.name}</h3>
                  <p className="text-sm font-medium text-flag-yellow">{c.handle}</p>
                  <p className="mt-4 flex-1 leading-relaxed text-muted-foreground">{c.blurb}</p>
                  <p className="mt-5 inline-block w-fit rounded-full bg-flag-red/15 px-3 py-1 text-xs font-semibold text-[#ff8a8a]">
                    My role: {teamWork.role}
                  </p>
                  <span className="mt-6 inline-flex items-center gap-2 text-sm font-semibold">
                    Visit the channel-01 on YouTube
                    <ArrowUpRight className="size-4 transition-transform group-hover:-translate-y-0.5 group-hover:translate-x-0.5" />
                  </span>
                </a>
              </TiltCard>
            </Reveal>
          </li>
        ))}
      </ul>

      <Reveal delay={200}>
        <p className="mt-8 rounded-2xl border border-dashed border-border px-5 py-4 text-sm leading-relaxed text-muted-foreground">
          More episodes are planned on the team&apos;s release calendar. Unpublished work is not
          shown here, out of respect for the team and its schedule.&nbsp;I invite you to explore the official channels below to see the animated content our production team creates. If you enjoy the visual storytelling and high-quality AI animation, please consider watching our latest videos and subscribing to stay updated on our upcoming releases. Your support drives our creative journey!
        </p>
      </Reveal>
    </section>
  )
}
