'use client'

import { Check, Copy, Mail, MessageCircle, Send } from 'lucide-react'
import Link from 'next/link'
import { useId, useState } from 'react'
import { site, socials } from '@/lib/site'
import { cn } from '@/lib/utils'

const services = [
  'Online printing',
  'Design & DTP',
  'Poster design',
  'AI content',
  'Motion graphics',
  'Brand identity',
  'Creative product promotion',
  'Brand promotion',
  'Brand strategy',
  'Something else',
]
const deadlines = ['As soon as possible', 'This week', 'This month', 'Flexible']

function Chip({
  active,
  onClick,
  children,
}: {
  active: boolean
  onClick: () => void
  children: React.ReactNode
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-pressed={active}
      className={cn(
        'rounded-full border px-4 py-2.5 text-sm font-medium transition-all active:scale-95',
        active
          ? 'border-flag-yellow bg-flag-yellow text-charcoal'
          : 'border-border bg-charcoal hover:border-flag-yellow/60',
      )}
    >
      {children}
    </button>
  )
}

export function ContactForm({
  initialProject,
  initialService,
}: {
  initialProject?: { title: string }
  initialService?: string
}) {
  const uid = useId()
  const [picked, setPicked] = useState<string[]>(() =>
    initialService && services.includes(initialService) ? [initialService] : [],
  )
  const [deadline, setDeadline] = useState(deadlines[3])
  const [name, setName] = useState('')
  const [reach, setReach] = useState('')
  const [message, setMessage] = useState(
    initialProject ? `I'm interested in a project like "${initialProject.title}".\n\n` : '',
  )
  const [privacyAcknowledged, setPrivacyAcknowledged] = useState(false)
  const [tried, setTried] = useState(false)
  const [copied, setCopied] = useState(false)
  const [status, setStatus] = useState<'idle' | 'sending' | 'sent' | 'error'>('idle')
  const [errorMessage, setErrorMessage] = useState('')
  const [delivery, setDelivery] = useState<{ saved: boolean; adminNotified: boolean; confirmationSent: boolean } | null>(null)

  const contactText = reach.trim()
  const contactDigits = contactText.replace(/\D/g, '')
  const validContact = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(contactText) ||
    (/^\+?[\d\s().-]+$/.test(contactText) && contactDigits.length >= 7 && contactDigits.length <= 15)
  const errors = {
    name: name.trim() ? '' : 'Please tell me your name.',
    reach: validContact ? '' : 'Enter a valid email address or phone number.',
    message: message.trim().length >= 10 ? '' : 'Write a little about what you need.',
    privacy: privacyAcknowledged ? '' : 'Please acknowledge the privacy notice.',
  }
  const valid = !errors.name && !errors.reach && !errors.message && !errors.privacy

  const brief = [
    `Hi CHIRU, I'm ${name.trim() || '[your name]'}.`,
    picked.length ? `I need: ${picked.join(', ')}.` : '',
    message.trim() || '[Tell me about your project]',
    `Deadline: ${deadline}.`,
    `Reach me at: ${reach.trim() || '[email or phone]'}`,
  ]
    .filter(Boolean)
    .join('\n\n')

  const whatsapp = socials.whatsapp
    ? `https://wa.me/${socials.whatsapp}?text=${encodeURIComponent(brief)}`
    : ''
  const emailHref = `mailto:${site.email}?subject=${encodeURIComponent(`Project enquiry from ${name.trim() || 'website visitor'}`)}&body=${encodeURIComponent(brief)}`

  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault()
    if (!valid) {
      setTried(true)
      return
    }
    setStatus('sending')
    setErrorMessage('')
    try {
      const res = await fetch('/api/enquiry', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: name.trim(),
          contact: reach.trim(),
          message: message.trim(),
          services: picked,
          deadline,
          privacyAcknowledged,
        }),
      })
      const data: { saved?: boolean; adminNotified?: boolean; confirmationSent?: boolean; error?: string } = await res.json()
      if (!res.ok) throw new Error(data.error || 'The enquiry could not be saved.')
      setDelivery({
        saved: Boolean(data.saved),
        adminNotified: Boolean(data.adminNotified),
        confirmationSent: Boolean(data.confirmationSent),
      })
      setStatus('sent')
    } catch (error) {
      setErrorMessage(error instanceof Error ? error.message : 'The enquiry could not be saved.')
      setStatus('error')
    }
  }

  function guard(e: React.MouseEvent) {
    if (!valid) {
      e.preventDefault()
      setTried(true)
    }
  }

  async function copy() {
    if (!valid) {
      setTried(true)
      return
    }
    try {
      await navigator.clipboard.writeText(brief)
      setCopied(true)
      window.setTimeout(() => setCopied(false), 2000)
    } catch {
      setCopied(false)
    }
  }

  const field =
    'mt-2 w-full rounded-2xl border border-border bg-charcoal px-4 py-3.5 text-base outline-none transition-colors placeholder:text-muted-foreground/70 focus:border-flag-yellow'

  return (
    <div className="grid gap-6 xl:grid-cols-[1.2fr_1fr]">
      <form
        id={`${uid}-form`}
        noValidate
        onSubmit={submit}
        className="space-y-7 rounded-3xl border border-border bg-card p-6 md:p-8"
      >
        <fieldset>
          <legend className="font-display text-lg font-bold">1. What do you need?</legend>
          <div className="mt-3 flex flex-wrap gap-2">
            {services.map((s) => (
              <Chip
                key={s}
                active={picked.includes(s)}
                onClick={() =>
                  setPicked((p) => (p.includes(s) ? p.filter((x) => x !== s) : [...p, s]))
                }
              >
                {s}
              </Chip>
            ))}
          </div>
        </fieldset>

        <fieldset>
          <legend className="font-display text-lg font-bold">2. When do you need it?</legend>
          <div className="mt-3 flex flex-wrap gap-2">
            {deadlines.map((d) => (
              <Chip key={d} active={deadline === d} onClick={() => setDeadline(d)}>
                {d}
              </Chip>
            ))}
          </div>
        </fieldset>

        <div>
          <p className="font-display text-lg font-bold">3. About you</p>
          <div className="mt-3 grid gap-4 sm:grid-cols-2">
            <div>
              <label htmlFor={`${uid}-name`} className="text-sm text-muted-foreground">
                Your name
              </label>
              <input
                id={`${uid}-name`}
                value={name}
                onChange={(e) => setName(e.target.value)}
                autoComplete="name"
                aria-invalid={tried && !!errors.name}
                aria-describedby={tried && errors.name ? `${uid}-name-e` : undefined}
                className={field}
                placeholder="Your name"
              />
              {tried && errors.name && (
                <p id={`${uid}-name-e`} className="mt-1.5 text-sm text-[#ff8a8a]">
                  {errors.name}
                </p>
              )}
            </div>
            <div>
              <label htmlFor={`${uid}-reach`} className="text-sm text-muted-foreground">
                Email or phone
              </label>
              <input
                id={`${uid}-reach`}
                value={reach}
                onChange={(e) => setReach(e.target.value)}
                autoComplete="email"
                aria-invalid={tried && !!errors.reach}
                aria-describedby={tried && errors.reach ? `${uid}-reach-e` : undefined}
                className={field}
                placeholder="you@example.com or +91 7204868185"
              />
              {tried && errors.reach && (
                <p id={`${uid}-reach-e`} className="mt-1.5 text-sm text-[#ff8a8a]">
                  {errors.reach}
                </p>
              )}
            </div>
          </div>
          <div className="mt-4">
            <label htmlFor={`${uid}-msg`} className="text-sm text-muted-foreground">
              Tell me about the project
            </label>
            <textarea
              id={`${uid}-msg`}
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              rows={5}
              aria-invalid={tried && !!errors.message}
              aria-describedby={tried && errors.message ? `${uid}-msg-e` : undefined}
              className={cn(field, 'resize-y')}
              placeholder="Sizes, quantity, style, references..."
            />
            {tried && errors.message && (
              <p id={`${uid}-msg-e`} className="mt-1.5 text-sm text-[#ff8a8a]">
                {errors.message}
              </p>
            )}
          </div>
          <label className="flex items-start gap-3 text-sm leading-relaxed text-muted-foreground">
            <input
              type="checkbox"
              checked={privacyAcknowledged}
              onChange={(event) => setPrivacyAcknowledged(event.target.checked)}
              aria-invalid={tried && !!errors.privacy}
              aria-describedby={tried && errors.privacy ? `${uid}-privacy-e` : undefined}
              className="mt-1 size-4 shrink-0 accent-[#ffc20e]"
            />
            <span>I understand my details will be used to respond to this enquiry as described in the <Link href="/privacy" className="text-flag-yellow underline">Privacy Notice</Link>.</span>
          </label>
          {tried && errors.privacy && <p id={`${uid}-privacy-e`} className="-mt-5 text-sm text-[#ff8a8a]">{errors.privacy}</p>}
        </div>
      </form>

      <aside className="flex flex-col gap-5 rounded-3xl border border-border bg-card p-6 md:p-8 xl:sticky xl:top-28 xl:self-start">
        <p className="font-display text-lg font-bold">Your message preview</p>
        <div
          aria-live="polite"
          className="rounded-3xl rounded-bl-md bg-gradient-to-br from-flag-yellow/90 to-[#f08a1c] p-5 text-sm leading-relaxed text-charcoal"
        >
          <p className="whitespace-pre-line">{brief}</p>
        </div>

        <div className="mt-auto flex flex-col gap-3">
          {status === 'sent' && (
            <p role="status" className="text-sm font-semibold text-flag-yellow">
              {delivery?.saved ? 'Thank you! Your enquiry has been recorded.' : 'Your enquiry was sent to CHIRU by email.'}
              {delivery?.adminNotified && delivery.saved && ' CHIRU has also been notified by email.'}
              {delivery?.saved && !delivery.adminNotified && ' CHIRU was not emailed; use the direct WhatsApp or email options below.'}
              {delivery?.confirmationSent && reach.includes('@') && ` A confirmation has been sent to ${reach.trim()}.`}
            </p>
          )}
          {status === 'error' && (
            <p role="alert" className="text-sm text-[#ff8a8a]">
              {errorMessage} Use WhatsApp or email below to keep a direct copy.
            </p>
          )}
          <button
            type="submit"
            form={`${uid}-form`}
            disabled={status === 'sending'}
            className="inline-flex items-center justify-center gap-2 rounded-full bg-gradient-to-b from-flag-yellow to-[#f08a1c] px-6 py-4 font-semibold text-charcoal transition-transform hover:-translate-y-0.5 disabled:pointer-events-none disabled:opacity-60"
          >
            <Send className="size-4" />
            {status === 'sending' ? 'Sending...' : 'Send enquiry'}
          </button>
          {whatsapp && (
            <a
              href={whatsapp}
              target="_blank"
              rel="noopener noreferrer"
              onClick={guard}
              className="inline-flex items-center justify-center gap-2 rounded-full border border-border px-6 py-4 font-semibold transition-colors hover:border-flag-yellow"
            >
              <MessageCircle className="size-4" />
              Continue in WhatsApp
            </a>
          )}
          <a
            href={emailHref}
            onClick={guard}
            className="inline-flex items-center justify-center gap-2 rounded-full border border-border px-6 py-4 font-semibold transition-colors hover:border-flag-yellow"
          >
            <Mail className="size-4" />
            Continue in email
          </a>
          <button
            type="button"
            onClick={copy}
            className="inline-flex items-center justify-center gap-2 rounded-full border border-border px-6 py-4 font-semibold transition-colors hover:border-flag-yellow"
          >
            {copied ? <Check className="size-4 text-flag-yellow" /> : <Copy className="size-4" />}
            {copied ? 'Copied' : 'Copy message'}
          </button>
          <p className="flex items-start gap-2 text-xs text-muted-foreground">
            <Mail className="mt-0.5 size-3.5 shrink-0" />
            Your enquiry is recorded. Add a valid email address if you would also like an automatic receipt.
          </p>
        </div>
      </aside>
    </div>
  )
}
