'use client'

import { Canvas, useFrame, useThree } from '@react-three/fiber'
import { useMemo, useRef } from 'react'
import * as THREE from 'three'

const W = 6
const H = 3.6
const SEG_X = 64
const SEG_Y = 38

function makeFlagTexture() {
  const c = document.createElement('canvas')
  c.width = 1024
  c.height = 614
  const g = c.getContext('2d')!
  g.fillStyle = '#FFC20E'
  g.fillRect(0, 0, 1024, 307)
  g.fillStyle = '#D62828'
  g.fillRect(0, 307, 1024, 307)
  g.globalAlpha = 0.07
  g.fillStyle = '#000'
  for (let y = 0; y < 614; y += 3) g.fillRect(0, y, 1024, 1)
  for (let x = 0; x < 1024; x += 3) g.fillRect(x, 0, 1, 614)
  g.globalAlpha = 1
  const t = new THREE.CanvasTexture(c)
  t.colorSpace = THREE.SRGBColorSpace
  t.anisotropy = 8
  return t
}

function Flag({ wind, backdrop }: { wind: React.RefObject<number>; backdrop: boolean }) {
  const group = useRef<THREE.Group>(null)
  const gust = useRef(0)
  const pointerSpeed = useRef(0)
  const prev = useRef({ x: 0, y: 0 })

  const reduced = useMemo(
    () => window.matchMedia('(prefers-reduced-motion: reduce)').matches,
    [],
  )
  const geometry = useMemo(() => new THREE.PlaneGeometry(W, H, SEG_X, SEG_Y), [])
  const base = useMemo(
    () => Float32Array.from(geometry.attributes.position.array as Float32Array),
    [geometry],
  )
  const texture = useMemo(() => makeFlagTexture(), [])

  const viewport = useThree((s) => s.viewport)
  const fit = backdrop
    ? Math.max(viewport.width / W, viewport.height / H) * 1.05
    : Math.min(1, (viewport.width * 0.82) / (W + 0.4), (viewport.height * 0.66) / H)

  useFrame(({ clock, pointer }) => {
    const t = clock.elapsedTime
    const moved = Math.hypot(pointer.x - prev.current.x, pointer.y - prev.current.y)
    prev.current = { x: pointer.x, y: pointer.y }
    pointerSpeed.current += (Math.min(1, moved * 10) - pointerSpeed.current) * 0.08
    gust.current *= 0.965

    const strength =
      (0.55 + wind.current * 1.1 + pointerSpeed.current * 0.7 + gust.current * 1.3) *
      (reduced ? 0.25 : 1)

    const pos = geometry.attributes.position as THREE.BufferAttribute
    for (let i = 0; i < pos.count; i++) {
      const x = base[i * 3]
      const y = base[i * 3 + 1]
      const u = (x + W / 2) / W
      const a = Math.pow(u, 1.15) * strength
      const phase = x * 1.5 - t * 3.2 + y * 0.5
      const z =
        a *
        (Math.sin(phase) * 0.32 +
          Math.sin(x * 3.2 - t * 5 + y * 1.1) * 0.1 +
          Math.sin(x * 6.8 - t * 8.4 + y * 2.6) * 0.035 +
          Math.sin(y * 2.3 + t * 2.1) * 0.06)
      pos.setXYZ(i, x, y - Math.sin(phase) * 0.03 * a, z)
    }
    pos.needsUpdate = true
    geometry.computeVertexNormals()

    if (group.current) {
      group.current.rotation.y += (-0.28 + pointer.x * 0.4 - group.current.rotation.y) * 0.06
      group.current.rotation.x += (-pointer.y * 0.16 - group.current.rotation.x) * 0.06
    }
  })

  return (
    <group ref={group} position={[0.2, -0.2, 0]} scale={fit}>
      <mesh
        geometry={geometry}
        onPointerDown={() => {
          gust.current = 1
        }}
      >
        <meshStandardMaterial
          map={texture}
          side={THREE.DoubleSide}
          roughness={0.75}
          metalness={0.04}
        />
      </mesh>
      {!backdrop && (
        <>
          <mesh position={[-W / 2 - 0.05, -0.6, 0]}>
            <cylinderGeometry args={[0.055, 0.055, 5.4, 20]} />
            <meshStandardMaterial color="#d8d8dc" metalness={0.85} roughness={0.25} />
          </mesh>
          <mesh position={[-W / 2 - 0.05, 2.18, 0]}>
            <sphereGeometry args={[0.13, 24, 24]} />
            <meshStandardMaterial color="#ffc20e" metalness={0.9} roughness={0.2} />
          </mesh>
        </>
      )}
    </group>
  )
}

export default function FlagCanvas({
  wind,
  backdrop = false,
}: {
  wind: React.RefObject<number>
  backdrop?: boolean
}) {
  return (
    <Canvas
      flat
      dpr={[1, 2]}
      camera={{ position: [0, 0, 9.8], fov: 36 }}
      gl={{ alpha: true, antialias: true }}
      aria-label={
        backdrop
          ? undefined
          : 'Interactive 3D waving Karnataka flag. Move your pointer or click the flag to stir the wind.'
      }
    >
      <ambientLight intensity={1.05} />
      <directionalLight position={[4, 3, 6]} intensity={2.2} />
      <directionalLight position={[-6, -2, 3]} intensity={0.55} color="#ffb4a0" />
      <Flag wind={wind} backdrop={backdrop} />
    </Canvas>
  )
}
