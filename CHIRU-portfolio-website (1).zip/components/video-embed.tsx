'use client'

import { Play } from 'lucide-react'
import { useState } from 'react'
import { LiveScene } from '@/components/live-scene'
import type { LiveSceneVariant } from '@/lib/scenes'
import { getYouTubeId } from '@/lib/youtube'

export function VideoEmbed({
  url,
  title,
  poster,
  sceneVariant,
  autoPlay = false,
}: {
  url?: string
  title: string
  poster?: string
  sceneVariant: LiveSceneVariant
  autoPlay?: boolean
}) {
  const id = getYouTubeId(url ?? '')
  const [playing, setPlaying] = useState(autoPlay)

  if (url && !id && url.startsWith('/')) {
    return (
      <video
        src={url}
        poster={poster}
        controls
        playsInline
        preload="metadata"
        aria-label={title}
        className="aspect-[4/5] w-full rounded-2xl bg-black object-contain"
      />
    )
  }

  if (!id) {
    return (
      <LiveScene
        variant={sceneVariant}
        label={`${title} live 3D scene`}
        poster={poster}
        className="aspect-[4/5] w-full rounded-2xl"
      />
    )
  }

  return (
    <div className="relative aspect-video w-full overflow-hidden rounded-2xl bg-black">
      {playing ? (
        <iframe
          src={`https://www.youtube-nocookie.com/embed/${id}?autoplay=1&rel=0`}
          title={title}
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
          allowFullScreen
          className="absolute inset-0 size-full"
        />
      ) : (
        <button
          type="button"
          onClick={() => setPlaying(true)}
          aria-label={`Play video: ${title}`}
          className="group absolute inset-0 size-full"
        >
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src={`https://i.ytimg.com/vi/${id}/hqdefault.jpg`}
            alt=""
            loading="lazy"
            className="size-full object-cover transition-transform duration-500 group-hover:scale-105"
          />
          <span className="absolute inset-0 bg-black/30 transition-colors group-hover:bg-black/10" />
          <span className="absolute left-1/2 top-1/2 flex size-16 -translate-x-1/2 -translate-y-1/2 items-center justify-center rounded-full bg-flag-red text-white shadow-xl transition-transform group-hover:scale-110">
            <Play className="size-7 translate-x-0.5 fill-current" />
          </span>
        </button>
      )}
    </div>
  )
}
