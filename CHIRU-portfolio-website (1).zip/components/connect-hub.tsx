import { Camera, Mail, MessageCircle, Play, Printer, type LucideIcon } from 'lucide-react'
import Link from 'next/link'
import { Reveal } from '@/components/reveal'
import { featuredReel, site, teamWork } from '@/lib/site'

interface HubNode {
  label: string
  href: string
  icon: LucideIcon
  external?: boolean
}

const nodes: HubNode[] = [
  { label: 'Instagram reel', href: featuredReel.url, icon: Camera, external: true },
  { label: 'Email', href: `mailto:${site.email}`, icon: Mail, external: true },
  { label: 'Send a brief', href: '/contact', icon: MessageCircle },
  { label: 'Print & DTP', href: '/services', icon: Printer },
]

const nodeClass =
  'flex w-[84px] flex-col items-center gap-1 rounded-2xl border border-border bg-card/90 px-2 py-3 text-center text-[11px] font-semibold leading-tight shadow-lg backdrop-blur transition-all hover:scale-110 hover:border-flag-yellow hover:text-flag-yellow'

function NodeLink({ node }: { node: HubNode }) {
  const body = (
    <>
      <node.icon className="size-5 text-flag-yellow" />
      {node.label}
    </>
  )
  return node.external ? (
    <a
      href={node.href}
      className={nodeClass}
      {...(node.href.startsWith('http') && { target: '_blank', rel: 'noopener noreferrer' })}
    >
      {body}
    </a>
  ) : (
    <Link href={node.href} className={nodeClass}>
      {body}
    </Link>
  )
}

export function ConnectHub() {
  return (
    <section
      id="connect"
      aria-labelledby="connect-heading"
      className="relative z-10 mx-auto max-w-7xl overflow-hidden px-5 py-20 md:px-8 md:py-28"
    >
      <div className="grid items-center gap-14 lg:grid-cols-2">
        <Reveal>
          <p className="mb-4 text-sm font-semibold uppercase tracking-[0.2em] text-flag-yellow">
            Digital media connections
          </p>
          <h2
            id="connect-heading"
            className="max-w-xl font-display text-4xl font-extrabold leading-tight tracking-tight text-balance md:text-6xl"
          >
            Every channel, <span className="text-flag-gradient">one conversation</span>
          </h2>
          <p className="mt-5 max-w-lg text-lg leading-relaxed text-muted-foreground">
            From YouTube animation and Instagram reels to posters, brochures and print jobs,
            everything I make connects back to one place. Pick any node and reach me the
            easiest way.
          </p>
          <ul className="mt-8 space-y-3 text-sm">
            {[
              'Describe your idea in the brief builder and send it by email in one tap.',
              'Digital and print deliverables from the same designer, so the look stays consistent.',
              'Share references, sizes and deadlines up front for fewer revisions.',
            ].map((t) => (
              <li key={t} className="flex gap-3">
                <span className="mt-1.5 size-2 shrink-0 rotate-45 bg-flag-red" />
                {t}
              </li>
            ))}
          </ul>
          <Link
            href="/contact"
            className="mt-8 inline-flex items-center gap-2 rounded-full bg-gradient-to-b from-flag-yellow to-[#f08a1c] px-7 py-3.5 font-semibold text-charcoal transition-transform hover:-translate-y-0.5"
          >
            <MessageCircle className="size-4" />
            Start a conversation
          </Link>
        </Reveal>

        <Reveal delay={150}>
          <div
            className="orbit relative mx-auto aspect-square"
            style={{
              width: 'min(88vw, 520px)',
              ['--r' as string]: 'calc(min(88vw, 520px) * 0.36)',
            }}
          >
            <span
              aria-hidden="true"
              className="absolute left-1/2 top-1/2 aspect-square -translate-x-1/2 -translate-y-1/2 rounded-full border border-dashed border-flag-yellow/30"
              style={{ width: 'calc(var(--r) * 2)' }}
            />
            <span
              aria-hidden="true"
              className="absolute left-1/2 top-1/2 aspect-square w-[96%] -translate-x-1/2 -translate-y-1/2 rounded-full border border-border"
            />

            <div className="absolute left-1/2 top-1/2 flex size-[30%] -translate-x-1/2 -translate-y-1/2 items-center justify-center overflow-hidden rounded-full shadow-[0_0_80px_-10px_rgba(255,194,14,0.6)]">
              <span className="absolute inset-x-0 top-0 h-1/2 bg-flag-yellow" />
              <span className="absolute inset-x-0 bottom-0 h-1/2 bg-flag-red" />
              <span className="relative font-display text-2xl font-extrabold text-charcoal sm:text-3xl">
                {site.name}
              </span>
            </div>

            <div className="orbit-spin absolute inset-0 animate-orbit">
              {nodes.map((n, i) => {
                const angle = (360 / nodes.length) * i
                return (
                  <div
                    key={n.label}
                    className="absolute left-1/2 top-1/2"
                    style={{
                      transform: `translate(-50%, -50%) rotate(${angle}deg) translateY(calc(var(--r) * -1)) rotate(${-angle}deg)`,
                    }}
                  >
                    <div className="orbit-counter animate-orbit-reverse">
                      <NodeLink node={n} />
                    </div>
                  </div>
                )
              })}
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  )
}
