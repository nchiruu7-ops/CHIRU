'use client'

import { Analytics } from '@vercel/analytics/next'
import Link from 'next/link'
import { useEffect, useState } from 'react'

const STORAGE_KEY = 'chiru-analytics-consent'
const OPEN_EVENT = 'chiru:open-privacy-choices'

type Consent = 'accepted' | 'rejected' | null

export function PrivacyChoicesButton() {
  const [hydrated, setHydrated] = useState(false)

  useEffect(() => setHydrated(true), [])

  if (!hydrated) return <span aria-hidden="true" className="block min-h-12" />

  return (
    <button type="button" onClick={() => window.dispatchEvent(new Event(OPEN_EVENT))} className="rounded-full bg-flag-yellow px-6 py-3 font-semibold text-charcoal">
      Manage privacy choices
    </button>
  )
}

export function AnalyticsConsent() {
  const [consent, setConsent] = useState<Consent>(null)
  const [ready, setReady] = useState(false)
  const [open, setOpen] = useState(false)

  useEffect(() => {
    try {
      const saved = window.localStorage.getItem(STORAGE_KEY)
      setConsent(saved === 'accepted' || saved === 'rejected' ? saved : null)
    } catch {
      setConsent(null)
    }
    setReady(true)
    const show = () => setOpen(true)
    window.addEventListener(OPEN_EVENT, show)
    return () => window.removeEventListener(OPEN_EVENT, show)
  }, [])

  function choose(value: Exclude<Consent, null>) {
    try {
      window.localStorage.setItem(STORAGE_KEY, value)
    } catch {
      setConsent(value)
      setOpen(false)
      return
    }
    setConsent(value)
    setOpen(false)
  }

  return (
    <>
      {ready && consent === 'accepted' && <Analytics />}
      {ready && (open || consent === null) && (
        <aside
          aria-labelledby="privacy-choice-title"
          aria-describedby="privacy-choice-copy"
          role="region"
          className="fixed inset-x-4 bottom-4 z-[70] mx-auto max-w-xl rounded-3xl border border-border bg-charcoal-2 p-5 shadow-2xl md:inset-x-auto md:right-6 md:p-6"
        >
          <h2 id="privacy-choice-title" className="font-display text-lg font-bold">Privacy choices</h2>
          <p id="privacy-choice-copy" className="mt-2 text-sm leading-relaxed text-muted-foreground">
            Optional, privacy-focused visit analytics are off unless you allow them. External Instagram or YouTube content loads only after you choose to play it. Read the <Link href="/privacy" className="text-flag-yellow underline">privacy notice</Link> or <Link href="/cookies" className="text-flag-yellow underline">cookie details</Link>.
          </p>
          <div className="mt-4 flex flex-wrap gap-2">
            <button type="button" onClick={() => choose('accepted')} className="rounded-full bg-flag-yellow px-5 py-2.5 text-sm font-semibold text-charcoal">Allow analytics</button>
            <button type="button" onClick={() => choose('rejected')} className="rounded-full border border-border px-5 py-2.5 text-sm font-semibold">Decline analytics</button>
            {consent && <button type="button" onClick={() => setOpen(false)} className="rounded-full px-4 py-2.5 text-sm text-muted-foreground">Close</button>}
          </div>
        </aside>
      )}
      {ready && consent !== null && !open && (
        <button type="button" onClick={() => setOpen(true)} className="fixed bottom-4 left-4 z-[60] rounded-full border border-border bg-charcoal/90 px-4 py-2 text-xs text-muted-foreground shadow-lg backdrop-blur hover:text-foreground">
          Privacy choices
        </button>
      )}
    </>
  )
}
