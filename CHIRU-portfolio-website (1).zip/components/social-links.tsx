import { Briefcase, Mail, MessageCircle, type LucideIcon } from 'lucide-react'
import { site, socials } from '@/lib/site'

interface LinkItem {
  label: string
  href: string
  icon: LucideIcon
}

const items: LinkItem[] = [
  { label: 'Email', href: `mailto:${site.email}`, icon: Mail },
  {
    label: 'WhatsApp',
    href: socials.whatsapp ? `https://wa.me/${socials.whatsapp}` : '',
    icon: MessageCircle,
  },
  { label: 'LinkedIn', href: socials.linkedin, icon: Briefcase },
].filter((i) => i.href)

export function SocialLinks() {
  return (
    <ul className="flex flex-wrap gap-3">
      {items.map((i) => (
        <li key={i.label}>
          <a
            href={i.href}
            {...(i.href.startsWith('http') && { target: '_blank', rel: 'noopener noreferrer' })}
            className="group inline-flex items-center gap-2.5 rounded-full border border-border bg-card px-5 py-3 text-sm font-medium transition-all hover:-translate-y-0.5 hover:border-flag-yellow hover:text-flag-yellow"
          >
            <i.icon className="size-4" />
            {i.label}
          </a>
        </li>
      ))}
    </ul>
  )
}
