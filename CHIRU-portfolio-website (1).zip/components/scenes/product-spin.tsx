import { useMemo, useRef } from 'react'
import * as THREE from 'three'
import { Backdrop, type SceneProps, type Spring, spring, type Step, useSimulation, YELLOW, RED, CREAM } from './kit'

function createSim() {
  return {
    rotation: { x: 0, v: 0 } as Spring,
    tilt: { x: 0, v: 0 } as Spring,
    height: { x: 0, v: 0 } as Spring,
    impulseAt: 2.2,
  }
}

export function ProductSpin({ reduced }: SceneProps) {
  const product = useRef<THREE.Group>(null)
  const pedestal = useRef<THREE.Group>(null)
  const sim = useMemo(createSim, [])

  const step: Step = (dt, t, input) => {
    while (t >= sim.impulseAt) {
      sim.rotation.v += Math.PI * 1.7
      sim.tilt.v += 0.75
      sim.height.v += 1.2
      sim.impulseAt += 5.2
    }
    spring(sim.rotation, Math.floor(t / 5.2) * Math.PI * 2 + Math.sin(t * 0.35) * 0.3, dt, 10, 2.8)
    spring(sim.tilt, Math.sin(t * 0.42) * 0.08, dt, 8, 2.6)
    spring(sim.height, 0, dt, 18, 5.5)
    if (product.current) {
      product.current.rotation.set(sim.tilt.x + input.pointer.y * 0.08, sim.rotation.x + input.pointer.x * 0.12, 0)
      product.current.position.y = 0.55 + sim.height.x + Math.sin(t * 1.6) * 0.08
    }
    if (pedestal.current) pedestal.current.rotation.y = -sim.rotation.x * 0.18
  }

  useSimulation(reduced, step)

  return (
    <>
      <Backdrop color="#101014" />
      <ambientLight intensity={0.55} />
      <spotLight position={[0, 5, 4]} angle={0.52} penumbra={0.55} intensity={90} color={CREAM} />
      <pointLight position={[-3, 1, -2]} intensity={20} color={RED} />
      <pointLight position={[3, 1, 2]} intensity={26} color={YELLOW} />
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -1.6, 0]}>
        <circleGeometry args={[4.5, 64]} />
        <meshStandardMaterial color="#18181d" roughness={0.78} metalness={0.15} />
      </mesh>
      <group ref={pedestal} position={[0, -1.35, 0]}>
        <mesh position={[0, 0, 0]}>
          <cylinderGeometry args={[1.65, 1.78, 0.42, 64, 1]} />
          <meshStandardMaterial color="#27272d" metalness={0.72} roughness={0.28} />
        </mesh>
        <mesh position={[0, 0.22, 0]}>
          <torusGeometry args={[1.58, 0.035, 12, 96]} />
          <meshStandardMaterial color={YELLOW} emissive={YELLOW} emissiveIntensity={1.2} metalness={0.5} />
        </mesh>
      </group>
      <group ref={product} position={[0, 0.55, 0]}>
        <mesh position={[0, -0.65, 0]} castShadow>
          <boxGeometry args={[2.5, 0.28, 0.88]} />
          <meshStandardMaterial color={CREAM} roughness={0.3} />
        </mesh>
        <mesh position={[-0.06, -0.25, 0]} castShadow>
          <sphereGeometry args={[1, 40, 24]} />
          <meshStandardMaterial color="#b81324" roughness={0.32} metalness={0.2} />
        </mesh>
        <mesh position={[0.74, -0.48, 0]} castShadow>
          <sphereGeometry args={[0.48, 32, 24]} />
          <meshStandardMaterial color="#c8282d" roughness={0.3} />
        </mesh>
        <mesh position={[-0.83, -0.42, 0]} castShadow>
          <boxGeometry args={[0.42, 0.66, 0.84]} />
          <meshStandardMaterial color="#202026" roughness={0.34} />
        </mesh>
        <mesh position={[-0.02, 0.25, 0]} rotation={[0, 0, -0.12]}>
          <boxGeometry args={[0.11, 0.62, 0.38]} />
          <meshStandardMaterial color={CREAM} metalness={0.45} roughness={0.3} />
        </mesh>
        {[-0.26, -0.1, 0.06, 0.22, 0.38].map((y) => (
          <mesh key={y} position={[-0.12, y, 0.24]} rotation={[0, 0, -0.12]}>
            <boxGeometry args={[0.72, 0.035, 0.035]} />
            <meshStandardMaterial color={YELLOW} metalness={0.6} roughness={0.24} />
          </mesh>
        ))}
      </group>
      <mesh position={[0, -0.2, -2.4]}>
        <torusGeometry args={[2.5, 0.018, 8, 96]} />
        <meshBasicMaterial color={YELLOW} transparent opacity={0.38} />
      </mesh>
    </>
  )
}
