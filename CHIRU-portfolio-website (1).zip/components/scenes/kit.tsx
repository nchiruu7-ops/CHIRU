import { useFrame, useThree } from '@react-three/fiber'
import { useEffect, useRef } from 'react'
import * as THREE from 'three'

export const YELLOW = '#ffc20e'
export const RED = '#d62828'
export const INK = '#121214'
export const CREAM = '#fff4d6'

export interface SceneProps {
  reduced: boolean
}

export interface Input {
  pointer: THREE.Vector2
  dpr: number
}

export type Step = (dt: number, t: number, input: Input) => void

export interface Spring {
  x: number
  v: number
}

export function spring(s: Spring, target: number, dt: number, k: number, c: number) {
  s.v += ((target - s.x) * k - s.v * c) * dt
  s.x += s.v * dt
}

export const clamp = (v: number, lo: number, hi: number) => Math.min(hi, Math.max(lo, v))

export const lerp = (a: number, b: number, t: number) => a + (b - a) * t

export function smooth(a: number, b: number, x: number) {
  const t = clamp((x - a) / (b - a), 0, 1)
  return t * t * (3 - 2 * t)
}

export const cyc = (t: number, period: number) => t - Math.floor(t / period) * period

export function mulberry32(seed: number) {
  let a = seed >>> 0
  return () => {
    a = (a + 0x6d2b79f5) >>> 0
    let t = a
    t = Math.imul(t ^ (t >>> 15), t | 1)
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61)
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296
  }
}

export function Backdrop({ color }: { color: string }) {
  return <color attach="background" args={[color]} />
}

export function useDispose(...resources: { dispose: () => void }[]) {
  useEffect(() => {
    return () => {
      for (const resource of resources) resource.dispose()
    }
  }, [])
}

const SETTLE_STEPS = 240

/**
 * Advances the scene every frame. With reduced motion it instead runs a fixed
 * settle period once and renders that single still frame.
 */
export function useSimulation(reduced: boolean, step: Step) {
  const invalidate = useThree((s) => s.invalidate)
  const elapsed = useRef(0)

  useEffect(() => {
    if (!reduced) return
    const input = { pointer: new THREE.Vector2(), dpr: 1 }
    for (let i = 0; i < SETTLE_STEPS; i++) step(1 / 60, i / 60, input)
    invalidate()
  }, [reduced, invalidate])

  useFrame((state, delta) => {
    if (reduced) return
    const dt = Math.min(delta, 1 / 30)
    elapsed.current += dt
    step(dt, elapsed.current, { pointer: state.pointer, dpr: state.viewport.dpr })
  })
}
