import { useMemo, useRef } from 'react'
import * as THREE from 'three'
import {
  Backdrop,
  CREAM,
  lerp,
  RED,
  type SceneProps,
  type Step,
  useDispose,
  useSimulation,
  YELLOW,
} from './kit'

const PERIOD = 3.6
const SHEET_W = 1.9
const SHEET_D = 2.2
const SHEET_T = 0.02
const FEED_X = -2.5
const EJECT_X = 2.5
const TRAY_X = 2.9
const TRAY_TOP = -0.85
const STACK_MAX = 5
const GRAVITY = 14
const PALETTE = [YELLOW, RED, '#2dd4bf']

const easeOut = (t: number) => 1 - (1 - t) ** 3
const easeIn = (t: number) => t ** 3

function createSim() {
  return {
    k: -1,
    x: FEED_X,
    y: SHEET_T,
    vy: 0,
    landed: false,
    pileCount: 0,
    color: new THREE.Color(CREAM),
    target: new THREE.Color(CREAM),
  }
}

export function PrintPress({ reduced }: SceneProps) {
  const sim = useMemo(createSim, [])
  const sheetRef = useRef<THREE.Mesh>(null)
  const headRef = useRef<THREE.Mesh>(null)
  const bandRef = useRef<THREE.Mesh>(null)
  const pileRef = useRef<(THREE.Mesh | null)[]>([])
  const sheetMat = useMemo(() => new THREE.MeshStandardMaterial({ color: CREAM, roughness: 0.8 }), [])
  const pileMats = useMemo(
    () => Array.from({ length: STACK_MAX }, () => new THREE.MeshStandardMaterial({ color: CREAM, roughness: 0.8 })),
    [],
  )
  const headMat = useMemo(
    () => new THREE.MeshStandardMaterial({ color: RED, emissive: RED, emissiveIntensity: 0.6 }),
    [],
  )
  const bandMat = useMemo(
    () =>
      new THREE.MeshBasicMaterial({
        color: YELLOW,
        transparent: true,
        opacity: 0.9,
        blending: THREE.AdditiveBlending,
        depthWrite: false,
      }),
    [],
  )
  useDispose(sheetMat, headMat, bandMat, ...pileMats)

  const step: Step = (dt, t) => {
    const sheet = sheetRef.current
    const head = headRef.current
    const band = bandRef.current
    if (!sheet || !head || !band) return

    const k = Math.floor(t / PERIOD)
    const u = t - k * PERIOD
    if (k !== sim.k) {
      sim.k = k
      if (sim.pileCount >= STACK_MAX) {
        sim.pileCount = 0
        pileRef.current.forEach((m) => {
          if (m) m.visible = false
        })
      }
      sim.landed = false
      sim.x = FEED_X
      sim.y = SHEET_T
      sim.vy = 0
      sim.target.set(PALETTE[k % PALETTE.length])
    }

    let printing = false
    if (u < 0.9) {
      sim.x = lerp(FEED_X, 0, easeOut(u / 0.9))
      sim.color.set(CREAM)
    } else if (u < 1.9) {
      printing = true
      const pass = (u - 0.9) / 1
      sim.x = 0
      sim.color.set(CREAM).lerp(sim.target, pass)
      head.position.x = lerp(-1.6, 1.6, pass)
    } else if (u < 2.25) {
      sim.x = lerp(0, EJECT_X, easeIn((u - 1.9) / 0.35))
    } else if (!sim.landed) {
      sim.x += (TRAY_X - sim.x) * Math.min(1, dt * 6)
      sim.vy -= GRAVITY * dt
      sim.y += sim.vy * dt
      const rest = TRAY_TOP + sim.pileCount * SHEET_T + SHEET_T / 2
      if (sim.y <= rest) {
        sim.y = rest
        if (sim.vy < -1.2) {
          sim.vy = -sim.vy * 0.22
        } else {
          sim.vy = 0
          sim.landed = true
          const pile = pileRef.current[sim.pileCount]
          const pileMat = pileMats[sim.pileCount]
          if (pile) {
            pile.position.set(TRAY_X, rest, 0)
            pile.visible = true
          }
          pileMat.color.copy(sim.color)
          sim.pileCount += 1
        }
      }
    }

    sheet.visible = !sim.landed
    sheet.position.set(sim.x, sim.y, 0)
    sheetMat.color.copy(sim.color)
    head.visible = printing
    band.visible = printing
    band.position.set(head.position.x, SHEET_T + 0.015, 0)
  }

  useSimulation(reduced, step)

  return (
    <>
      <Backdrop color="#15110d" />
      <ambientLight intensity={0.6} />
      <directionalLight position={[3, 7, 5]} intensity={1.5} />
      <pointLight position={[0, 2.4, 2]} intensity={4} color={YELLOW} distance={10} />

      <mesh position={[FEED_X - 0.6, -0.2, 0]}>
        <boxGeometry args={[1.6, 0.4, 2.6]} />
        <meshStandardMaterial color="#1f1f24" metalness={0.4} roughness={0.5} />
      </mesh>
      <mesh position={[0, -0.1, 0]}>
        <boxGeometry args={[4.2, 0.2, 2.8]} />
        <meshStandardMaterial color="#2a2a30" metalness={0.7} roughness={0.35} />
      </mesh>
      <mesh position={[TRAY_X, TRAY_TOP - 0.15, 0]}>
        <boxGeometry args={[1.8, 0.3, 2.6]} />
        <meshStandardMaterial color="#1f1f24" metalness={0.4} roughness={0.5} />
      </mesh>

      <mesh ref={sheetRef} material={sheetMat}>
        <boxGeometry args={[SHEET_W, SHEET_T, SHEET_D]} />
      </mesh>
      {pileMats.map((mat, i) => (
        <mesh
          key={i}
          ref={(el) => {
            pileRef.current[i] = el
          }}
          material={mat}
          visible={false}
        >
          <boxGeometry args={[SHEET_W, SHEET_T, SHEET_D]} />
        </mesh>
      ))}

      <mesh ref={headRef} position={[-1.6, 0.9, 0]} material={headMat}>
        <boxGeometry args={[0.16, 0.16, 2.6]} />
      </mesh>
      <mesh ref={bandRef} rotation={[-Math.PI / 2, 0, 0]} material={bandMat}>
        <planeGeometry args={[0.28, 2]} />
      </mesh>
    </>
  )
}
