import { useEffect, useMemo, useRef } from 'react'
import * as THREE from 'three'
import {
  Backdrop,
  CREAM,
  clamp,
  RED,
  type SceneProps,
  type Spring,
  spring,
  type Step,
  useDispose,
  useSimulation,
  YELLOW,
} from './kit'

const N = 9
const COUNT = N * N
const PITCH = 0.62
const HALF = ((N - 1) * PITCH) / 2
const BALL_R = 0.22
const GRAVITY = 16
const DROP_HEIGHT = 3.6

const tileX = (j: number) => (j % N) * PITCH - HALF
const tileZ = (j: number) => Math.floor(j / N) * PITCH - HALF

function createSim() {
  return {
    heights: Array.from({ length: COUNT }, (): Spring => ({ x: 0.2, v: 0 })),
    roamX: { x: 0, v: 0 } as Spring,
    roamZ: { x: 0, v: 0 } as Spring,
    ball: { x: 0, y: DROP_HEIGHT, z: 0, vy: 0, bounces: 0 },
    prev: new THREE.Vector2(),
    dummy: new THREE.Object3D(),
  }
}

export function MotionKinetic({ reduced }: SceneProps) {
  const meshRef = useRef<THREE.InstancedMesh>(null)
  const ballRef = useRef<THREE.Mesh>(null)
  const sim = useMemo(createSim, [])
  const geometry = useMemo(() => new THREE.BoxGeometry(0.5, 1, 0.5), [])
  const material = useMemo(() => new THREE.MeshStandardMaterial({ roughness: 0.35, metalness: 0.1 }), [])
  useDispose(geometry, material)

  useEffect(() => {
    const mesh = meshRef.current
    if (!mesh) return
    const color = new THREE.Color()
    for (let j = 0; j < COUNT; j++) {
      const checker = ((j % N) + Math.floor(j / N)) % 2 === 0
      mesh.setColorAt(j, color.set(checker ? YELLOW : RED))
    }
    if (mesh.instanceColor) mesh.instanceColor.needsUpdate = true
  }, [])

  const step: Step = (dt, t, input) => {
    const mesh = meshRef.current
    const ballMesh = ballRef.current
    if (!mesh || !ballMesh) return
    const b = sim.ball

    spring(sim.roamX, Math.sin(t * 0.55) * 1.7, dt, 5, 3)
    spring(sim.roamZ, Math.cos(t * 0.37) * 1.3, dt, 5, 3)
    b.x = sim.roamX.x
    b.z = sim.roamZ.x
    b.vy -= GRAVITY * dt
    b.y += b.vy * dt

    const ix = clamp(Math.round((b.x + HALF) / PITCH), 0, N - 1)
    const iz = clamp(Math.round((b.z + HALF) / PITCH), 0, N - 1)
    const surface = sim.heights[iz * N + ix].x
    if (b.vy < 0 && b.y - BALL_R <= surface) {
      const impact = -b.vy
      b.y = surface + BALL_R
      b.vy = impact * 0.72
      b.bounces += 1
      for (let j = 0; j < COUNT; j++) {
        const d2 = (tileX(j) - b.x) ** 2 + (tileZ(j) - b.z) ** 2
        sim.heights[j].v -= impact * 2.2 * Math.exp(-d2 * 3)
      }
      if (b.bounces >= 3) {
        b.bounces = 0
        b.y = DROP_HEIGHT
        b.vy = 0
      }
    }

    const speed = Math.hypot(input.pointer.x - sim.prev.x, input.pointer.y - sim.prev.y) / Math.max(dt, 1e-3)
    sim.prev.copy(input.pointer)
    if (speed > 0.2) {
      const px = input.pointer.x * 4.4
      const pz = -input.pointer.y * 2.6
      const push = Math.min(speed, 4) * 0.25
      for (let j = 0; j < COUNT; j++) {
        const d2 = (tileX(j) - px) ** 2 + (tileZ(j) - pz) ** 2
        sim.heights[j].v += push * Math.exp(-d2 * 2.5)
      }
    }

    for (let j = 0; j < COUNT; j++) {
      const h = sim.heights[j]
      spring(h, 0.16 + 0.22 * (0.5 + 0.5 * Math.sin(t * 2.2 - (tileX(j) + tileZ(j)) * 0.9)), dt, 150, 8)
      if (h.x < 0.04) h.x = 0.04
      sim.dummy.position.set(tileX(j), h.x / 2, tileZ(j))
      sim.dummy.scale.set(1, h.x, 1)
      sim.dummy.updateMatrix()
      mesh.setMatrixAt(j, sim.dummy.matrix)
    }
    mesh.instanceMatrix.needsUpdate = true
    ballMesh.position.set(b.x, b.y, b.z)
  }

  useSimulation(reduced, step)

  return (
    <>
      <Backdrop color="#121214" />
      <ambientLight intensity={0.55} />
      <directionalLight position={[3, 6, 4]} intensity={1.6} />
      <pointLight position={[0, 3, 2]} intensity={6} color={YELLOW} distance={9} />
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.01, 0]}>
        <planeGeometry args={[14, 14]} />
        <meshStandardMaterial color="#17171b" roughness={0.9} />
      </mesh>
      <instancedMesh ref={meshRef} args={[geometry, material, COUNT]} />
      <mesh ref={ballRef}>
        <sphereGeometry args={[BALL_R, 32, 24]} />
        <meshStandardMaterial color={CREAM} emissive={YELLOW} emissiveIntensity={0.4} roughness={0.25} />
      </mesh>
    </>
  )
}
