import { useMemo, useRef } from 'react'
import * as THREE from 'three'
import {
  Backdrop,
  CREAM,
  INK,
  RED,
  type SceneProps,
  type Spring,
  spring,
  type Step,
  useDispose,
  useSimulation,
  YELLOW,
} from './kit'

const POSTERS = 4
const SPIN_EVERY = 2.4
const POSTER_W = 1.45
const POSTER_H = 1.8
const PALETTES: [string, string, string][] = [
  [YELLOW, RED, CREAM],
  [RED, YELLOW, CREAM],
  [CREAM, RED, YELLOW],
  [INK, YELLOW, RED],
  [YELLOW, INK, CREAM],
  [RED, CREAM, YELLOW],
]

const VERT = /* glsl */ `
varying vec2 vUv;
void main() {
  vUv = uv;
  gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
}
`

const FRAG = /* glsl */ `
uniform float uTime;
uniform float uPattern;
uniform vec3 uA;
uniform vec3 uB;
uniform vec3 uC;
varying vec2 vUv;

float hash(vec2 p) { return fract(sin(dot(p, vec2(41.3, 289.1))) * 9583.1); }

void main() {
  vec2 uv = vUv;
  vec3 col;
  if (uPattern < 0.5) {
    float d = length((uv - 0.5) * vec2(1.0, 1.25));
    float r = fract(d * 9.0 - uTime * 0.4);
    col = mix(uA, uB, step(0.5, r));
    col = mix(col, uC, step(d, 0.12));
  } else if (uPattern < 1.5) {
    vec2 g = fract(uv * vec2(22.0, 28.0)) - 0.5;
    float dots = 1.0 - step(0.5 * (1.0 - uv.y) + 0.05, length(g));
    col = mix(uA, uB, dots);
    col = mix(col, uC, step(uv.y, 0.1));
  } else if (uPattern < 2.5) {
    float s = fract((uv.x + uv.y) * 5.0 - uTime * 0.25);
    col = mix(uA, uB, step(0.5, s));
    col = mix(col, uC, step(uv.y, 0.12));
  } else if (uPattern < 3.5) {
    vec2 cell = floor(uv * vec2(4.0, 5.0));
    float h = hash(cell);
    col = mix(uA, uB, step(0.55, h));
    col = mix(col, uC, step(0.92, h));
  } else if (uPattern < 4.5) {
    float d = distance(uv, vec2(0.5, 0.0));
    float arcs = fract(d * 6.0 - uTime * 0.3);
    col = mix(uA, uB, smoothstep(0.45, 0.55, arcs));
    col = mix(col, uC, step(0.94, uv.y));
  } else {
    float b = floor(uv.y * 12.0);
    col = mix(uA, uB, step(0.5, fract(b * 0.618)));
    col = mix(col, uC, step(uv.x, 0.04 + 0.5 * fract(b * 0.37)) * step(0.5, fract(b * 0.618)));
  }
  gl_FragColor = vec4(col, 1.0);
}
`

function createSim() {
  return {
    angles: Array.from({ length: POSTERS }, (): Spring => ({ x: 0, v: 0 })),
    turns: Array.from({ length: POSTERS }, () => 0),
    nextSpin: Array.from({ length: POSTERS }, (_, i) => 1 + i * 0.6),
    tiltX: { x: 0, v: 0 } as Spring,
    tiltY: { x: 0, v: 0 } as Spring,
  }
}

export function PosterFlip({ reduced }: SceneProps) {
  const root = useRef<THREE.Group>(null)
  const posterRefs = useRef<(THREE.Group | null)[]>([])
  const sim = useMemo(createSim, [])
  const geometry = useMemo(() => new THREE.PlaneGeometry(POSTER_W, POSTER_H), [])
  const materials = useMemo(
    () =>
      Array.from(
        { length: POSTERS },
        () =>
          new THREE.ShaderMaterial({
            vertexShader: VERT,
            fragmentShader: FRAG,
            uniforms: {
              uTime: { value: 0 },
              uPattern: { value: 0 },
              uA: { value: new THREE.Color(YELLOW) },
              uB: { value: new THREE.Color(RED) },
              uC: { value: new THREE.Color(CREAM) },
            },
            side: THREE.DoubleSide,
          }),
      ),
    [],
  )
  useDispose(geometry, ...materials)

  const step: Step = (dt, t, input) => {
    for (let i = 0; i < POSTERS; i++) {
      if (t >= sim.nextSpin[i]) {
        sim.turns[i] += 1
        sim.nextSpin[i] += SPIN_EVERY
      }
      const angle = sim.angles[i]
      spring(angle, sim.turns[i] * Math.PI * 2, dt, 16, 3.6)

      const pattern = (((i + Math.floor((angle.x + Math.PI / 2) / (Math.PI * 2))) % 6) + 6) % 6
      const palette = PALETTES[pattern]
      const mat = materials[i]
      mat.uniforms.uTime.value = t
      mat.uniforms.uPattern.value = pattern
      mat.uniforms.uA.value.set(palette[0])
      mat.uniforms.uB.value.set(palette[1])
      mat.uniforms.uC.value.set(palette[2])

      const group = posterRefs.current[i]
      if (group) {
        group.rotation.y = angle.x
        group.position.y = Math.sin(t * 1.4 + i * 0.9) * 0.08
      }
    }

    spring(sim.tiltY, input.pointer.x * 0.25, dt, 30, 7)
    spring(sim.tiltX, -input.pointer.y * 0.15, dt, 30, 7)
    root.current?.rotation.set(sim.tiltX.x, sim.tiltY.x, 0)
  }

  useSimulation(reduced, step)

  return (
    <>
      <Backdrop color="#0e0d0f" />
      <ambientLight intensity={0.9} />
      <directionalLight position={[2, 3, 6]} intensity={0.8} />
      <group ref={root}>
        {materials.map((mat, i) => (
          <group
            key={i}
            ref={(el) => {
              posterRefs.current[i] = el
            }}
            position={[(i - (POSTERS - 1) / 2) * 1.75, 0, 0]}
          >
            <mesh geometry={geometry} material={mat} />
          </group>
        ))}
      </group>
    </>
  )
}
