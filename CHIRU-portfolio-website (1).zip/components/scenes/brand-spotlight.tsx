import { useMemo, useRef } from 'react'
import * as THREE from 'three'
import { Backdrop, CREAM, RED, type SceneProps, type Spring, spring, type Step, useSimulation, YELLOW } from './kit'

function createSim() {
  return {
    yaw: { x: 0, v: 0 } as Spring,
    halo: { x: 0.1, v: 0 } as Spring,
    orbit: { x: 0, v: 0 } as Spring,
  }
}

export function BrandSpotlight({ reduced }: SceneProps) {
  const identity = useRef<THREE.Group>(null)
  const halo = useRef<THREE.Mesh>(null)
  const orbitals = useRef<(THREE.Mesh | null)[]>([])
  const sim = useMemo(createSim, [])

  const step: Step = (dt, t, input) => {
    spring(sim.yaw, Math.sin(t * 0.4) * 0.32 + input.pointer.x * 0.18, dt, 9, 3)
    spring(sim.halo, 0.12 + Math.sin(t * 1.2) * 0.05, dt, 12, 4)
    spring(sim.orbit, t * 0.42, dt, 18, 5)
    identity.current?.rotation.set(input.pointer.y * -0.14, sim.yaw.x, 0)
    if (halo.current) {
      halo.current.rotation.z = -sim.orbit.x * 0.35
      halo.current.scale.setScalar(1 + sim.halo.x)
    }
    orbitals.current.forEach((orb, i) => {
      if (!orb) return
      const a = sim.orbit.x + i * Math.PI * 2 / 4
      orb.position.set(Math.cos(a) * 2.05, Math.sin(a * 1.4) * 0.4, Math.sin(a) * 0.5)
    })
  }

  useSimulation(reduced, step)

  return (
    <>
      <Backdrop color="#0d0a0d" />
      <ambientLight intensity={0.48} />
      <pointLight position={[0, 1, 4]} intensity={45} color={CREAM} />
      <pointLight position={[-3, 2, -1]} intensity={32} color={RED} />
      <pointLight position={[3, -1, 1]} intensity={28} color={YELLOW} />
      <mesh ref={halo} position={[0, 0, -0.35]}>
        <torusGeometry args={[1.44, 0.045, 16, 128]} />
        <meshStandardMaterial color={YELLOW} emissive={YELLOW} emissiveIntensity={0.8} metalness={0.75} roughness={0.22} />
      </mesh>
      <group ref={identity}>
        <mesh castShadow>
          <torusKnotGeometry args={[0.78, 0.26, 160, 24, 2, 3]} />
          <meshStandardMaterial color={RED} roughness={0.25} metalness={0.38} emissive="#46090e" emissiveIntensity={0.4} />
        </mesh>
        <mesh rotation={[Math.PI / 2, 0, 0]}>
          <torusGeometry args={[0.82, 0.035, 16, 96]} />
          <meshStandardMaterial color={CREAM} metalness={0.8} roughness={0.18} />
        </mesh>
        <mesh position={[0, 0, 0.72]}>
          <icosahedronGeometry args={[0.24, 1]} />
          <meshStandardMaterial color={YELLOW} emissive={YELLOW} emissiveIntensity={0.5} metalness={0.45} roughness={0.22} />
        </mesh>
      </group>
      {Array.from({ length: 4 }, (_, i) => (
        <mesh
          key={i}
          ref={(el) => {
            orbitals.current[i] = el
          }}
        >
          <sphereGeometry args={[i === 0 ? 0.14 : 0.09, 24, 16]} />
          <meshStandardMaterial color={i % 2 ? RED : CREAM} emissive={i % 2 ? RED : YELLOW} emissiveIntensity={0.45} />
        </mesh>
      ))}
      <mesh position={[0, -1.7, 0]}>
        <cylinderGeometry args={[1.2, 1.5, 0.22, 64]} />
        <meshStandardMaterial color="#202027" roughness={0.35} metalness={0.62} />
      </mesh>
    </>
  )
}
