import { useMemo, useRef } from 'react'
import * as THREE from 'three'
import { Backdrop, CREAM, RED, type SceneProps, type Spring, spring, type Step, useSimulation, YELLOW } from './kit'

const COUNT = 4
const DEPTH = [-1.35, -0.45, 0.45, 1.35]

function createSim() {
  return {
    heights: Array.from({ length: COUNT }, (_, i): Spring => ({ x: 0.45 + i * 0.18, v: 0 })),
    bridge: { x: 0, v: 0 } as Spring,
    light: { x: -3.5, v: 0 } as Spring,
  }
}

export function StrategyPillars({ reduced }: SceneProps) {
  const pillars = useRef<(THREE.Group | null)[]>([])
  const beam = useRef<THREE.Mesh>(null)
  const light = useRef<THREE.Mesh>(null)
  const sim = useMemo(createSim, [])

  const step: Step = (dt, t, input) => {
    const phase = t % 10
    const active = phase > 1.1 && phase < 7.2 ? 1 : 0
    sim.heights.forEach((height, i) => {
      const wave = active ? 1.65 + Math.sin(t * 0.65 + i * 0.38) * 0.12 : 0.48 + i * 0.12
      spring(height, wave, dt, 22, 6.2)
      const group = pillars.current[i]
      if (group) {
        group.scale.y = Math.max(0.08, height.x)
        group.position.y = (group.scale.y - 1) * 0.48
      }
    })
    spring(sim.bridge, active ? 0.12 : -0.3, dt, 15, 5)
    spring(sim.light, phase > 1.1 && phase < 7.2 ? -3.5 + ((phase - 1.1) / 6.1) * 7 : -3.5, dt, 10, 4)
    if (beam.current) {
      beam.current.position.y = 1.4 + sim.bridge.x
      beam.current.rotation.z = input.pointer.x * 0.05
    }
    if (light.current) light.current.position.x = sim.light.x
  }

  useSimulation(reduced, step)

  return (
    <>
      <Backdrop color="#101013" />
      <ambientLight intensity={0.55} />
      <directionalLight position={[1, 5, 4]} intensity={1.5} />
      <pointLight position={[0, 3, 0]} intensity={18} color={YELLOW} distance={10} />
      {DEPTH.map((z, i) => (
        <group
          key={z}
          ref={(el) => {
            pillars.current[i] = el
          }}
          position={[(i - (COUNT - 1) / 2) * 1.45, 0, z]}
        >
          <mesh position={[0, 0.5, 0]} castShadow>
            <boxGeometry args={[0.82, 1, 0.82]} />
            <meshStandardMaterial color={[YELLOW, RED, CREAM, '#7f5af0'][i]} roughness={0.34} metalness={0.22} />
          </mesh>
          <mesh position={[0, 1.06, 0]}>
            <cylinderGeometry args={[0.16, 0.16, 0.12, 32]} />
            <meshStandardMaterial color={CREAM} metalness={0.7} roughness={0.24} />
          </mesh>
        </group>
      ))}
      <mesh ref={beam} position={[0, 1.1, 0]}>
        <boxGeometry args={[6.4, 0.18, 0.56]} />
        <meshStandardMaterial color="#25252b" metalness={0.66} roughness={0.3} />
      </mesh>
      <mesh position={[0, 0.04, 0]} rotation={[-Math.PI / 2, 0, 0]}>
        <boxGeometry args={[9, 0.12, 4.5]} />
        <meshStandardMaterial color="#1b1b20" roughness={0.82} />
      </mesh>
      <mesh ref={light} position={[-3.5, 0.18, 2.2]} rotation={[-Math.PI / 2, 0, 0]}>
        <planeGeometry args={[0.75, 3]} />
        <meshBasicMaterial color={YELLOW} transparent opacity={0.32} side={THREE.DoubleSide} />
      </mesh>
    </>
  )
}
