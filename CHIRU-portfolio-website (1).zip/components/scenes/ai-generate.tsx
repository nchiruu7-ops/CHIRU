import { useMemo, useRef } from 'react'
import * as THREE from 'three'
import {
  Backdrop,
  cyc,
  mulberry32,
  type SceneProps,
  type Spring,
  smooth,
  spring,
  type Step,
  useDispose,
  useSimulation,
  YELLOW,
} from './kit'

const COUNT = 420
const CYCLE = 8
const PLANE_W = 3.4
const PLANE_H = 2.25
const ORB_X = -3.1
const ORB_Y = 1.5
const ORB_Z = 1.2

const PLANE_VERT = /* glsl */ `
varying vec2 vUv;
void main() {
  vUv = uv;
  gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
}
`

const PLANE_FRAG = /* glsl */ `
uniform float uTime;
uniform float uReveal;
varying vec2 vUv;

float hash(vec2 p) { return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }

float noise(vec2 p) {
  vec2 i = floor(p);
  vec2 f = fract(p);
  vec2 u = f * f * (3.0 - 2.0 * f);
  return mix(
    mix(hash(i), hash(i + vec2(1.0, 0.0)), u.x),
    mix(hash(i + vec2(0.0, 1.0)), hash(i + vec2(1.0, 1.0)), u.x),
    u.y
  );
}

float fbm(vec2 p) {
  float v = 0.0;
  float a = 0.5;
  for (int i = 0; i < 5; i++) {
    v += a * noise(p);
    p = p * 2.03 + vec2(1.7, 9.2);
    a *= 0.5;
  }
  return v;
}

void main() {
  vec2 uv = vUv;
  float n = fbm(uv * vec2(3.0, 2.0) + vec2(0.0, uTime * 0.05));
  vec3 dusk = mix(
    vec3(0.42, 0.04, 0.05),
    vec3(1.0, 0.76, 0.05),
    smoothstep(0.05, 0.95, uv.y + (n - 0.5) * 0.3)
  );
  float sun = 1.0 - smoothstep(0.17, 0.19, distance(uv, vec2(0.5, 0.42)));
  vec3 col = mix(dusk, vec3(1.0, 0.96, 0.85), sun);
  float ridge = 0.18 + 0.35 * fbm(vec2(uv.x * 3.0, 4.0));
  col = mix(col, vec3(0.07, 0.02, 0.03), step(uv.y, ridge));
  float edge = smoothstep(uReveal - 0.02, uReveal + 0.02, n);
  float front = 1.0 - smoothstep(0.0, 0.025, abs(n - uReveal));
  vec3 base = vec3(0.035, 0.03, 0.035);
  gl_FragColor = vec4(mix(col, base, edge) + front * vec3(1.0, 0.76, 0.05), 1.0);
}
`

const POINT_VERT = /* glsl */ `
attribute float aSize;
attribute float aAlpha;
uniform float uPixel;
varying float vAlpha;
void main() {
  vAlpha = aAlpha;
  vec4 mv = modelViewMatrix * vec4(position, 1.0);
  gl_PointSize = aSize * uPixel / max(0.1, -mv.z);
  gl_Position = projectionMatrix * mv;
}
`

const POINT_FRAG = /* glsl */ `
uniform vec3 uColor;
varying float vAlpha;
void main() {
  float d = length(gl_PointCoord - vec2(0.5));
  float a = smoothstep(0.5, 0.0, d) * vAlpha;
  if (a < 0.01) discard;
  gl_FragColor = vec4(uColor, a);
}
`

function createParticles() {
  const rand = mulberry32(11)
  const pos = new Float32Array(COUNT * 3)
  const vel = new Float32Array(COUNT * 3)
  const target = new Float32Array(COUNT * 3)
  const sway = new Float32Array(COUNT * 3)
  const jitter = new Float32Array(COUNT * 3)
  const start = new Float32Array(COUNT)
  const scatter = new Float32Array(COUNT)
  const size = new Float32Array(COUNT)
  const alpha = new Float32Array(COUNT)

  for (let i = 0; i < COUNT; i++) {
    const k = i * 3
    target[k] = (rand() - 0.5) * PLANE_W
    target[k + 1] = (rand() - 0.5) * PLANE_H
    target[k + 2] = 0.06
    const a = rand() * Math.PI * 2
    const b = (rand() - 0.5) * Math.PI
    const s = 1.2 + rand() * 1.8
    sway[k] = Math.cos(a) * Math.cos(b) * s
    sway[k + 1] = Math.sin(b) * s
    sway[k + 2] = Math.sin(a) * Math.cos(b) * s * 0.3
    jitter[k] = (rand() - 0.5) * 0.16
    jitter[k + 1] = (rand() - 0.5) * 0.16
    jitter[k + 2] = (rand() - 0.5) * 0.16
    start[i] = 0.3 + rand() * 1.1
    scatter[i] = 4.5 + rand() * 0.6
    size[i] = 0.5 + rand() * 0.7
    pos[k] = ORB_X + jitter[k]
    pos[k + 1] = ORB_Y + jitter[k + 1]
    pos[k + 2] = ORB_Z + jitter[k + 2]
  }

  const position = new THREE.BufferAttribute(pos, 3)
  const aAlpha = new THREE.BufferAttribute(alpha, 1)
  const geometry = new THREE.BufferGeometry()
  geometry.setAttribute('position', position)
  geometry.setAttribute('aSize', new THREE.BufferAttribute(size, 1))
  geometry.setAttribute('aAlpha', aAlpha)

  return {
    geometry,
    position,
    aAlpha,
    pos,
    vel,
    target,
    sway,
    jitter,
    start,
    scatter,
    alpha,
    tiltX: { x: 0, v: 0 } as Spring,
    tiltY: { x: 0, v: 0 } as Spring,
  }
}

export function AiGenerate({ reduced }: SceneProps) {
  const group = useRef<THREE.Group>(null)
  const orb = useRef<THREE.Mesh>(null)
  const sim = useMemo(createParticles, [])
  const planeMat = useMemo(
    () =>
      new THREE.ShaderMaterial({
        vertexShader: PLANE_VERT,
        fragmentShader: PLANE_FRAG,
        uniforms: { uTime: { value: 0 }, uReveal: { value: 0 } },
      }),
    [],
  )
  const pointMat = useMemo(
    () =>
      new THREE.ShaderMaterial({
        vertexShader: POINT_VERT,
        fragmentShader: POINT_FRAG,
        uniforms: { uPixel: { value: 52 }, uColor: { value: new THREE.Color(YELLOW) } },
        transparent: true,
        depthWrite: false,
        blending: THREE.AdditiveBlending,
      }),
    [],
  )
  useDispose(sim.geometry, planeMat, pointMat)

  const step: Step = (dt, t, input) => {
    const p = cyc(t, CYCLE)
    for (let i = 0; i < COUNT; i++) {
      const k = i * 3
      const end = sim.scatter[i] + 1.4
      if (p < sim.start[i] || p >= end) {
        sim.pos[k] = ORB_X + sim.jitter[k]
        sim.pos[k + 1] = ORB_Y + sim.jitter[k + 1]
        sim.pos[k + 2] = ORB_Z + sim.jitter[k + 2]
        sim.vel[k] = 0
        sim.vel[k + 1] = 0
        sim.vel[k + 2] = 0
        sim.alpha[i] = 0
        continue
      }

      let ax: number
      let ay: number
      let az: number
      if (p < sim.scatter[i]) {
        ax = (sim.target[k] - sim.pos[k]) * 9 - sim.vel[k] * 4.2 + Math.sin(t * 3 + i) * 0.9
        ay =
          (sim.target[k + 1] - sim.pos[k + 1]) * 9 -
          sim.vel[k + 1] * 4.2 +
          Math.cos(t * 2.6 + i * 1.3) * 0.9
        az = (sim.target[k + 2] - sim.pos[k + 2]) * 9 - sim.vel[k + 2] * 4.2
        sim.alpha[i] = smooth(sim.start[i], sim.start[i] + 0.3, p)
      } else {
        ax = sim.sway[k] * 2.4 - sim.vel[k] * 1.4
        ay = sim.sway[k + 1] * 2.4 - sim.vel[k + 1] * 1.4
        az = sim.sway[k + 2] * 2.4 - sim.vel[k + 2] * 1.4
        sim.alpha[i] = 1 - smooth(sim.scatter[i], end, p)
      }

      sim.vel[k] += ax * dt
      sim.vel[k + 1] += ay * dt
      sim.vel[k + 2] += az * dt
      sim.pos[k] += sim.vel[k] * dt
      sim.pos[k + 1] += sim.vel[k + 1] * dt
      sim.pos[k + 2] += sim.vel[k + 2] * dt
    }

    const reveal = p < 4.3 ? smooth(1.6, 4.3, p) : 1 - smooth(5, 6.6, p)
    planeMat.uniforms.uTime.value = t
    planeMat.uniforms.uReveal.value = reveal
    pointMat.uniforms.uPixel.value = input.dpr * 52
    sim.position.needsUpdate = true
    sim.aAlpha.needsUpdate = true

    spring(sim.tiltY, input.pointer.x * 0.35, dt, 30, 7)
    spring(sim.tiltX, -input.pointer.y * 0.2, dt, 30, 7)
    group.current?.rotation.set(sim.tiltX.x, sim.tiltY.x, 0)
    if (orb.current) {
      orb.current.position.y = ORB_Y + Math.sin(t * 1.7) * 0.12
      orb.current.scale.setScalar(1 + Math.sin(t * 5) * 0.08)
    }
  }

  useSimulation(reduced, step)

  return (
    <>
      <Backdrop color="#0b0708" />
      <ambientLight intensity={0.4} />
      <group ref={group}>
        <mesh material={planeMat}>
          <planeGeometry args={[PLANE_W, PLANE_H]} />
        </mesh>
        <points geometry={sim.geometry} material={pointMat} frustumCulled={false} />
        <mesh ref={orb} position={[ORB_X, ORB_Y, ORB_Z]}>
          <sphereGeometry args={[0.2, 32, 24]} />
          <meshBasicMaterial color={YELLOW} />
        </mesh>
      </group>
    </>
  )
}
