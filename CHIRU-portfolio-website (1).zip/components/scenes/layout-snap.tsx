import { useMemo, useRef } from 'react'
import * as THREE from 'three'
import {
  Backdrop,
  CREAM,
  cyc,
  mulberry32,
  RED,
  type SceneProps,
  type Spring,
  spring,
  type Step,
  useDispose,
  useSimulation,
  YELLOW,
} from './kit'

const PERIOD = 7
const PAGE_W = 6.8
const PAGE_H = 4.6

type Kind = 'image' | 'rect' | 'dot' | 'ring'

const BLOCKS: { kind: Kind; x: number; y: number; w: number; h: number; color: string }[] = [
  { kind: 'image', x: -1.35, y: 0.5, w: 2.3, h: 2.6, color: YELLOW },
  { kind: 'rect', x: 1.5, y: 1.25, w: 2, h: 0.42, color: CREAM },
  { kind: 'rect', x: 1.5, y: 0.5, w: 2, h: 0.16, color: '#8c8478' },
  { kind: 'rect', x: 1.5, y: 0.18, w: 2, h: 0.16, color: '#8c8478' },
  { kind: 'rect', x: 1.5, y: -0.14, w: 1.5, h: 0.16, color: '#8c8478' },
  { kind: 'dot', x: -1.9, y: -1.25, w: 0.42, h: 0.42, color: RED },
  { kind: 'dot', x: -1.3, y: -1.25, w: 0.42, h: 0.42, color: YELLOW },
  { kind: 'dot', x: -0.7, y: -1.25, w: 0.42, h: 0.42, color: CREAM },
  { kind: 'ring', x: 1.7, y: -1.15, w: 0.62, h: 0.62, color: RED },
]

function geometryFor(block: (typeof BLOCKS)[number]) {
  if (block.kind === 'dot') {
    const geo = new THREE.CylinderGeometry(block.w / 2, block.w / 2, 0.08, 32)
    geo.rotateX(Math.PI / 2)
    return geo
  }
  if (block.kind === 'ring') return new THREE.TorusGeometry(block.w / 2 - 0.08, 0.08, 16, 48)
  return new THREE.BoxGeometry(block.w, block.h, 0.08)
}

function createSim() {
  const rand = mulberry32(21)
  return {
    items: BLOCKS.map((block) => ({
      x: { x: block.x + (rand() - 0.5) * 9, v: 0 } as Spring,
      y: { x: block.y + (rand() - 0.5) * 6, v: 0 } as Spring,
      r: { x: (rand() - 0.5) * 3, v: 0 } as Spring,
      farX: (rand() - 0.5) * 9,
      farY: (rand() - 0.5) * 5,
      spin: (rand() - 0.5) * 2.4,
    })),
    tiltX: { x: 0, v: 0 } as Spring,
    tiltY: { x: 0, v: 0 } as Spring,
  }
}

export function LayoutSnap({ reduced }: SceneProps) {
  const root = useRef<THREE.Group>(null)
  const groups = useRef<(THREE.Group | null)[]>([])
  const guide = useRef<THREE.Mesh>(null)
  const sim = useMemo(createSim, [])
  const geometries = useMemo(() => BLOCKS.map(geometryFor), [])
  const materials = useMemo(
    () =>
      BLOCKS.map(
        (block) =>
          new THREE.MeshStandardMaterial({
            color: block.color,
            emissive: YELLOW,
            emissiveIntensity: 0,
            roughness: 0.4,
          }),
      ),
    [],
  )
  const pageMat = useMemo(() => new THREE.MeshStandardMaterial({ color: '#1d1d22', roughness: 0.9 }), [])
  const guideMat = useMemo(
    () => new THREE.MeshBasicMaterial({ color: YELLOW, transparent: true, opacity: 0, depthWrite: false }),
    [],
  )
  useDispose(pageMat, guideMat, ...materials, ...geometries)

  const step: Step = (dt, t, input) => {
    const p = cyc(t, PERIOD)
    const exploding = p >= 4.4 && p < 5
    const sweeping = p >= 2.6 && p < 4.4
    const sweepX = -3.2 + ((p - 2.6) / 1.8) * 6.4

    sim.items.forEach((item, i) => {
      const block = BLOCKS[i]
      spring(item.x, exploding ? item.farX : block.x, dt, 70, 8)
      spring(item.y, exploding ? item.farY : block.y, dt, 70, 8)
      spring(item.r, exploding ? item.spin : 0, dt, 60, 7)
      const group = groups.current[i]
      if (group) {
        group.position.set(item.x.x, item.y.x, 0)
        group.rotation.z = item.r.x
      }
      const near = sweeping ? Math.exp(-((block.x - sweepX) ** 2) * 2.5) : 0
      materials[i].emissiveIntensity = near * 0.5
    })

    if (guide.current) {
      guide.current.position.x = sweeping ? sweepX : 0
      guide.current.position.y = 0
      guideMat.opacity = sweeping ? 0.85 : 0
    }

    spring(sim.tiltY, input.pointer.x * 0.2, dt, 30, 7)
    spring(sim.tiltX, -input.pointer.y * 0.12, dt, 30, 7)
    root.current?.rotation.set(sim.tiltX.x, sim.tiltY.x, 0)
  }

  useSimulation(reduced, step)

  return (
    <>
      <Backdrop color="#101113" />
      <ambientLight intensity={0.7} />
      <directionalLight position={[2, 4, 6]} intensity={1.4} />
      <group ref={root}>
        <mesh position={[0, 0, -0.12]} material={pageMat}>
          <boxGeometry args={[PAGE_W, PAGE_H, 0.05]} />
        </mesh>
        {BLOCKS.map((block, i) => (
          <group
            key={i}
            ref={(el) => {
              groups.current[i] = el
            }}
          >
            <mesh geometry={geometries[i]} material={materials[i]} />
            {block.kind === 'image' ? (
              <mesh position={[0, 0.25, 0.06]}>
                <circleGeometry args={[0.6, 48]} />
                <meshStandardMaterial color={RED} roughness={0.5} />
              </mesh>
            ) : null}
          </group>
        ))}
        <mesh ref={guide} position={[0, 0, 0.2]} material={guideMat}>
          <boxGeometry args={[0.035, PAGE_H, 0.02]} />
        </mesh>
      </group>
    </>
  )
}
