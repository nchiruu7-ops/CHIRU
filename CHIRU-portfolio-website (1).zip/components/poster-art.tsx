import type { PosterConcept } from '@/lib/posters'

export function PosterArt({ poster, className = '' }: { poster: PosterConcept; className?: string }) {
  const [background, mid, accent, paper] = poster.palette

  return (
    <svg viewBox="0 0 420 560" role="img" aria-label={`${poster.title}: ${poster.brief}`} className={className}>
      <rect width="420" height="560" fill={background} />
      {poster.style === 'sun' && (
        <>
          {Array.from({ length: 18 }, (_, i) => <path key={i} d="M210 215V35" stroke={mid} strokeWidth="2" opacity=".5" transform={`rotate(${i * 20} 210 215)`} />)}
          <circle cx="210" cy="215" r="130" fill={accent} />
          <circle cx="210" cy="215" r="86" fill={mid} />
          <path d="M20 320H400V355H20z" fill={paper} />
          <path d="M20 365H350V380H20z" fill={mid} />
        </>
      )}
      {poster.style === 'cut-paper' && (
        <>
          <circle cx="305" cy="155" r="80" fill={accent} />
          <path d="M0 325L100 195L190 325Z" fill={mid} />
          <path d="M85 325L210 125L340 325Z" fill={paper} />
          <path d="M225 325L330 215L420 325Z" fill={accent} />
          <path d="M20 340H400V350H20zM20 365H315V378H20z" fill={paper} />
        </>
      )}
      {poster.style === 'wave' && (
        <>
          {[0, 1, 2, 3, 4, 5].map((i) => <path key={i} d={`M-20 ${185 + i * 23} C70 ${105 + i * 30},145 ${300 - i * 14},230 ${190 + i * 21} S350 ${115 + i * 27},450 ${190 + i * 22}`} fill="none" stroke={i % 2 ? accent : paper} strokeWidth={i === 2 ? 26 : 12} opacity={0.82 - i * 0.06} />)}
          <circle cx="315" cy="105" r="34" fill={accent} />
          <path d="M28 360H392V372H28z" fill={paper} />
        </>
      )}
      {poster.style === 'grid' && (
        <>
          {Array.from({ length: 35 }, (_, i) => {
            const x = 28 + (i % 5) * 74
            const y = 48 + Math.floor(i / 5) * 43
            const size = 15 + ((i * 17) % 35)
            return <rect key={i} x={x} y={y} width={size} height={size} fill={[mid, accent, paper][i % 3]} opacity=".9" />
          })}
          <path d="M24 325H396V340H24zM24 355H275V367H24z" fill={mid} />
        </>
      )}
      {poster.style === 'botanical' && (
        <>
          {[90, 210, 330].map((x, i) => <g key={x} transform={`rotate(${i * 18 - 18} ${x} 270)`}><path d={`M${x} 360V90`} stroke={paper} strokeWidth="5"/><ellipse cx={x - 30} cy="165" rx="28" ry="65" fill={mid} transform={`rotate(-36 ${x - 30} 165)`}/><ellipse cx={x + 32} cy="235" rx="24" ry="58" fill={accent} transform={`rotate(38 ${x + 32} 235)`}/><ellipse cx={x - 25} cy="300" rx="20" ry="47" fill={paper} opacity=".8" transform={`rotate(-35 ${x - 25} 300)`}/></g>)}
          <path d="M35 390H385V403H35z" fill={paper} />
        </>
      )}
      {poster.style === 'orbit' && (
        <>
          <circle cx="210" cy="205" r="150" fill="none" stroke={mid} strokeWidth="2" />
          <circle cx="210" cy="205" r="118" fill="none" stroke={accent} strokeWidth="16" />
          <circle cx="210" cy="205" r="77" fill={mid} />
          <circle cx="210" cy="205" r="32" fill={paper} />
          <circle cx="330" cy="130" r="18" fill={accent} />
          <circle cx="105" cy="300" r="12" fill={paper} />
          <path d="M28 360H392V375H28z" fill={paper} />
        </>
      )}
      {poster.style === 'architecture' && (
        <>
          <circle cx="280" cy="120" r="72" fill={accent} />
          <path d="M42 340V225H102V170H162V215H222V150H275V340z" fill={mid} />
          <path d="M220 340V260H286V210H340V265H385V340z" fill={paper} />
          {Array.from({ length: 8 }, (_, i) => <rect key={i} x={58 + i * 43} y={355 + (i % 2) * 19} width="25" height="3" fill={accent} />)}
        </>
      )}
      {poster.style === 'signal' && (
        <>
          {Array.from({ length: 18 }, (_, i) => <rect key={i} x={28 + i * 21} y={65 + Math.sin(i * 1.7) * 80} width="12" height={145 + Math.cos(i * 0.8) * 55} rx="6" fill={i % 3 ? mid : accent} opacity=".9" />)}
          <path d="M30 290H390" stroke={paper} strokeWidth="3" />
          <path d="M30 318H290" stroke={accent} strokeWidth="14" />
        </>
      )}
      <text x="28" y="445" fill={paper} fontFamily="Arial, sans-serif" fontSize="32" fontWeight="700" letterSpacing="-1">{poster.title}</text>
      <text x="30" y="478" fill={paper} opacity=".72" fontFamily="Arial, sans-serif" fontSize="11" fontWeight="600" letterSpacing="2">{poster.edition.toUpperCase()}</text>
      <path d="M28 502H392" stroke={paper} opacity=".4" />
      <text x="30" y="530" fill={paper} opacity=".56" fontFamily="Arial, sans-serif" fontSize="9" letterSpacing="2">CHIRU / VISUAL STUDY</text>
      <rect x="0" y="0" width="420" height="560" fill="none" stroke={paper} strokeOpacity=".14" strokeWidth="2" />
    </svg>
  )
}
