'use client'

import dynamic from 'next/dynamic'
import { useRef } from 'react'

const FlagCanvas = dynamic(() => import('./flag-canvas'), { ssr: false })

export function FlagBackdrop() {
  const wind = useRef(0.35)

  return (
    <div
      aria-hidden="true"
      className="pointer-events-none absolute inset-0 -z-10 opacity-35"
    >
      <FlagCanvas wind={wind} backdrop />
    </div>
  )
}
