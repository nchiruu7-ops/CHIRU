import { cn } from '@/lib/utils'

const petals = [0, 45, 90, 135, 180, 225, 270, 315]

export function HeritageArch({
  className,
  mirrored = false,
}: {
  className?: string
  mirrored?: boolean
}) {
  return (
    <svg
      aria-hidden="true"
      viewBox="0 0 200 320"
      fill="none"
      stroke="currentColor"
      strokeLinecap="round"
      className={cn('pointer-events-none', mirrored && '-scale-x-100', className)}
    >
      <path d="M24 320V132C24 72 60 32 100 32S176 72 176 132V320" strokeWidth="2" />
      <path d="M42 320V138C42 92 66 60 100 60S158 92 158 138V320" strokeWidth="1" opacity="0.6" />
      <path d="M8 320H192" strokeWidth="2" />
      <rect x="10" y="150" width="10" height="170" strokeWidth="1.5" />
      <rect x="180" y="150" width="10" height="170" strokeWidth="1.5" />
      <path d="M100 6v26M88 16h24" strokeWidth="1.5" />
      <circle cx="100" cy="112" r="10" strokeWidth="1.2" opacity="0.7" />
      <circle cx="100" cy="112" r="3" fill="currentColor" stroke="none" />
    </svg>
  )
}

export function HeritageDivider({ className }: { className?: string }) {
  return (
    <div aria-hidden="true" className={cn('flex items-center gap-4', className)}>
      <span className="h-px flex-1 bg-gradient-to-r from-transparent to-flag-yellow/70" />
      <svg
        viewBox="0 0 160 40"
        fill="none"
        stroke="currentColor"
        strokeWidth="1.2"
        className="h-8 w-40 shrink-0 text-flag-yellow"
      >
        <circle cx="80" cy="20" r="6" />
        <circle cx="80" cy="20" r="14" opacity="0.6" />
        {petals.map((a) => (
          <ellipse key={a} cx="80" cy="9" rx="3.5" ry="7" transform={`rotate(${a} 80 20)`} opacity="0.8" />
        ))}
        <path d="M0 20H56M104 20H160" opacity="0.5" />
        <path d="M56 20l6-4 6 4-6 4z" fill="currentColor" stroke="none" />
        <path d="M104 20l-6-4-6 4 6 4z" fill="currentColor" stroke="none" />
      </svg>
      <span className="h-px flex-1 bg-gradient-to-l from-transparent to-flag-red/70" />
    </div>
  )
}
