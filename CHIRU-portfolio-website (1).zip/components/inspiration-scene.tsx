'use client'

import { Volume2, VolumeOff } from 'lucide-react'
import { useEffect, useRef, useState } from 'react'

export type SceneVariant =
  | 'ai-temple'
  | 'motion-ribbons'
  | 'print-collateral'
  | 'brand-kit'
  | 'mascot'
  | 'sneaker'
  | 'poster'
  | 'circuit'

type Painter = (ctx: CanvasRenderingContext2D, t: number, dt: number) => void
type Factory = (w: number, h: number) => Painter
type Pt = { x: number; y: number }

const INK = '#121214'
const YELLOW = '#ffc20e'
const RED = '#d62828'
const CREAM = '#fff4d6'

const rand = (a: number, b: number) => a + Math.random() * (b - a)
const clamp = (v: number, lo: number, hi: number) => Math.min(hi, Math.max(lo, v))
const easeOutCubic = (x: number) => 1 - Math.pow(1 - clamp(x, 0, 1), 3)

function pointAlong(pts: Pt[], lens: number[], total: number, d: number): Pt {
  let rest = ((d % total) + total) % total
  for (let i = 0; i < lens.length; i++) {
    if (rest <= lens[i]) {
      const f = lens[i] === 0 ? 0 : rest / lens[i]
      return {
        x: pts[i].x + (pts[i + 1].x - pts[i].x) * f,
        y: pts[i].y + (pts[i + 1].y - pts[i].y) * f,
      }
    }
    rest -= lens[i]
  }
  return pts[pts.length - 1]
}

function drawTemple(ctx: CanvasRenderingContext2D, cx: number, baseY: number, size: number) {
  const W = size
  const H = size * 1.1
  ctx.fillStyle = '#050405'
  ctx.strokeStyle = YELLOW
  ctx.lineWidth = Math.max(1.5, size * 0.006)
  ctx.beginPath()
  ctx.rect(cx - W * 0.5, baseY - H * 0.08, W, H * 0.08)
  ctx.rect(cx - W * 0.4, baseY - H * 0.3, W * 0.8, H * 0.22)
  ctx.rect(cx - W * 0.3, baseY - H * 0.55, W * 0.6, H * 0.25)
  ctx.moveTo(cx - W * 0.45, baseY - H * 0.55)
  ctx.lineTo(cx, baseY - H * 0.74)
  ctx.lineTo(cx + W * 0.45, baseY - H * 0.55)
  ctx.lineTo(cx + W * 0.45, baseY - H * 0.58)
  ctx.lineTo(cx, baseY - H * 0.78)
  ctx.lineTo(cx - W * 0.45, baseY - H * 0.58)
  ctx.closePath()
  ctx.rect(cx - W * 0.03, baseY - H * 1.0, W * 0.06, H * 0.3)
  ctx.fill()
  ctx.fillStyle = 'rgba(255,194,14,0.22)'
  for (let i = 0; i < 6; i++) {
    const x = cx - W * 0.36 + (i * W * 0.72) / 5
    ctx.fillRect(x - W * 0.02, baseY - H * 0.3, W * 0.04, -H * 0.22)
  }
  ctx.fillStyle = '#050405'
  ctx.beginPath()
  ctx.arc(cx, baseY - H * 1.02, W * 0.035, 0, Math.PI * 2)
  ctx.fillStyle = YELLOW
  ctx.fill()
}

const aiTemple: Factory = (w, h) => {
  type Ember = { x: number; y: number; vy: number; r: number; phase: number; life: number; max: number }
  const spawn = (fromBottom: boolean): Ember => {
    const max = rand(3, 7)
    return {
      x: rand(0, w),
      y: fromBottom ? h + rand(0, h * 0.2) : rand(0, h),
      vy: -rand(40, 110),
      r: rand(0.8, 2.4),
      phase: rand(0, Math.PI * 2),
      life: max,
      max,
    }
  }
  const embers = Array.from({ length: 60 }, () => spawn(false))
  const size = Math.min(w * 0.55, h * 0.7)
  return (ctx, t, dt) => {
    const sky = ctx.createLinearGradient(0, 0, 0, h)
    sky.addColorStop(0, '#0b0a0c')
    sky.addColorStop(0.7, '#3a0f10')
    sky.addColorStop(1, '#8a1d1a')
    ctx.fillStyle = sky
    ctx.fillRect(0, 0, w, h)

    const pulse = 0.85 + Math.sin(t * 1.4) * 0.08
    const sun = ctx.createRadialGradient(w / 2, h * 0.58, 0, w / 2, h * 0.58, size * 0.9 * pulse)
    sun.addColorStop(0, 'rgba(255,194,14,0.55)')
    sun.addColorStop(1, 'rgba(255,194,14,0)')
    ctx.fillStyle = sun
    ctx.fillRect(0, 0, w, h)

    const rise = (1 - easeOutCubic(t / 1.8)) * h * 0.25
    const bob = Math.sin(t * 1.2) * 2
    drawTemple(ctx, w / 2, h * 0.88 + rise + bob, size)

    for (const e of embers) {
      e.life -= dt
      e.vy += (-30 - e.vy) * 0.4 * dt
      e.y += e.vy * dt
      e.x += Math.sin(t * 2 + e.phase) * 14 * dt
      if (e.life <= 0 || e.y < -10) Object.assign(e, spawn(true))
      const a = clamp(e.life / e.max, 0, 1)
      ctx.beginPath()
      ctx.arc(e.x, e.y, e.r, 0, Math.PI * 2)
      ctx.fillStyle = `rgba(255,${180 + Math.round(60 * a)},60,${(0.25 + 0.7 * a).toFixed(2)})`
      ctx.fill()
    }
  }
}

const motionRibbons: Factory = (w, h) => {
  const N = 28
  const ribbons = Array.from({ length: 5 }, (_, r) => ({
    pts: Array.from({ length: N }, (_, i) => ({ x: (i / (N - 1)) * w, y: h / 2 + r * 6, vy: 0 })),
    phase: r * 0.7,
    gap: (r - 2) * (h * 0.08),
    color: r % 2 === 0 ? YELLOW : RED,
  }))
  return (ctx, t, dt) => {
    ctx.fillStyle = INK
    ctx.fillRect(0, 0, w, h)
    for (const rb of ribbons) {
      for (let i = 0; i < N; i++) {
        const p = rb.pts[i]
        const drive = Math.sin(i * 0.32 - t * 2.2 + rb.phase) * h * 0.14
        const target = h / 2 + rb.gap + drive * Math.sin(Math.PI * (i / (N - 1)) + 0.3)
        p.vy += (target - p.y) * 60 * dt
        p.vy *= Math.exp(-4 * dt)
        p.y += p.vy * dt
      }
      for (let iter = 0; iter < 3; iter++) {
        for (let i = 1; i < N - 1; i++) {
          const mid = (rb.pts[i - 1].y + rb.pts[i + 1].y) / 2
          rb.pts[i].y += (mid - rb.pts[i].y) * 0.5
        }
      }
      const grad = ctx.createLinearGradient(0, 0, w, 0)
      grad.addColorStop(0, rb.color)
      grad.addColorStop(1, rb.color === YELLOW ? RED : YELLOW)
      ctx.lineJoin = 'round'
      ctx.lineCap = 'round'
      ctx.strokeStyle = grad
      ctx.globalAlpha = 0.25
      ctx.lineWidth = Math.max(18, h * 0.12)
      ctx.beginPath()
      rb.pts.forEach((p, i) => (i ? ctx.lineTo(p.x, p.y) : ctx.moveTo(p.x, p.y)))
      ctx.stroke()
      ctx.globalAlpha = 1
      ctx.lineWidth = Math.max(5, h * 0.03)
      ctx.stroke()
    }
  }
}

const printCollateral: Factory = (w, h) => {
  type Card = { x: number; y: number; vy: number; rot: number; vr: number; rest: number; restRot: number; hue: string }
  const cardW = Math.min(w * 0.2, 170)
  const cardH = cardW * 1.4
  const ground = h * 0.84
  const slots = [0.3, 0.5, 0.7]
  const hues = [YELLOW, RED, INK]
  let cards: Card[] = []
  let nextSpawn = 0.4
  let holdUntil = 0

  const drawCard = (ctx: CanvasRenderingContext2D, c: Card) => {
    ctx.save()
    ctx.translate(c.x, c.y)
    ctx.rotate(c.rot)
    ctx.shadowColor = 'rgba(0,0,0,0.45)'
    ctx.shadowBlur = 14
    ctx.shadowOffsetY = 6
    ctx.fillStyle = CREAM
    ctx.fillRect(-cardW / 2, -cardH / 2, cardW, cardH)
    ctx.shadowColor = 'transparent'
    ctx.fillStyle = c.hue
    ctx.fillRect(-cardW / 2, -cardH / 2, cardW, cardH * 0.34)
    ctx.fillStyle = 'rgba(18,18,20,0.75)'
    for (let i = 0; i < 6; i++) {
      const lw = cardW * (i % 3 === 2 ? 0.4 : 0.7)
      ctx.fillRect(-cardW / 2 + cardW * 0.1, -cardH / 2 + cardH * (0.45 + i * 0.08), lw, cardH * 0.02)
    }
    ctx.restore()
  }

  return (ctx, t, dt) => {
    ctx.fillStyle = INK
    ctx.fillRect(0, 0, w, h)
    ctx.strokeStyle = 'rgba(255,244,214,0.06)'
    ctx.lineWidth = 1
    for (let x = 0; x < w; x += 28) {
      ctx.beginPath()
      ctx.moveTo(x, 0)
      ctx.lineTo(x, h)
      ctx.stroke()
    }

    if (cards.length >= 12) {
      if (!holdUntil) holdUntil = t + 2.4
      if (t > holdUntil) {
        cards = []
        holdUntil = 0
        nextSpawn = t + 0.4
      }
    } else if (t >= nextSpawn) {
      const n = cards.length
      const slot = n % 3
      const level = Math.floor(n / 3)
      const rest = ground - cardH / 2 - level * cardH * 0.14
      cards.push({
        x: w * slots[slot],
        y: -cardH,
        vy: rand(0, 120),
        rot: rand(-0.7, 0.7),
        vr: rand(-1, 1),
        rest,
        restRot: rand(-0.06, 0.06),
        hue: hues[n % hues.length],
      })
      nextSpawn = t + 0.85
    }

    ctx.fillStyle = 'rgba(0,0,0,0.5)'
    ctx.beginPath()
    ctx.ellipse(w / 2, ground + 6, w * 0.4, 8, 0, 0, Math.PI * 2)
    ctx.fill()

    for (const c of cards) {
      c.vy += 2000 * dt
      c.y += c.vy * dt
      if (c.y >= c.rest) {
        c.y = c.rest
        if (c.vy > 0) c.vy = Math.abs(c.vy) < 120 ? 0 : -c.vy * 0.36
      }
      c.vr += (-(c.rot - c.restRot) * 40 - c.vr * 5) * dt
      c.rot += c.vr * dt
      drawCard(ctx, c)
    }
  }
}

const brandKit: Factory = (w, h) => {
  type Piece = { kind: 'square' | 'circle' | 'tri' | 'bar'; x: number; y: number; vx: number; vy: number; r: number; vr: number; tx: number; ty: number; tr: number; sx: number; sy: number; ar: number }
  const S = Math.min(w, h) * 0.34
  const layout: { kind: Piece['kind']; x: number; y: number; ar: number; fill: string }[] = [
    { kind: 'square', x: -S * 0.25, y: -S * 0.25, ar: 0, fill: YELLOW },
    { kind: 'circle', x: S * 0.25, y: -S * 0.25, ar: 0, fill: RED },
    { kind: 'tri', x: -S * 0.25, y: S * 0.25, ar: 0, fill: CREAM },
    { kind: 'bar', x: S * 0.25, y: S * 0.25, ar: 0, fill: YELLOW },
  ]
  const pieces: Piece[] = layout.map((l, i) => {
    const side = i % 2 === 0 ? -1 : 1
    const sx = side * w * 0.7
    const sy = (i < 2 ? -1 : 1) * h * 0.7
    return {
      kind: l.kind,
      x: sx,
      y: sy,
      vx: 0,
      vy: 0,
      r: rand(-3, 3),
      vr: 0,
      tx: sx,
      ty: sy,
      tr: rand(-3, 3),
      sx,
      sy,
      ar: rand(-3, 3),
    }
  })
  let assembled = false
  const fills = layout.map((l) => l.fill)
  const k = 110
  const c = 11

  return (ctx, t, dt) => {
    const cycle = t % 9
    const want = cycle > 1.2 && cycle < 6.6
    if (want !== assembled) {
      assembled = want
      pieces.forEach((p, i) => {
        if (assembled) {
          p.tx = layout[i].x
          p.ty = layout[i].y
          p.tr = 0
        } else {
          p.tx = p.sx
          p.ty = p.sy
          p.tr = p.ar
        }
      })
    }

    ctx.fillStyle = INK
    ctx.fillRect(0, 0, w, h)
    ctx.strokeStyle = 'rgba(255,194,14,0.08)'
    for (let x = 0; x < w; x += 36) {
      ctx.beginPath()
      ctx.moveTo(x, 0)
      ctx.lineTo(x, h)
      ctx.stroke()
    }

    const cx = w / 2
    const cy = h * 0.46
    pieces.forEach((p, i) => {
      p.vx += (-(p.x - p.tx) * k - p.vx * c) * dt
      p.vy += (-(p.y - p.ty) * k - p.vy * c) * dt
      p.vr += (-(p.r - p.tr) * k * 0.8 - p.vr * c) * dt
      p.x += p.vx * dt
      p.y += p.vy * dt
      p.r += p.vr * dt

      ctx.save()
      ctx.translate(cx + p.x, cy + p.y)
      ctx.rotate(p.r)
      ctx.fillStyle = fills[i]
      ctx.strokeStyle = YELLOW
      ctx.lineWidth = 2
      if (p.kind === 'square') {
        ctx.fillRect(-S * 0.22, -S * 0.22, S * 0.44, S * 0.44)
      } else if (p.kind === 'circle') {
        ctx.beginPath()
        ctx.arc(0, 0, S * 0.22, 0, Math.PI * 2)
        ctx.fill()
      } else if (p.kind === 'tri') {
        ctx.beginPath()
        ctx.moveTo(-S * 0.25, S * 0.22)
        ctx.lineTo(S * 0.25, S * 0.22)
        ctx.lineTo(0, -S * 0.26)
        ctx.closePath()
        ctx.fill()
      } else {
        ctx.fillRect(-S * 0.28, -S * 0.08, S * 0.56, S * 0.16)
      }
      ctx.restore()
    })

    const captionAlpha = clamp((cycle - 1.6) / 0.8, 0, 1) * clamp((7.2 - cycle) / 0.6, 0, 1)
    ctx.globalAlpha = captionAlpha
    ctx.fillStyle = CREAM
    ctx.font = `800 ${Math.max(12, Math.min(w * 0.05, 26))}px system-ui, sans-serif`
    ctx.textAlign = 'center'
    ctx.fillText('CHIRU  ·  BRAND KIT', cx, cy + S * 0.7)
    ctx.globalAlpha = 1
  }
}

const mascot: Factory = (w, h) => {
  const R = Math.min(w, h) * 0.17
  const floor = h * 0.8
  const restY = floor - R
  let y = restY
  let vy = 0
  let d = 0
  let vd = 0
  let onGround = true
  let nextHop = 0.6
  let blinkIn = 2.4
  let blinkT = 0
  const dust: { x: number; y: number; vx: number; vy: number; life: number }[] = []

  return (ctx, t, dt) => {
    const bg = ctx.createLinearGradient(0, 0, 0, h)
    bg.addColorStop(0, '#1d1b20')
    bg.addColorStop(1, '#0d0d0f')
    ctx.fillStyle = bg
    ctx.fillRect(0, 0, w, h)
    ctx.fillStyle = 'rgba(255,194,14,0.08)'
    ctx.fillRect(0, floor, w, h - floor)

    if (onGround && t >= nextHop) {
      vy = -rand(950, 1150)
      onGround = false
      d = -0.12
      nextHop = t + rand(0.9, 1.3)
    }
    vy += 2400 * dt
    y += vy * dt
    if (y >= restY) {
      y = restY
      if (!onGround) {
        d = 0.32
        vd = 0
        for (let i = 0; i < 10; i++) {
          dust.push({ x: w / 2 + rand(-R, R), y: floor, vx: rand(-160, 160), vy: rand(-220, -60), life: 0.6 })
        }
      }
      vy = 0
      onGround = true
    }

    const target = vy < -200 ? -0.12 : 0
    vd += (-(d - target) * 150 - vd * 12) * dt
    d += vd * dt

    const hn = clamp((restY - y) / (h * 0.45), 0, 1)
    ctx.fillStyle = 'rgba(0,0,0,0.45)'
    ctx.beginPath()
    ctx.ellipse(w / 2, floor, R * (1.05 - 0.45 * hn), R * 0.16 * (1 - 0.4 * hn), 0, 0, Math.PI * 2)
    ctx.fill()

    for (const p of dust) {
      p.life -= dt
      p.vy += 900 * dt
      p.x += p.vx * dt
      p.y += p.vy * dt
      if (p.y > floor) {
        p.y = floor
        p.vy = 0
      }
      ctx.globalAlpha = clamp(p.life / 0.6, 0, 1) * 0.6
      ctx.fillStyle = CREAM
      ctx.beginPath()
      ctx.arc(p.x, p.y, 4, 0, Math.PI * 2)
      ctx.fill()
    }
    ctx.globalAlpha = 1
    for (let i = dust.length - 1; i >= 0; i--) if (dust[i].life <= 0) dust.splice(i, 1)

    blinkIn -= dt
    if (blinkIn <= 0) {
      blinkT += dt
      if (blinkT > 0.14) {
        blinkT = 0
        blinkIn = rand(2, 4)
      }
    }

    const sx = 1 + d * 0.6
    const sy = 1 - d
    ctx.save()
    ctx.translate(w / 2, y)
    ctx.scale(sx, sy)
    const body = ctx.createRadialGradient(-R * 0.3, -R * 0.4, R * 0.1, 0, 0, R)
    body.addColorStop(0, YELLOW)
    body.addColorStop(1, RED)
    ctx.fillStyle = body
    ctx.beginPath()
    ctx.arc(0, 0, R, 0, Math.PI * 2)
    ctx.fill()

    const look = Math.sin(t * 0.8) * R * 0.08
    const eyeOpen = blinkT > 0 ? 0.15 : 1
    ctx.fillStyle = INK
    for (const ex of [-R * 0.35, R * 0.35]) {
      ctx.save()
      ctx.translate(ex, -R * 0.15)
      ctx.scale(1, eyeOpen)
      ctx.beginPath()
      ctx.arc(0, 0, R * 0.14, 0, Math.PI * 2)
      ctx.fill()
      ctx.restore()
      if (eyeOpen > 0.5) {
        ctx.fillStyle = '#fff'
        ctx.beginPath()
        ctx.arc(ex + look + R * 0.05, -R * 0.2, R * 0.05, 0, Math.PI * 2)
        ctx.fill()
        ctx.fillStyle = INK
      }
    }
    ctx.strokeStyle = INK
    ctx.lineWidth = R * 0.08
    ctx.lineCap = 'round'
    ctx.beginPath()
    ctx.arc(0, R * 0.12, R * 0.3, 0.15 * Math.PI, 0.85 * Math.PI)
    ctx.stroke()
    ctx.restore()
  }
}

const sneaker: Factory = (w, h) => {
  const scale = Math.min(w, h) / 220
  const ground = h * 0.78
  const dust: { x: number; y: number; vx: number; life: number }[] = []
  const lines = Array.from({ length: 12 }, () => ({ y: rand(0.2, 0.7) * h, len: rand(0.1, 0.3) * w, off: rand(0, 1) }))

  const shoe = (ctx: CanvasRenderingContext2D) => {
    ctx.beginPath()
    ctx.moveTo(-95, 30)
    ctx.lineTo(-95, -15)
    ctx.quadraticCurveTo(-90, -45, -55, -45)
    ctx.quadraticCurveTo(-30, -30, -10, -10)
    ctx.quadraticCurveTo(20, 0, 40, -5)
    ctx.quadraticCurveTo(70, 0, 95, 15)
    ctx.lineTo(95, 30)
    ctx.closePath()
  }

  return (ctx, t, dt) => {
    const bg = ctx.createLinearGradient(0, 0, w, h)
    bg.addColorStop(0, '#2a0708')
    bg.addColorStop(1, INK)
    ctx.fillStyle = bg
    ctx.fillRect(0, 0, w, h)

    const travel = ((t * 0.16) % 1.3) - 0.15
    const x = travel * w
    const bounce = Math.abs(Math.sin(t * 4.2))
    const lift = bounce * h * 0.14
    const cy = ground - lift

    ctx.strokeStyle = 'rgba(255,194,14,0.35)'
    ctx.lineWidth = 2
    for (const l of lines) {
      const lx = ((l.off - t * 0.6) % 1 + 1) % 1 * w
      ctx.beginPath()
      ctx.moveTo(lx, l.y)
      ctx.lineTo(lx - l.len, l.y)
      ctx.stroke()
    }

    ctx.fillStyle = 'rgba(0,0,0,0.5)'
    ctx.beginPath()
    ctx.ellipse(x, ground + 14 * scale, 110 * scale * (1 - 0.35 * lift / (h * 0.14)), 9 * scale, 0, 0, Math.PI * 2)
    ctx.fill()

    if (bounce < 0.06 && Math.random() < 0.6) {
      dust.push({ x: x - 60 * scale, y: ground + 10 * scale, vx: -rand(40, 110), life: 0.7 })
    }
    for (const p of dust) {
      p.life -= dt
      p.x += p.vx * dt
      p.vx *= 0.96
      ctx.globalAlpha = clamp(p.life / 0.7, 0, 1) * 0.5
      ctx.fillStyle = CREAM
      ctx.beginPath()
      ctx.arc(p.x, ground + 6 * scale, 5 * scale, 0, Math.PI * 2)
      ctx.fill()
    }
    ctx.globalAlpha = 1
    for (let i = dust.length - 1; i >= 0; i--) if (dust[i].life <= 0) dust.splice(i, 1)

    for (const ghost of [2, 1]) {
      ctx.save()
      ctx.globalAlpha = 0.12 * ghost
      ctx.translate(x - ghost * 18 * scale, cy)
      ctx.scale(scale, scale)
      ctx.fillStyle = RED
      shoe(ctx)
      ctx.fill()
      ctx.restore()
    }

    ctx.save()
    ctx.translate(x, cy)
    ctx.rotate(-lift * 0.004)
    ctx.scale(scale, scale)
    ctx.fillStyle = YELLOW
    shoe(ctx)
    ctx.fill()
    ctx.fillStyle = RED
    ctx.fillRect(-95, 22, 190, 14)
    ctx.strokeStyle = INK
    ctx.lineWidth = 4
    ctx.beginPath()
    ctx.moveTo(-40, -20)
    ctx.lineTo(-5, -2)
    ctx.moveTo(-25, -10)
    ctx.lineTo(0, 8)
    ctx.stroke()
    ctx.restore()
  }
}

const poster: Factory = (w, h) => {
  const cx = w / 2
  const cy = h * 0.46
  const rays = 28
  const size = Math.min(w * 0.2, h * 0.24)
  const fontSize = Math.min(w * 0.17, h * 0.26)
  return (ctx, t) => {
    ctx.fillStyle = INK
    ctx.fillRect(0, 0, w, h)
    const reach = Math.hypot(w, h)
    const spin = t * 0.25
    for (let i = 0; i < rays; i++) {
      const a0 = spin + (i / rays) * Math.PI * 2
      const a1 = a0 + Math.PI / rays
      ctx.fillStyle = i % 2 === 0 ? 'rgba(214,40,40,0.5)' : 'rgba(255,194,14,0.2)'
      ctx.beginPath()
      ctx.moveTo(cx, cy)
      ctx.lineTo(cx + Math.cos(a0) * reach, cy + Math.sin(a0) * reach)
      ctx.lineTo(cx + Math.cos(a1) * reach, cy + Math.sin(a1) * reach)
      ctx.closePath()
      ctx.fill()
    }

    const pop = easeOutCubic(t / 1.1)
    const pulse = 1 + Math.sin(t * 2.4) * 0.03
    ctx.save()
    ctx.translate(cx, cy)
    ctx.scale(pop * pulse, pop * pulse)
    ctx.fillStyle = YELLOW
    ctx.beginPath()
    ctx.arc(0, 0, size, 0, Math.PI * 2)
    ctx.fill()
    ctx.restore()

    ctx.save()
    ctx.translate(cx, cy + h * 0.36)
    ctx.scale(pop, pop)
    ctx.fillStyle = CREAM
    ctx.textAlign = 'center'
    ctx.textBaseline = 'middle'
    ctx.font = `900 ${fontSize}px "Arial Black", system-ui, sans-serif`
    ctx.fillText('PALACE', 0, 0)
    ctx.restore()
  }
}

const circuit: Factory = (w, h) => {
  const cols = 14
  const rows = 8
  const gx = w / cols
  const gy = h / rows
  const traces = Array.from({ length: 9 }, () => {
    let cx = Math.floor(rand(0, cols))
    let cy = Math.floor(rand(0, rows))
    const pts: Pt[] = [{ x: (cx + 0.5) * gx, y: (cy + 0.5) * gy }]
    for (let s = 0; s < 6; s++) {
      const step = Math.floor(rand(1, 4)) * (Math.random() < 0.5 ? -1 : 1)
      if (s % 2 === 0) cx = clamp(cx + step, 0, cols - 1)
      else cy = clamp(cy + step, 0, rows - 1)
      pts.push({ x: (cx + 0.5) * gx, y: (cy + 0.5) * gy })
    }
    const lens = pts.slice(1).map((p, i) => Math.hypot(p.x - pts[i].x, p.y - pts[i].y))
    return { pts, lens, total: lens.reduce((a, b) => a + b, 0), speed: rand(0.12, 0.22), phase: Math.random() }
  })
  const nodes = traces.flatMap((tr) => tr.pts)
  return (ctx, t) => {
    ctx.fillStyle = INK
    ctx.fillRect(0, 0, w, h)
    for (const tr of traces) {
      ctx.strokeStyle = 'rgba(255,194,14,0.18)'
      ctx.lineWidth = 2
      ctx.beginPath()
      tr.pts.forEach((p, i) => (i ? ctx.lineTo(p.x, p.y) : ctx.moveTo(p.x, p.y)))
      ctx.stroke()

      const progress = (tr.phase + t * tr.speed) % 1
      const head = pointAlong(tr.pts, tr.lens, tr.total, progress * tr.total)
      const tail = pointAlong(tr.pts, tr.lens, tr.total, progress * tr.total - tr.total * 0.18)
      const trail = ctx.createLinearGradient(tail.x, tail.y, head.x, head.y)
      trail.addColorStop(0, 'rgba(214,40,40,0)')
      trail.addColorStop(1, 'rgba(255,194,14,0.95)')
      ctx.strokeStyle = trail
      ctx.lineWidth = 3
      ctx.beginPath()
      ctx.moveTo(tail.x, tail.y)
      ctx.lineTo(head.x, head.y)
      ctx.stroke()
      ctx.fillStyle = YELLOW
      ctx.beginPath()
      ctx.arc(head.x, head.y, 4, 0, Math.PI * 2)
      ctx.fill()
    }
    ctx.fillStyle = 'rgba(255,244,214,0.25)'
    for (const p of nodes) {
      ctx.beginPath()
      ctx.arc(p.x, p.y, 3, 0, Math.PI * 2)
      ctx.fill()
    }
  }
}

const FACTORIES: Record<SceneVariant, Factory> = {
  'ai-temple': aiTemple,
  'motion-ribbons': motionRibbons,
  'print-collateral': printCollateral,
  'brand-kit': brandKit,
  mascot,
  sneaker,
  poster,
  circuit,
}

type Ambience = { ctx: AudioContext; gain: GainNode }

function startAmbience(): Ambience {
  const ctx = new AudioContext()
  const buffer = ctx.createBuffer(1, ctx.sampleRate * 2, ctx.sampleRate)
  const data = buffer.getChannelData(0)
  let last = 0
  for (let i = 0; i < data.length; i++) {
    last = (last + 0.02 * (Math.random() * 2 - 1)) / 1.02
    data[i] = last * 3.5
  }
  const noise = ctx.createBufferSource()
  noise.buffer = buffer
  noise.loop = true
  const filter = ctx.createBiquadFilter()
  filter.type = 'lowpass'
  filter.frequency.value = 500
  const lfo = ctx.createOscillator()
  lfo.frequency.value = 0.08
  const lfoGain = ctx.createGain()
  lfoGain.gain.value = 180
  lfo.connect(lfoGain)
  lfoGain.connect(filter.frequency)
  const drone = ctx.createOscillator()
  drone.frequency.value = 110
  const droneGain = ctx.createGain()
  droneGain.gain.value = 0.04
  drone.connect(droneGain)
  const gain = ctx.createGain()
  gain.gain.value = 0
  noise.connect(filter)
  filter.connect(gain)
  droneGain.connect(gain)
  gain.connect(ctx.destination)
  noise.start()
  drone.start()
  lfo.start()
  gain.gain.linearRampToValueAtTime(0.22, ctx.currentTime + 1.5)
  return { ctx, gain }
}

export function InspirationScene({
  variant,
  label,
  poster,
  showSound = true,
  className = '',
}: {
  variant: SceneVariant
  label?: string
  poster?: string
  showSound?: boolean
  className?: string
}) {
  const wrapRef = useRef<HTMLDivElement>(null)
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const ambienceRef = useRef<Ambience | null>(null)
  const [ready, setReady] = useState(false)
  const [soundOn, setSoundOn] = useState(false)

  useEffect(() => {
    const wrap = wrapRef.current
    const canvas = canvasRef.current
    if (!wrap || !canvas) return
    const ctx = canvas.getContext('2d')
    if (!ctx) return

    const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches
    const factory = FACTORIES[variant]
    let painter: Painter | null = null
    let visible = true
    let raf = 0
    let last = 0
    let t = 0
    let announced = false

    const resize = () => {
      const rect = wrap.getBoundingClientRect()
      const dpr = Math.min(window.devicePixelRatio || 1, 2)
      canvas.width = Math.max(1, Math.round(rect.width * dpr))
      canvas.height = Math.max(1, Math.round(rect.height * dpr))
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0)
      painter = factory(rect.width, rect.height)
      if (reduced) {
        for (let i = 0; i < 240; i++) painter(ctx, i / 60, 1 / 60)
        setReady(true)
      }
    }

    const frame = (now: number) => {
      raf = requestAnimationFrame(frame)
      const dt = last ? Math.min(0.05, (now - last) / 1000) : 1 / 60
      last = now
      if (!visible || !painter) return
      t += dt
      painter(ctx, t, dt)
      if (!announced) {
        announced = true
        setReady(true)
      }
    }

    resize()
    const ro = new ResizeObserver(resize)
    ro.observe(wrap)
    const io = new IntersectionObserver(([entry]) => {
      visible = entry.isIntersecting
    })
    io.observe(wrap)
    if (!reduced) raf = requestAnimationFrame(frame)

    return () => {
      cancelAnimationFrame(raf)
      ro.disconnect()
      io.disconnect()
    }
  }, [variant])

  useEffect(() => {
    return () => {
      void ambienceRef.current?.ctx.close()
      ambienceRef.current = null
    }
  }, [])

  const toggleSound = () => {
    if (!soundOn) {
      if (!ambienceRef.current) ambienceRef.current = startAmbience()
      else {
        const { ctx, gain } = ambienceRef.current
        void ctx.resume()
        gain.gain.cancelScheduledValues(ctx.currentTime)
        gain.gain.linearRampToValueAtTime(0.22, ctx.currentTime + 0.6)
      }
    } else if (ambienceRef.current) {
      const { ctx, gain } = ambienceRef.current
      gain.gain.cancelScheduledValues(ctx.currentTime)
      gain.gain.linearRampToValueAtTime(0, ctx.currentTime + 0.4)
    }
    setSoundOn(!soundOn)
  }

  return (
    <div
      ref={wrapRef}
      role={label ? 'img' : undefined}
      aria-label={label}
      aria-hidden={label ? undefined : true}
      className={`relative overflow-hidden bg-black ${className}`}
    >
      {poster ? (
        // eslint-disable-next-line @next/next/no-img-element
        <img
          src={poster}
          alt=""
          aria-hidden="true"
          className="absolute inset-0 size-full object-cover"
        />
      ) : null}
      <canvas
        ref={canvasRef}
        aria-hidden="true"
        className={`absolute inset-0 size-full transition-opacity duration-700 ${ready ? 'opacity-100' : 'opacity-0'}`}
      />
      {showSound ? (
        <button
          type="button"
          onClick={toggleSound}
          aria-pressed={soundOn}
          aria-label={soundOn ? 'Mute scene sound' : 'Play scene sound'}
          className="absolute bottom-3 right-3 z-10 flex size-10 items-center justify-center rounded-full border border-white/15 bg-black/60 text-white backdrop-blur transition-colors hover:border-flag-yellow hover:text-flag-yellow"
        >
          {soundOn ? <Volume2 className="size-4" /> : <VolumeOff className="size-4" />}
        </button>
      ) : null}
    </div>
  )
}
