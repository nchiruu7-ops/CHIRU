import { tools } from '@/lib/site'

export function ToolMarquee() {
  const row = [...tools, ...tools]
  return (
    <div
      className="relative z-10 overflow-hidden border-y border-border bg-charcoal-2 py-5"
      aria-label={`Tools I use: ${tools.join(', ')}`}
    >
      <div className="flex w-max animate-marquee items-center gap-12 hover:[animation-play-state:paused]" aria-hidden="true">
        {row.map((t, i) => (
          <span
            key={`${t}-${i}`}
            className="flex items-center gap-12 font-display text-2xl font-bold text-foreground/70"
          >
            {t}
            <span className="size-2 rotate-45 bg-flag-yellow" />
          </span>
        ))}
      </div>
    </div>
  )
}
