import { Mail } from 'lucide-react'
import { PrivacyChoicesButton } from '@/components/analytics-consent'
import Link from 'next/link'
import { navLinks, site } from '@/lib/site'

export function SiteFooter() {
  return (
    <footer className="relative z-10 mt-24 border-t border-border bg-charcoal-2">
      <div className="h-2 w-full bg-flag-stripe" aria-hidden="true" />
      <div className="mx-auto grid max-w-7xl gap-10 px-5 py-14 md:grid-cols-2 md:px-8 xl:grid-cols-[1.25fr_1fr_1fr_1fr]">
        <div>
          <p className="font-kannada text-3xl font-extrabold text-flag-gradient">
            ಕರ್ನಾಟಕ
          </p>
          <p className="mt-3 font-display text-2xl font-bold">{site.name}</p>
          <p className="mt-2 max-w-sm text-sm leading-relaxed text-muted-foreground">
            {site.role}. AI content, motion graphics, online printing and DTP
            solutions.
          </p>
        </div>
        <nav aria-label="Footer">
          <p className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
            Pages
          </p>
          <ul className="mt-4 space-y-2">
            {navLinks.map((l) => (
              <li key={l.href}>
                <Link
                  href={l.href}
                  className="text-sm transition-colors hover:text-flag-yellow"
                >
                  {l.label}
                  {l.href === '/contact' && '+91 7204868185 Feel Free To Connect For Detailed Enquires'}
                </Link>
              </li>
            ))}
          </ul>
        </nav>
        <nav aria-label="Legal information">
          <p className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
            Legal & privacy
          </p>
          <ul className="mt-4 space-y-2">
            <li><Link href="/privacy" className="text-sm transition-colors hover:text-flag-yellow">Privacy notice</Link></li>
            <li><Link href="/terms" className="text-sm transition-colors hover:text-flag-yellow">Website terms</Link></li>
            <li><Link href="/cookies" className="text-sm transition-colors hover:text-flag-yellow">Cookie details</Link></li>
            <li><PrivacyChoicesButton /></li>
          </ul>
        </nav>
        <div>
          <p className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
            Say hello
          </p>
          <a
            href={`mailto:${site.email}`}
            className="mt-4 inline-flex items-center gap-2 break-all text-sm transition-colors hover:text-flag-yellow"
          >
            <Mail className="size-4 shrink-0" />
            {site.email}
          </a>
          <p className="mt-6 text-xs font-semibold uppercase tracking-widest text-muted-foreground">
            Welcome! I create stunning AI visuals and motion graphics that bring your ideas to life. Have a project in mind? Contact me through my website, and let’s get started.&nbsp;
          </p>
        </div>
      </div>
      <div className="border-t border-border py-5 text-center text-xs text-muted-foreground">
        &copy; {new Date().getFullYear()} {site.name} All rights reserved.
      </div>
    </footer>
  )
}
