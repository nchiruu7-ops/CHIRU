import Link from 'next/link'
import { ArrowRight, Check } from 'lucide-react'
import { LiveScene } from '@/components/live-scene'
import { PageHero } from '@/components/page-hero'
import { ProjectGallery } from '@/components/project-gallery'
import { Reveal } from '@/components/reveal'
import { projects } from '@/lib/projects'
import type { LiveSceneVariant } from '@/lib/scenes'

type ShowcaseKey = 'product' | 'brand' | 'strategy'

type Showcase = {
  eyebrow: string
  title: string
  accent: string
  text: string
  variant: LiveSceneVariant
  poster: string
  label: string
  services: string[]
  steps: { title: string; text: string }[]
  projectSlugs: string[]
  enquiryService: string
}

const showcases: Record<ShowcaseKey, Showcase> = {
  product: {
    eyebrow: 'Creative product promotion',
    title: 'Make the product',
    accent: 'the hero.',
    text: 'A product-first creative direction for launch visuals, short promotional clips and campaign-ready assets. The scene below is a generated 3D concept, not a client commission.',
    variant: 'product-spin',
    poster: '/projects/promo-reel.png',
    label: 'A product model rotates under studio lighting and rebounds after a display turn',
    services: ['Hero product visual', 'Short social promo', 'Launch poster and banner', 'Platform-ready crops'],
    steps: [
      { title: 'Brief', text: 'Share the product, audience, channels and launch date.' },
      { title: 'Art direction', text: 'Agree on the visual mood, key message and formats.' },
      { title: 'Create', text: 'Build the hero visual and adapt the motion or artwork.' },
      { title: 'Approve', text: 'Review a proof before final export and delivery.' },
    ],
    projectSlugs: ['sneaker-reel'],
    enquiryService: 'Creative product promotion',
  },
  brand: {
    eyebrow: 'Brand promotion',
    title: 'One identity,',
    accent: 'every touchpoint.',
    text: 'Bring a visual identity into everyday use across campaign graphics, stationery, social content and promotional assets. This live scene is a design study created for the site.',
    variant: 'brand-spotlight',
    poster: '/projects/brand-identity.png',
    label: 'A brand emblem turns beneath a light, with identity elements orbiting around it',
    services: ['Brand launch visuals', 'Campaign graphics', 'Social media asset sets', 'Stationery and merchandise mockups'],
    steps: [
      { title: 'Understand', text: 'Review the audience, existing identity and campaign goal.' },
      { title: 'Unify', text: 'Set a consistent palette, shape language and visual hierarchy.' },
      { title: 'Extend', text: 'Adapt the identity to print, digital and social formats.' },
      { title: 'Deliver', text: 'Prepare approved exports and production-ready files.' },
    ],
    projectSlugs: ['brand-kit'],
    enquiryService: 'Brand promotion',
  },
  strategy: {
    eyebrow: 'Brand strategy',
    title: 'Build a clear',
    accent: 'creative direction.',
    text: 'Turn a business goal into a practical visual brief: audience, positioning, message, channel and a consistent system for future work. This animated strategy scene is illustrative, not a client result.',
    variant: 'strategy-pillars',
    poster: '/projects/ai-character.png',
    label: 'Four rising pillars connect beneath a beam as a light travels across the strategy system',
    services: ['Audience and objective brief', 'Positioning and message direction', 'Campaign content plan', 'Visual identity recommendations'],
    steps: [
      { title: 'Listen', text: 'Share the business, audience and current challenge.' },
      { title: 'Focus', text: 'Choose a primary message and the action it should inspire.' },
      { title: 'Plan', text: 'Map the message to channels, formats and a usable schedule.' },
      { title: 'Create', text: 'Translate the direction into a visual system and first assets.' },
    ],
    projectSlugs: ['circuit-portrait', 'dawn-temple'],
    enquiryService: 'Brand strategy',
  },
}

export function OfferShowcase({ kind }: { kind: ShowcaseKey }) {
  const item = showcases[kind]
  const examples = item.projectSlugs
    .map((slug) => projects.find((project) => project.slug === slug))
    .filter((project): project is (typeof projects)[number] => Boolean(project))

  return (
    <>
      <PageHero eyebrow={item.eyebrow} title={item.title} accent={item.accent} text={item.text} />
      <section className="relative z-10 mx-auto max-w-7xl px-5 md:px-8">
        <Reveal>
          <LiveScene
            variant={item.variant}
            label={item.label}
            poster={item.poster}
            className="aspect-[16/9] w-full rounded-[2rem] border border-border md:aspect-[21/9]"
          />
        </Reveal>
        <div className="mt-12 grid gap-6 md:grid-cols-[1fr_1.2fr]">
          <Reveal>
            <article className="h-full rounded-3xl border border-border bg-card p-7 md:p-9">
              <h2 className="font-display text-2xl font-bold">What we can make</h2>
              <ul className="mt-6 space-y-3">
                {item.services.map((service) => (
                  <li key={service} className="flex items-start gap-3 text-sm leading-relaxed">
                    <Check className="mt-0.5 size-4 shrink-0 text-flag-yellow" />{service}
                  </li>
                ))}
              </ul>
            </article>
          </Reveal>
          <Reveal delay={100}>
            <article className="h-full rounded-3xl border border-border bg-card p-7 md:p-9">
              <h2 className="font-display text-2xl font-bold">A clear path from brief to delivery</h2>
              <ol className="mt-6 grid gap-4 sm:grid-cols-2">
                {item.steps.map((step, i) => (
                  <li key={step.title}>
                    <span className="font-display text-sm font-bold text-flag-yellow">0{i + 1}</span>
                    <h3 className="mt-1 font-semibold">{step.title}</h3>
                    <p className="mt-1 text-sm leading-relaxed text-muted-foreground">{step.text}</p>
                  </li>
                ))}
              </ol>
            </article>
          </Reveal>
        </div>
        {examples.length > 0 && (
          <div className="py-20">
            <div className="mb-8">
              <p className="text-sm font-semibold uppercase tracking-[0.2em] text-flag-yellow">Related concepts</p>
              <h2 className="mt-3 font-display text-3xl font-extrabold md:text-4xl">Explore the work</h2>
            </div>
            <ProjectGallery projects={examples} showFilters={false} />
          </div>
        )}
        <div className="mb-20 rounded-[2rem] bg-gradient-to-b from-flag-yellow to-flag-red p-8 text-charcoal md:flex md:items-center md:justify-between md:p-12">
          <div>
            <h2 className="font-display text-3xl font-extrabold">Have a brief in mind?</h2>
            <p className="mt-2 text-charcoal/80">Share your goals and preferred timeline to start a conversation.</p>
          </div>
          <Link href={`/contact?service=${encodeURIComponent(item.enquiryService)}`} className="mt-6 inline-flex items-center gap-2 rounded-full bg-charcoal px-7 py-4 font-semibold text-white md:mt-0">
            Start an enquiry <ArrowRight className="size-4" />
          </Link>
        </div>
      </section>
    </>
  )
}
