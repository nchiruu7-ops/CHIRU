'use client'

import { Eye, EyeOff } from 'lucide-react'
import Image from 'next/image'
import { useRef, useState } from 'react'
import { portraits } from '@/lib/site'
import { cn } from '@/lib/utils'

export function PortraitReveal({
  className,
  priority = false,
}: {
  className?: string
  priority?: boolean
}) {
  const [index, setIndex] = useState(0)
  const [full, setFull] = useState(false)
  const frame = useRef<HTMLDivElement>(null)
  const raf = useRef(0)
  const photo = portraits[index]

  function track(e: React.PointerEvent<HTMLDivElement>) {
    const el = frame.current
    if (!el) return
    const { clientX, clientY, pointerType } = e
    cancelAnimationFrame(raf.current)
    raf.current = requestAnimationFrame(() => {
      const r = el.getBoundingClientRect()
      const px = (clientX - r.left) / r.width
      const py = (clientY - r.top) / r.height
      el.style.setProperty('--mx', `${px * 100}%`)
      el.style.setProperty('--my', `${py * 100}%`)
      el.style.setProperty('--r', '170px')
      if (pointerType === 'mouse') {
        el.style.transform = `perspective(1000px) rotateX(${(0.5 - py) * 9}deg) rotateY(${(px - 0.5) * 12}deg) scale(1.02)`
      }
    })
  }

  function leave() {
    cancelAnimationFrame(raf.current)
    const el = frame.current
    if (!el) return
    el.style.setProperty('--r', '1px')
    el.style.transform = ''
  }

  return (
    <div className={cn('relative', className)}>
      <span
        aria-hidden="true"
        className="absolute -left-4 -top-4 size-24 rounded-full bg-flag-yellow/30 blur-2xl"
      />
      <span
        aria-hidden="true"
        className="absolute -bottom-4 -right-4 size-28 rounded-full bg-flag-red/35 blur-2xl"
      />

      <div
        ref={frame}
        data-full={full}
        onPointerMove={track}
        onPointerDown={track}
        onPointerLeave={leave}
        onPointerCancel={leave}
        className="portrait relative aspect-[4/5] touch-pan-y select-none overflow-hidden rounded-[2rem] border border-white/15 bg-charcoal-2 shadow-[0_30px_80px_-20px_rgba(214,40,40,0.55)] transition-transform duration-200 ease-out will-change-transform"
      >
        <Image
          key={`base-${photo.src}`}
          src={photo.src}
          alt={photo.alt}
          fill
          priority={priority}
          sizes="(min-width: 1024px) 360px, 90vw"
          className="object-cover grayscale contrast-125"
          style={{ objectPosition: photo.position }}
        />
        <div
          aria-hidden="true"
          className="absolute inset-0 bg-gradient-to-b from-flag-yellow to-flag-red mix-blend-multiply"
        />
        <div aria-hidden="true" className="portrait-color absolute inset-0">
          <Image
            key={`color-${photo.src}`}
            src={photo.src}
            alt=""
            fill
            sizes="(min-width: 1024px) 360px, 90vw"
            className="object-cover"
            style={{ objectPosition: photo.position }}
          />
        </div>

        <span
          key={`a-${index}`}
          aria-hidden="true"
          className="pointer-events-none absolute inset-x-0 top-0 h-1/2 animate-wipe bg-flag-yellow"
        />
        <span
          key={`b-${index}`}
          aria-hidden="true"
          className="pointer-events-none absolute inset-x-0 bottom-0 h-1/2 animate-wipe-back bg-flag-red"
        />

        <div className="pointer-events-none absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/80 to-transparent p-5 pt-16">
          <p className="font-display text-2xl font-extrabold leading-none">CHIRU</p>
          <p className="mt-1 text-xs font-medium uppercase tracking-[0.2em] text-flag-yellow">
            Creator · Karnataka
          </p>
        </div>
        {!full && (
          <span className="pointer-events-none absolute right-4 top-4 rounded-full bg-charcoal/70 px-3 py-1 text-[11px] font-medium backdrop-blur">
            Move over me to reveal
          </span>
        )}
      </div>

      <div className="mt-4 flex items-center justify-between gap-3">
        <div className="flex gap-2" role="group" aria-label="Choose portrait">
          {portraits.map((p, i) => (
            <button
              key={p.src}
              type="button"
              onClick={() => setIndex(i)}
              aria-pressed={i === index}
              aria-label={p.label}
              className={cn(
                'relative size-12 overflow-hidden rounded-xl border-2 transition-all hover:-translate-y-0.5',
                i === index ? 'border-flag-yellow' : 'border-border opacity-70 hover:opacity-100',
              )}
            >
              <Image
                src={p.src}
                alt=""
                fill
                sizes="48px"
                className="object-cover"
                style={{ objectPosition: p.position }}
              />
            </button>
          ))}
        </div>
        <button
          type="button"
          onClick={() => setFull((v) => !v)}
          aria-pressed={full}
          className="inline-flex items-center gap-2 rounded-full border border-border bg-card/70 px-4 py-2.5 text-sm font-medium backdrop-blur transition-colors hover:border-flag-yellow hover:text-flag-yellow"
        >
          {full ? <EyeOff className="size-4" /> : <Eye className="size-4" />}
          {full ? 'Back to flag tone' : 'Reveal full colour'}
        </button>
      </div>
    </div>
  )
}
