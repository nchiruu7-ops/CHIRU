'use client'

import dynamic from 'next/dynamic'
import { Canvas, useThree } from '@react-three/fiber'
import { useEffect, useRef, useState } from 'react'
import type { ComponentType } from 'react'
import * as THREE from 'three'
import type { SceneProps } from '@/components/scenes/kit'

export type LiveSceneVariant =
  | 'ai-generate'
  | 'motion-kinetic'
  | 'print-press'
  | 'layout-snap'
  | 'product-spin'
  | 'brand-spotlight'
  | 'strategy-pillars'
  | 'poster-flip'

const scenes: Record<LiveSceneVariant, ComponentType<SceneProps>> = {
  'ai-generate': dynamic(() => import('@/components/scenes/ai-generate').then((m) => m.AiGenerate), { ssr: false }),
  'motion-kinetic': dynamic(() => import('@/components/scenes/motion-kinetic').then((m) => m.MotionKinetic), { ssr: false }),
  'print-press': dynamic(() => import('@/components/scenes/print-press').then((m) => m.PrintPress), { ssr: false }),
  'layout-snap': dynamic(() => import('@/components/scenes/layout-snap').then((m) => m.LayoutSnap), { ssr: false }),
  'product-spin': dynamic(() => import('@/components/scenes/product-spin').then((m) => m.ProductSpin), { ssr: false }),
  'brand-spotlight': dynamic(() => import('@/components/scenes/brand-spotlight').then((m) => m.BrandSpotlight), { ssr: false }),
  'strategy-pillars': dynamic(() => import('@/components/scenes/strategy-pillars').then((m) => m.StrategyPillars), { ssr: false }),
  'poster-flip': dynamic(() => import('@/components/scenes/poster-flip').then((m) => m.PosterFlip), { ssr: false }),
}

function CameraFit() {
  const { camera, size } = useThree()
  useEffect(() => {
    const perspective = camera as THREE.PerspectiveCamera
    const aspect = size.width / Math.max(1, size.height)
    perspective.position.z = Math.max(8, 8.4 / (2 * Math.tan((perspective.fov * Math.PI) / 360) * aspect))
    perspective.updateProjectionMatrix()
  }, [camera, size.height, size.width])
  return null
}

export function LiveScene({
  variant,
  label,
  poster,
  className = '',
}: {
  variant: LiveSceneVariant
  label: string
  poster?: string
  className?: string
}) {
  const host = useRef<HTMLDivElement>(null)
  const [visible, setVisible] = useState(false)
  const [reduced, setReduced] = useState(false)

  useEffect(() => {
    const media = window.matchMedia('(prefers-reduced-motion: reduce)')
    const update = () => setReduced(media.matches)
    update()
    media.addEventListener('change', update)
    return () => media.removeEventListener('change', update)
  }, [])

  useEffect(() => {
    if (!host.current) return
    if (!('IntersectionObserver' in window)) {
      setVisible(true)
      return
    }
    const observer = new IntersectionObserver(([entry]) => setVisible(entry.isIntersecting), {
      rootMargin: '160px',
      threshold: 0.01,
    })
    observer.observe(host.current)
    return () => observer.disconnect()
  }, [])

  const Scene = scenes[variant]

  return (
    <div
      ref={host}
      role="img"
      aria-label={label}
      className={`relative overflow-hidden bg-[#111013] ${className}`}
      style={poster ? { backgroundImage: `url("${poster}")`, backgroundPosition: 'center', backgroundSize: 'cover' } : undefined}
    >
      {visible && (
        <Canvas
          camera={{ position: [0, 0, 9], fov: 38 }}
          dpr={[1, 1.5]}
          frameloop={reduced ? 'demand' : 'always'}
          gl={{ antialias: false, powerPreference: 'low-power' }}
          aria-hidden="true"
        >
          <CameraFit />
          <Scene reduced={reduced} />
        </Canvas>
      )}
    </div>
  )
}
