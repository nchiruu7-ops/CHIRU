'use client'

import { ArrowUpRight } from 'lucide-react'
import Image from 'next/image'
import Link from 'next/link'
import { useMemo, useState } from 'react'
import { TiltCard } from '@/components/tilt-card'
import { categories, type Project } from '@/lib/projects'
import { cn } from '@/lib/utils'

export function ProjectGallery({
  projects,
  showFilters = true,
}: {
  projects: Project[]
  showFilters?: boolean
}) {
  const [filter, setFilter] = useState<string>('All')

  const visible = useMemo(
    () => (filter === 'All' ? projects : projects.filter((p) => p.category === filter)),
    [filter, projects],
  )
  const available = useMemo(
    () => categories.filter((c) => projects.some((p) => p.category === c)),
    [projects],
  )

  return (
    <div>
      {showFilters && (
        <div
          role="group"
          aria-label="Filter projects by category"
          className="mb-10 flex flex-wrap gap-2"
        >
          {['All', ...available].map((c) => (
            <button
              key={c}
              type="button"
              onClick={() => setFilter(c)}
              aria-pressed={filter === c}
              className={cn(
                'rounded-full border px-4 py-2 text-sm font-medium transition-all',
                filter === c
                  ? 'border-flag-yellow bg-flag-yellow text-charcoal'
                  : 'border-border bg-card/60 text-muted-foreground hover:border-flag-yellow/60 hover:text-foreground',
              )}
            >
              {c}
            </button>
          ))}
        </div>
      )}

      <ul className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
        {visible.map((p, i) => (
          <li
            key={p.slug}
            className="animate-in fade-in zoom-in-95 duration-500"
            style={{ animationDelay: `${i * 50}ms`, animationFillMode: 'backwards' }}
          >
            <TiltCard className="rounded-3xl">
              <Link
                href={`/portfolio/${p.slug}`}
                aria-label={`View project: ${p.title}`}
                className="group relative block aspect-[4/5] w-full overflow-hidden rounded-3xl border border-border bg-card text-left"
              >
                <Image
                  src={p.posterSrc}
                  alt={`${p.title}: ${p.category}`}
                  fill
                  sizes="(min-width:1024px) 33vw, (min-width:640px) 50vw, 100vw"
                  className="object-cover transition-transform duration-700 group-hover:scale-110"
                />
                <span className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-transparent" />
                <span className="absolute left-4 top-4 rounded-full bg-charcoal/80 px-3 py-1 text-xs font-semibold text-flag-yellow backdrop-blur">
                  {p.category}
                </span>
                <span className="absolute right-4 top-4 flex size-9 items-center justify-center rounded-full bg-flag-yellow text-charcoal opacity-0 transition-all duration-300 group-hover:opacity-100 group-focus-visible:opacity-100">
                  <ArrowUpRight className="size-4" />
                </span>
                <span className="absolute inset-x-0 bottom-0 p-5">
                  <span className="block font-display text-xl font-bold leading-tight text-balance">
                    {p.title}
                  </span>
                  <span className="mt-1 block max-h-0 overflow-hidden text-sm leading-relaxed text-white/75 opacity-0 transition-all duration-500 group-hover:max-h-24 group-hover:opacity-100">
                    {p.summary}
                  </span>
                </span>
              </Link>
            </TiltCard>
          </li>
        ))}
      </ul>
    </div>
  )
}
