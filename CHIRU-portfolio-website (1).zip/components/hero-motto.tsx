'use client'

import { useEffect, useRef } from 'react'

const words = ['ಸತ್ಯಮೇವ', 'ಜಯತೇ']

const RADIUS = 180
const PUSH = 46
const STIFFNESS = 0.12
const DAMPING = 0.82

type Body = { x: number; y: number; vx: number; vy: number; rot: number; vrot: number }

export function HeroMotto() {
  const wrapRef = useRef<HTMLParagraphElement>(null)
  const wordRefs = useRef<(HTMLSpanElement | null)[]>([])

  useEffect(() => {
    const wrap = wrapRef.current
    if (!wrap) return
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return

    const bodies: Body[] = words.map(() => ({ x: 0, y: 0, vx: 0, vy: 0, rot: 0, vrot: 0 }))
    const pointer = { x: 0, y: 0, active: false }
    let frame = 0
    let running = false

    const step = () => {
      let moving = pointer.active

      bodies.forEach((body, i) => {
        const el = wordRefs.current[i]
        if (!el) return

        // Rest position is measured from layout so the physics offset never feeds back into it.
        const rect = el.getBoundingClientRect()
        const cx = rect.left + rect.width / 2 - body.x
        const cy = rect.top + rect.height / 2 - body.y

        let tx = 0
        let ty = 0
        let trot = 0
        if (pointer.active) {
          const dx = cx - pointer.x
          const dy = cy - pointer.y
          const dist = Math.hypot(dx, dy)
          if (dist < RADIUS) {
            const force = (1 - dist / RADIUS) ** 2
            tx = (dx / (dist || 1)) * PUSH * force
            ty = (dy / (dist || 1)) * PUSH * force
            trot = (dx / RADIUS) * 9 * force
          }
        }

        body.vx = (body.vx + (tx - body.x) * STIFFNESS) * DAMPING
        body.vy = (body.vy + (ty - body.y) * STIFFNESS) * DAMPING
        body.vrot = (body.vrot + (trot - body.rot) * STIFFNESS) * DAMPING
        body.x += body.vx
        body.y += body.vy
        body.rot += body.vrot

        el.style.transform = `translate3d(${body.x.toFixed(2)}px, ${body.y.toFixed(2)}px, 0) rotate(${body.rot.toFixed(2)}deg)`

        const energy = Math.abs(body.vx) + Math.abs(body.vy) + Math.abs(body.vrot) + Math.abs(body.x) + Math.abs(body.y)
        if (energy > 0.05) moving = true
      })

      if (moving) {
        frame = requestAnimationFrame(step)
      } else {
        running = false
        bodies.forEach((_, i) => {
          const el = wordRefs.current[i]
          if (el) el.style.transform = ''
        })
      }
    }

    const start = () => {
      if (running) return
      running = true
      frame = requestAnimationFrame(step)
    }

    const onMove = (e: PointerEvent) => {
      pointer.x = e.clientX
      pointer.y = e.clientY
      pointer.active = true
      start()
    }
    const onLeave = () => {
      pointer.active = false
      start()
    }
    const onPress = (e: PointerEvent) => {
      const rect = wrap.getBoundingClientRect()
      const originX = e.clientX - (rect.left + rect.width / 2)
      bodies.forEach((body, i) => {
        body.vy -= 14
        body.vrot += (i === 0 ? -1 : 1) * 6 + originX * 0.01
      })
      start()
    }

    wrap.addEventListener('pointermove', onMove)
    wrap.addEventListener('pointerleave', onLeave)
    wrap.addEventListener('pointerdown', onPress)
    return () => {
      wrap.removeEventListener('pointermove', onMove)
      wrap.removeEventListener('pointerleave', onLeave)
      wrap.removeEventListener('pointerdown', onPress)
      cancelAnimationFrame(frame)
    }
  }, [])

  return (
    <p
      ref={wrapRef}
      aria-label="ಸತ್ಯಮೇವ ಜಯತೇ — Truth alone triumphs"
      className="group/motto relative mb-4 flex w-fit cursor-pointer select-none flex-wrap items-baseline gap-x-4 rounded-full border-2 border-flag-yellow/60 bg-charcoal/70 px-6 py-2 font-kannada text-3xl font-extrabold shadow-[0_0_40px_-8px_rgba(255,194,14,0.6)] md:px-10 md:text-5xl"
      style={{ touchAction: 'manipulation' }}
    >
      {words.map((word, i) => (
        <span
          key={word}
          aria-hidden="true"
          className="animate-motto-float inline-block"
          style={{ animationDelay: `${i * 400}ms` }}
        >
          <span
            ref={(node) => {
              wordRefs.current[i] = node
            }}
            className="text-flag-gradient inline-block will-change-transform drop-shadow-[0_6px_24px_rgba(253,184,19,0.45)]"
          >
            {word}
          </span>
        </span>
      ))}
      <span
        aria-hidden="true"
        className="pointer-events-none absolute -bottom-1 left-0 h-[3px] w-full origin-left scale-x-0 rounded-full bg-gradient-to-r from-flag-yellow to-flag-red transition-transform duration-700 group-hover/motto:scale-x-100"
      />
    </p>
  )
}
