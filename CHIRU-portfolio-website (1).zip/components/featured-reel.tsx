'use client'

import { ArrowUpRight, Play } from 'lucide-react'
import { useRef, useState } from 'react'
import { Reveal } from '@/components/reveal'
import { featuredReel } from '@/lib/site'

export function FeaturedReel() {
  const [loaded, setLoaded] = useState(false)
  const phone = useRef<HTMLDivElement>(null)

  function tilt(e: React.PointerEvent<HTMLDivElement>) {
    if (e.pointerType !== 'mouse' || loaded) return
    const el = phone.current
    if (!el) return
    const r = el.getBoundingClientRect()
    const px = (e.clientX - r.left) / r.width
    const py = (e.clientY - r.top) / r.height
    el.style.transform = `perspective(1100px) rotateY(${(px - 0.5) * 16}deg) rotateX(${(0.5 - py) * 10}deg)`
  }

  return (
    <section
      id="reel"
      aria-labelledby="reel-heading"
      className="relative z-10 mx-auto max-w-7xl px-5 py-20 md:px-8 md:py-28"
    >
      <div className="grid items-center gap-14 lg:grid-cols-[1fr_auto]">
        <Reveal>
          <p className="mb-4 text-sm font-semibold uppercase tracking-[0.2em] text-flag-yellow">
            Published work
          </p>
          <h2
            id="reel-heading"
            className="max-w-xl font-display text-4xl font-extrabold leading-tight tracking-tight text-balance md:text-6xl"
          >
            One reel, <span className="text-flag-gradient">live on Instagram</span>
          </h2>
          <p className="mt-5 max-w-lg text-lg leading-relaxed text-muted-foreground">
            Here is a single published reel. Press play to load it right here. The rest of the
            content I create with the team is scheduled by the team, so it will appear only after
            it goes live.
          </p>
          <a
            href={featuredReel.url}
            target="_blank"
            rel="noopener noreferrer"
            className="group mt-8 inline-flex items-center gap-2 rounded-full border border-border px-6 py-3 text-sm font-semibold transition-colors hover:border-flag-yellow hover:text-flag-yellow"
          >
            Open on Instagram
            <ArrowUpRight className="size-4 transition-transform group-hover:-translate-y-0.5 group-hover:translate-x-0.5" />
          </a>
        </Reveal>

        <Reveal delay={150} className="mx-auto">
          <div
            onPointerMove={tilt}
            onPointerLeave={() => {
              if (phone.current) phone.current.style.transform = ''
            }}
          >
            <div
              ref={phone}
              className="relative w-[min(86vw,340px)] rounded-[2.5rem] bg-gradient-to-b from-flag-yellow to-flag-red p-[3px] shadow-[0_40px_90px_-30px_rgba(214,40,40,0.6)] transition-transform duration-200 ease-out will-change-transform"
            >
              <div className="relative h-[min(130vw,640px)] overflow-hidden rounded-[2.4rem] bg-charcoal">
                {loaded ? (
                  <iframe
                    src={featuredReel.embedUrl}
                    title="Published Instagram reel"
                    loading="lazy"
                    allowFullScreen
                    scrolling="no"
                    className="absolute inset-0 size-full border-0 bg-white"
                  />
                ) : (
                  <button
                    type="button"
                    onClick={() => setLoaded(true)}
                    aria-label="Load and play the Instagram reel"
                    className="group absolute inset-0 flex size-full flex-col items-center justify-center gap-5 bg-[radial-gradient(circle_at_30%_20%,rgba(255,194,14,0.35),transparent_55%),radial-gradient(circle_at_80%_90%,rgba(214,40,40,0.45),transparent_55%)] p-8 text-center"
                  >
                    <span className="relative flex size-24 items-center justify-center">
                      <span
                        aria-hidden="true"
                        className="absolute inset-0 animate-pulse-ring rounded-full bg-flag-yellow/60"
                      />
                      <span className="relative flex size-24 items-center justify-center rounded-full bg-flag-yellow text-charcoal shadow-xl transition-transform group-hover:scale-110">
                        <Play className="size-10 translate-x-0.5 fill-current" />
                      </span>
                    </span>
                    <span className="font-display text-2xl font-extrabold">Play the reel</span>
                    <span className="max-w-[16rem] text-sm text-muted-foreground">
                      Loads from Instagram only when you press play, so the site stays fast.
                    </span>
                  </button>
                )}
              </div>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  )
}
