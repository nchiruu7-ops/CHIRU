import { ArrowRight, MessageCircle } from 'lucide-react'
import Link from 'next/link'
import { FlagBackdrop } from '@/components/flag-backdrop'
import { HeroMotto } from '@/components/hero-motto'
import { HeritageArch } from '@/components/heritage-frame'
import { PortraitReveal } from '@/components/portrait-reveal'
import { site } from '@/lib/site'

const letters = site.name.split('')

const corners = [
  'top-4 left-4 border-l-2 border-t-2 rounded-tl-2xl',
  'top-4 right-4 border-r-2 border-t-2 rounded-tr-2xl',
  'bottom-4 left-4 border-l-2 border-b-2 rounded-bl-2xl',
  'bottom-4 right-4 border-r-2 border-b-2 rounded-br-2xl',
]

export function Hero() {
  return (
    <section className="relative isolate overflow-hidden px-5 pb-16 pt-24 md:px-8 md:pt-28">
      <FlagBackdrop />
      <div
        aria-hidden="true"
        className="absolute inset-x-0 top-0 -z-10 h-1/2 bg-gradient-to-b from-flag-yellow/20 to-transparent"
      />
      <div
        aria-hidden="true"
        className="absolute inset-x-0 bottom-0 -z-10 h-1/2 bg-gradient-to-t from-flag-red/25 to-transparent"
      />
      <div aria-hidden="true" className="absolute inset-0 -z-10 bg-grain opacity-60" />
      <HeritageArch className="absolute -left-6 bottom-0 -z-10 hidden h-72 w-52 text-flag-yellow/25 md:block" />
      <HeritageArch
        mirrored
        className="absolute -right-6 bottom-0 -z-10 hidden h-72 w-52 text-flag-red/30 md:block"
      />

      <div className="mx-auto max-w-7xl">
        <div className="relative overflow-hidden rounded-[2.5rem] border border-flag-yellow/25 bg-charcoal/55 px-5 py-10 text-center shadow-[0_30px_90px_-30px_rgba(214,40,40,0.5)] backdrop-blur-md md:px-12 md:py-14">
          <span
            aria-hidden="true"
            className="absolute inset-x-0 top-0 h-1.5 bg-gradient-to-r from-flag-yellow via-flag-yellow/70 to-flag-red"
          />
          <span
            aria-hidden="true"
            className="absolute inset-x-0 bottom-0 h-1.5 bg-gradient-to-r from-flag-red via-flag-yellow/70 to-flag-yellow"
          />
          {corners.map((pos) => (
            <span
              key={pos}
              aria-hidden="true"
              className={`absolute size-8 border-flag-yellow/70 ${pos}`}
            />
          ))}

          <p className="text-xs font-semibold uppercase tracking-[0.3em] text-flag-yellow md:text-sm">
            Creator · Karnataka
          </p>

          <div className="mt-4 flex justify-center">
            <HeroMotto />
          </div>

          <h1
            aria-label={site.name}
            className="mt-2 flex justify-center font-display text-[clamp(5.5rem,21vw,17rem)] font-extrabold leading-[0.92] tracking-tight drop-shadow-[0_12px_40px_rgba(214,40,40,0.35)]"
          >
            {letters.map((ch, i) => (
              <span
                key={`${ch}-${i}`}
                aria-hidden="true"
                style={{ animationDelay: `${i * 140}ms` }}
                className="text-flag-split inline-block animate-letter cursor-default pr-[0.02em] transition-[scale] duration-200 hover:scale-110"
              >
                {ch}
              </span>
            ))}
          </h1>

          <div className="mt-6 flex items-center justify-center gap-5">
            <span aria-hidden="true" className="h-px w-12 bg-gradient-to-r from-transparent to-flag-yellow/70 md:w-24" />
            <p className="font-kannada text-3xl font-extrabold text-flag-gradient md:text-4xl">
              ಜೈ ಭುವನೇಶ್ವರಿ
            </p>
            <span aria-hidden="true" className="h-px w-12 bg-gradient-to-l from-transparent to-flag-red/70 md:w-24" />
          </div>
          <p className="mt-3 font-kannada text-base font-semibold text-muted-foreground md:text-lg">
            With Blessings of Sadhguru Shri Shri Shri Venkatachala Avadhootaru
          </p>
        </div>

        <div className="mt-10 grid items-center gap-10 lg:grid-cols-[minmax(0,360px)_1fr] lg:gap-14">
          <div className="relative mx-auto w-full max-w-sm lg:mx-0">
            <div
              aria-hidden="true"
              className="absolute -inset-2 rounded-[2.5rem] opacity-70 blur-md motion-safe:animate-spin"
              style={{
                animationDuration: '14s',
                background:
                  'conic-gradient(from 0deg, #ffc20e, #d62828, #ffc20e, #d62828, #ffc20e)',
              }}
            />
            <PortraitReveal priority className="relative" />
          </div>

          <div className="mx-auto max-w-xl text-center lg:mx-0 lg:text-left">
            <p className="font-display text-xl font-bold md:text-2xl">
              Creator of <span className="text-flag-gradient">AI content</span>, motion graphics and print design.
            </p>
            <p className="mt-3 leading-relaxed text-muted-foreground">
              3D AI Animation For YouTube channels, Brands, Brand Recognition And plus online printing, DTP and digital solutions for your brand.
            </p>
            <div className="mt-6 flex flex-wrap justify-center gap-3 lg:justify-start">
              <Link
                href="/contact"
                className="group inline-flex items-center gap-2 rounded-full bg-gradient-to-b from-flag-yellow to-[#f08a1c] px-6 py-3.5 font-semibold text-charcoal shadow-[0_10px_40px_-10px_rgba(255,194,14,0.7)] transition-transform hover:-translate-y-0.5"
              >
                <MessageCircle className="size-4" />
                Start an enquiry
              </Link>
              <Link
                href="/portfolio"
                className="group inline-flex items-center gap-2 rounded-full border border-border bg-card/60 px-6 py-3.5 font-semibold backdrop-blur transition-colors hover:border-flag-red"
              >
                View portfolio
                <ArrowRight className="size-4 transition-transform group-hover:translate-x-1" />
              </Link>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
