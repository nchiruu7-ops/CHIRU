import Link from 'next/link'
import { ArrowUpRight } from 'lucide-react'
import { LiveScene } from '@/components/live-scene'
import { Reveal } from '@/components/reveal'
import type { LiveSceneVariant } from '@/lib/scenes'

const offers: { title: string; text: string; href: string; variant: LiveSceneVariant; poster: string }[] = [
  { title: 'Poster gallery', text: 'Eight original vector-led poster concepts across distinct visual styles.', href: '/posters', variant: 'poster-flip', poster: '/projects/poster.png' },
  { title: 'Product promotion', text: 'A hero visual and campaign assets designed around the product.', href: '/product-promotion', variant: 'product-spin', poster: '/projects/promo-reel.png' },
  { title: 'Brand promotion', text: 'A consistent identity system carried through campaign touchpoints.', href: '/brand-promotion', variant: 'brand-spotlight', poster: '/projects/brand-identity.png' },
  { title: 'Brand strategy', text: 'A practical direction from audience and message to visual system.', href: '/brand-strategy', variant: 'strategy-pillars', poster: '/projects/ai-character.png' },
]

export function CreativeServices() {
  return (
    <section aria-labelledby="creative-services-heading" className="relative z-10 mx-auto max-w-7xl px-5 py-20 md:px-8 md:py-28">
      <Reveal>
        <p className="mb-4 text-sm font-semibold uppercase tracking-[0.2em] text-flag-yellow">More ways to make an impression</p>
        <h2 id="creative-services-heading" className="max-w-3xl font-display text-4xl font-extrabold leading-tight md:text-6xl">Campaign ideas, <span className="text-flag-gradient">made tangible.</span></h2>
      </Reveal>
      <ul className="mt-10 grid gap-5 sm:grid-cols-2">
        {offers.map((offer, i) => (
          <li key={offer.href}>
            <Reveal delay={i * 80}>
              <Link href={offer.href} className="group grid h-full overflow-hidden rounded-3xl border border-border bg-card transition-colors hover:border-flag-yellow/60 md:grid-cols-[0.9fr_1.1fr]">
                <LiveScene variant={offer.variant} label={`${offer.title} live 3D example`} poster={offer.poster} className="aspect-[16/10] min-h-44 w-full md:aspect-auto" />
                <span className="flex flex-col justify-center p-6 md:p-8">
                  <span className="flex items-center justify-between gap-3 font-display text-xl font-bold">
                    {offer.title}
                    <ArrowUpRight className="size-5 shrink-0 text-flag-yellow transition-transform group-hover:-translate-y-1 group-hover:translate-x-1" />
                  </span>
                  <span className="mt-2 text-sm leading-relaxed text-muted-foreground">{offer.text}</span>
                </span>
              </Link>
            </Reveal>
          </li>
        ))}
      </ul>
    </section>
  )
}
