export function PageHero({
  eyebrow,
  title,
  accent,
  text,
}: {
  eyebrow: string
  title: string
  accent: string
  text: string
}) {
  return (
    <section className="relative overflow-hidden px-5 pb-14 pt-32 md:px-8 md:pb-20 md:pt-44">
      <div
        aria-hidden="true"
        className="absolute -right-24 top-0 h-[420px] w-[420px] rounded-full bg-flag-yellow/15 blur-3xl"
      />
      <div
        aria-hidden="true"
        className="absolute -left-24 bottom-0 h-[360px] w-[360px] rounded-full bg-flag-red/15 blur-3xl"
      />
      <div className="relative mx-auto max-w-7xl">
        <p className="mb-5 inline-flex items-center gap-2 text-sm font-semibold uppercase tracking-[0.2em] text-flag-yellow">
          <span className="h-px w-8 bg-flag-yellow" />
          {eyebrow}
        </p>
        <h1 className="max-w-4xl font-display text-5xl font-extrabold leading-[1.02] tracking-tight text-balance md:text-7xl">
          {title} <span className="text-flag-gradient">{accent}</span>
        </h1>
        <p className="mt-6 max-w-2xl text-lg leading-relaxed text-muted-foreground text-pretty">
          {text}
        </p>
      </div>
    </section>
  )
}
