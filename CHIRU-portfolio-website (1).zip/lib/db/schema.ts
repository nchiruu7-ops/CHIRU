import { pgTable, text, timestamp, uuid } from 'drizzle-orm/pg-core'

export const enquiries = pgTable('enquiries', {
  id: uuid('id').primaryKey().defaultRandom(),
  name: text('name').notNull(),
  contact: text('contact').notNull(),
  message: text('message').notNull(),
  privacyAcknowledgedAt: timestamp('privacy_acknowledged_at', { withTimezone: true }),
  services: text('services').notNull(),
  deadline: text('deadline').notNull(),
  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
  adminNotifiedAt: timestamp('admin_notified_at', { withTimezone: true }),
  confirmationSentAt: timestamp('confirmation_sent_at', { withTimezone: true }),
  status: text('status').notNull().default('new'),
  internalNotes: text('internal_notes').notNull().default(''),
})
