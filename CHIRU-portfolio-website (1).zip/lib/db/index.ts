import { drizzle } from 'drizzle-orm/node-postgres'
import { Pool } from 'pg'
import * as schema from '@/lib/db/schema'

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  max: 5,
  connectionTimeoutMillis: 5000,
  idleTimeoutMillis: 10000,
})

pool.on('error', (error) => {
  console.error('Unexpected idle database client error', error)
})

export const db = drizzle(pool, { schema })
export const checkDatabaseConnection = () => db.select().from(schema.enquiries).limit(0)
