/**
 * EDIT THIS FILE to update your name, contact links, team channels and photos.
 * Leave a link as an empty string ('') and the site will show a
 * "coming soon" placeholder instead of a broken link.
 */

export const site = {
  name: 'CHIRU',
  fullName: 'CHIRU',
  role: 'AI Content Creator & Motion Graphics Designer',
  tagline: 'AI Content Creator | Motion Graphics Designer | Visual Storyteller',
  email: 'chirujaff007@gmail.com',
  description:
    'CHIRU: AI content creator, AI animation team member, motion graphics designer. Online printing, DTP and digital design solutions, styled in the colours of Karnataka.',
}

/** Default inbox for contact form enquiries; deployments may set ENQUIRY_TO. */
export const enquiryRecipient = site.email

/** Your photos. The first one is the default portrait. */
export const portraits = [
  {
    src: '/images/chiru-1.jpg',
    alt: 'Portrait of Chiru wearing a cream collared shirt',
    label: 'Studio look',
    position: '50% 18%',
  },
  {
    src: '/images/chiru-2.png',
    alt: 'Portrait of Chiru at night wearing a light blue t-shirt',
    label: 'Street look',
    position: '50% 22%',
  },
]

/** Paste your real profile links between the quotes. Empty = placeholder. */
export const socials = {
  linkedin: '', // e.g. 'https://www.linkedin.com/in/your-name'
  instagram: '', // e.g. 'https://www.instagram.com/your-handle'
  whatsapp: '917204868185',
  youtube: '', // your channel link
}

/**
 * Team work. CHIRU works as an AI animation team member. Only the public
 * channels are linked; individual videos are not shown.
 */
export const teamWork = {
  role: 'AI Animation Team Member',
  channels: [
    {
      name: 'Moo Family',
      handle: '@moofamily_official',
      url: 'https://youtube.com/@moofamily_official',
      blurb: 'Animated family-friendly stories created by a team of AI animation artists.\nSubscribe, Suppourt and Share Such Healthy Contents',
    },
    {
      name: 'Cow Paradise',
      handle: '@cowparadiseofficial',
      url: 'https://youtube.com/@cowparadiseofficial',
      blurb: 'A colourful animated world, produced and published by the team on a content calendar.\nSubscribe, Suppourt and Share Such Healthy Contents',
    },
  ],
}

/** The single published reel that is showcased on the site. */
export const featuredReel = {
  url: 'https://www.instagram.com/reel/DcyPa3rmwDb/',
  embedUrl: 'https://www.instagram.com/reel/DcyPa3rmwDb/embed/',
}

export const navLinks = [
  { href: '/', label: 'Home' },
  { href: '/portfolio', label: 'Portfolio' },
  { href: '/ai-content', label: 'AI Content' },
  { href: '/motion-graphics', label: 'Motion' },
  { href: '/services', label: 'Print & DTP' },
  { href: '/posters', label: 'Posters' },
  { href: '/about', label: 'About' },
  { href: '/contact', label: 'Contact' },
]

export const skills = [
  'Prompt Engineering & Optimization',
  'AI Content Creation (Text, Image, Video)',
  'Social Media Content & Script Writing',
  'Visual Storytelling',
  'SEO Basics & Content Strategy',
  'Video Editing & Motion Graphics',
]

export const tools = [
  'ChatGPT',
  'Claude',
  'Grok',
  'Gemini',
  'Midjourney',
  'Flow',
  'Runway ML',
  'Pika Labs',
  'Canva',
  'Adobe Suite',
]

export const education = [
  {
    title: 'Motion Graphic Design',
    place: 'Framebox – Institute of Emerging Media',
    year: '2025',
    note: '',
  },
  {
    title: 'Diploma in Printing Technology',
    place: '',
    year: '2023',
    note: '85%',
  },
]

export const experience = [
  'AI-generated content for social media and marketing campaigns',
  'Prompt design for text, image and video generation',
  'Branding assets, posters and web banners',
  'Visual storytelling across digital and print',
]

export interface Service {
  title: string
  description: string
  items: string[]
}

export const services: Service[] = [
  {
    title: 'Online Printing',
    description:
      'Send your artwork or ask us to design it. We prepare print-ready files and handle the printing.',
    items: [
      'Business cards and stationery',
      'Flyers, brochures and catalogues',
      'Posters and banners',
      'Stickers and labels',
    ],
  },
  {
    title: 'Design Solutions',
    description:
      'Logos, brand kits and campaign visuals designed to look sharp on paper and on screen.',
    items: [
      'Logo and brand identity',
      'Posters and invitations',
      'Packaging and label artwork',
      'Social media and web banners',
    ],
  },
  {
    title: 'DTP Works',
    description:
      'Desktop publishing for print and digital: clean layouts, correct colour and print-ready output.',
    items: [
      'Page layout and typesetting',
      'Book, magazine and brochure layout',
      'File cleanup and print-ready PDFs',
      'Colour and resolution checks',
    ],
  },
  {
    title: 'Digital Solutions',
    description:
      'Content built for screens: AI visuals, short videos and motion graphics for your channels.',
    items: [
      'AI images and AI video clips',
      'Promotional reels and shorts',
      'Motion graphics and titles',
      'E-brochures and presentations',
    ],
  },
]

export const processSteps = [
  { step: '01', title: 'Brief', text: 'Tell us what you need, the size, the quantity and the deadline.' },
  { step: '02', title: 'Design', text: 'We design or prepare your artwork and share a proof for approval.' },
  { step: '03', title: 'Print or Publish', text: 'Once approved we print, or export the files for your digital channels.' },
  { step: '04', title: 'Deliver', text: 'You receive the finished prints or final files, ready to use.' },
]
