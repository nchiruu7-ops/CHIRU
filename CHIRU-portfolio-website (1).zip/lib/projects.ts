import type { SceneVariant } from '@/components/inspiration-scene'

/**
 * ADD YOUR PROJECTS HERE. Copy one block, change the text, drop your poster
 * into /public/projects and point `posterSrc` at it. The Portfolio page, filters,
 * Home gallery and /portfolio/[slug] pages update automatically.
 *
 * Replace posters and videos with your real work and set `client` and `year`
 * to match the real project.
 */

import type { LiveSceneVariant } from '@/lib/scenes'

export const categories = [
  'AI Videos',
  'Motion Graphics',
  '3D Animation',
  'Brand Identity',
  'Promotional Reels',
  'Posters',
  'Print & DTP',
] as const

export type Category = (typeof categories)[number]

export interface Project {
  slug: string
  title: string
  category: Category
  /** One-line summary shown on cards and detail pages. */
  summary: string
  description: string
  /** What the brief asked for. */
  brief: string
  /** Steps the work went through, in order. */
  process: string[]
  software: string[]
  client: string
  year: string
  /** Poster image, also used as the video fallback. */
  posterSrc: string
  /** Local video (under /public) or YouTube link. */
  videoUrl?: string
  /** Live scene shown in project previews. */
  sceneVariant: LiveSceneVariant
  /** Call to action text on the detail page. */
  cta: string
  featured?: boolean
  /** Shown on the AI Content page. */
  aiContent?: boolean
}

export const projects: Project[] = [
  {
    slug: 'dawn-temple',
    title: 'Dawn Temple, Cinematic AI Sequence',
    category: 'AI Videos',
    summary: 'A lone figure on a misty temple stair at first light.',
    description:
      'A cinematic AI film concept: a lone figure on a misty temple stair at first light, built from prompt-designed keyframes and animated shot by shot.',
    brief:
      'A short, atmospheric opening shot for a devotional channel: quiet, cinematic and rooted in Karnataka temple architecture.',
    process: [
      'Wrote the shot list and mood board from the brief.',
      'Designed keyframes with prompt-led image generation.',
      'Animated each shot and matched the light across the sequence.',
      'Colour graded the set and exported the final loop.',
    ],
    software: ['Midjourney', 'Runway ML', 'Adobe Suite'],
    client: 'Concept sample',
    year: '2025',
    posterSrc: '/projects/ai-cinematic.png',
    sceneVariant: 'ai-generate',
    cta: 'Commission a cinematic AI sequence',
    featured: true,
    aiContent: true,
  },
  {
    slug: 'molten-ribbons',
    title: 'Molten Ribbons, Title Motion Study',
    category: 'Motion Graphics',
    summary: 'Liquid colour and light for a broadcast-style title.',
    description:
      'Liquid colour and light for a broadcast-style title sequence. An exploration of rhythm, depth and flow in yellow and red.',
    brief: 'A broadcast title open with a bold, flowing identity in the flag palette.',
    process: [
      'Explored rhythm and timing with a storyboard.',
      'Built the liquid ribbon simulation and lighting.',
      'Added the title type and tuned the motion curves.',
      'Delivered the title open in broadcast and social cuts.',
    ],
    software: ['After Effects', 'Adobe Suite'],
    client: 'Concept sample',
    year: '2025',
    posterSrc: '/projects/motion-graphics.png',
    sceneVariant: 'motion-kinetic',
    cta: 'Book a title sequence',
    featured: true,
  },
  {
    slug: 'mascot-character',
    title: 'Mascot Character Render',
    category: '3D Animation',
    summary: 'A friendly stylised mascot for short animated loops.',
    description:
      'A friendly stylised mascot designed for brand storytelling, lit and rendered for short animated loops.',
    brief: 'A friendly mascot that can carry a brand through short, looping social posts.',
    process: [
      'Sketched character turnarounds and chose the palette.',
      'Rendered the hero pose with soft studio lighting.',
      'Animated idle and reaction loops.',
      'Exported loops in square and vertical formats.',
    ],
    software: ['Midjourney', 'Runway ML', 'After Effects'],
    client: 'Concept sample',
    year: '2025',
    posterSrc: '/projects/3d-character.png',
    sceneVariant: 'brand-spotlight',
    cta: 'Design a mascot for your brand',
    featured: true,
    aiContent: true,
  },
  {
    slug: 'brand-kit',
    title: 'Brand Identity Kit',
    category: 'Brand Identity',
    summary: 'An emblem applied across stationery and merchandise.',
    description:
      'Emblem, stationery and merchandise mock-ups showing how a logo lives across print and everyday objects.',
    brief: 'A compact identity kit that works on print, merchandise and screen.',
    process: [
      'Refined the emblem and built a colour system.',
      'Laid out stationery and label templates.',
      'Produced merchandise mock-ups.',
      'Packaged the kit as a print-ready and digital set.',
    ],
    software: ['Illustrator', 'Photoshop', 'Canva'],
    client: 'Concept sample',
    year: '2025',
    posterSrc: '/projects/brand-identity.png',
    sceneVariant: 'layout-snap',
    cta: 'Start a brand identity kit',
    featured: true,
  },
  {
    slug: 'sneaker-reel',
    title: 'Product Promo Reel',
    category: 'Promotional Reels',
    summary: 'A vertical promo built for the scroll.',
    description:
      'A high-energy vertical promo frame for social media: bold colour splashes, rim light and motion built for the scroll.',
    brief: 'A vertical product reel with punchy motion that stops a thumb mid-scroll.',
    process: [
      'Wrote a three-beat script for the reel.',
      'Generated product visuals and colour splashes.',
      'Cut the reel to music with motion accents.',
      'Exported vertical and square versions.',
    ],
    software: ['Runway ML', 'Pika Labs', 'Premiere Pro'],
    client: 'Concept sample',
    year: '2025',
    posterSrc: '/projects/promo-reel.png',
    sceneVariant: 'product-spin',
    cta: 'Request a promo reel',
    featured: true,
    aiContent: true,
  },
  {
    slug: 'palace-poster',
    title: 'Festival Poster Artwork',
    category: 'Posters',
    summary: 'A palace silhouette against a golden sun.',
    description:
      'Layered paper-cut style poster artwork with a palace silhouette against a golden sun and crimson sky.',
    brief: 'A festival poster that feels heritage-led while staying bold at a distance.',
    process: [
      'Planned the layers and focal point.',
      'Built the palace silhouette and sun.',
      'Set the type hierarchy for event details.',
      'Prepared print and screen versions.',
    ],
    software: ['Midjourney', 'Photoshop', 'Illustrator'],
    client: 'Concept sample',
    year: '2025',
    posterSrc: '/projects/poster.png',
    sceneVariant: 'poster-flip',
    cta: 'Order a festival poster',
    featured: true,
    aiContent: true,
  },
  {
    slug: 'print-ready-collateral',
    title: 'Print-Ready Collateral',
    category: 'Print & DTP',
    summary: 'Brochures and banners prepared for press.',
    description:
      'Brochures, banners and colour-managed files prepared for press, drawn from a Diploma in Printing Technology background.',
    brief: 'A set of brochures and banners that must print accurately the first time.',
    process: [
      'Checked artwork resolution and colour mode.',
      'Laid out pages with bleed and safe margins.',
      'Prepared colour-managed PDFs for press.',
      'Proofed and handed over the print-ready files.',
    ],
    software: ['InDesign', 'Photoshop', 'Illustrator'],
    client: 'Concept sample',
    year: '2025',
    posterSrc: '/projects/printing.png',
    sceneVariant: 'print-press',
    cta: 'Get a print quote',
  },
  {
    slug: 'circuit-portrait',
    title: 'Circuit Portrait, AI Character',
    category: 'AI Videos',
    summary: 'Glowing circuitry meets traditional gold jewellery.',
    description:
      'An AI character study blending glowing circuitry with traditional gold jewellery, designed for character animation.',
    brief: 'A character study that brings traditional gold craft into a futuristic look.',
    process: [
      'Developed the character look and jewellery design.',
      'Generated the circuit lighting and texture.',
      'Tested the character in short motion clips.',
      'Chose the final frames for animation.',
    ],
    software: ['Midjourney', 'Runway ML', 'Pika Labs'],
    client: 'Concept sample',
    year: '2025',
    posterSrc: '/projects/ai-character.png',
    sceneVariant: 'strategy-pillars',
    cta: 'Commission a character study',
    aiContent: true,
  },
]

export function getProject(slug: string) {
  return projects.find((p) => p.slug === slug)
}
