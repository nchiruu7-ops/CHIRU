export type LiveSceneVariant =
  | 'ai-generate'
  | 'motion-kinetic'
  | 'print-press'
  | 'layout-snap'
  | 'product-spin'
  | 'brand-spotlight'
  | 'strategy-pillars'
  | 'poster-flip'
