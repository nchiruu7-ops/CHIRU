export type PosterStyle = 'sun' | 'cut-paper' | 'wave' | 'grid' | 'botanical' | 'orbit' | 'architecture' | 'signal'

export interface PosterConcept {
  slug: string
  title: string
  brief: string
  style: PosterStyle
  palette: [string, string, string, string]
  edition: string
}

export const posters: PosterConcept[] = [
  { slug: 'golden-hour', title: 'Golden Hour', brief: 'A warm, layered composition built around a rising sun.', style: 'sun', palette: ['#25110e', '#b73922', '#ffc20e', '#fff2cf'], edition: '01 / Atmosphere' },
  { slug: 'paper-festival', title: 'Paper Festival', brief: 'Cut-paper geometry brings a celebration into view.', style: 'cut-paper', palette: ['#16151a', '#d62828', '#ffc20e', '#fff4d6'], edition: '02 / Culture' },
  { slug: 'monsoon-lines', title: 'Monsoon Lines', brief: 'A rhythm of flowing forms inspired by the first rain.', style: 'wave', palette: ['#101a22', '#1d6471', '#74c4af', '#f0d89a'], edition: '03 / Nature' },
  { slug: 'type-study', title: 'Type Study', brief: 'An editorial grid that turns scale and spacing into the image.', style: 'grid', palette: ['#f2e8d5', '#151515', '#d62828', '#ffc20e'], edition: '04 / Editorial' },
  { slug: 'garden-notes', title: 'Garden Notes', brief: 'Botanical silhouettes arranged as a contemporary print.', style: 'botanical', palette: ['#17241c', '#486b45', '#d5a954', '#f4ead1'], edition: '05 / Botanical' },
  { slug: 'orbit-festival', title: 'Orbit Festival', brief: 'Concentric forms create a high-energy night-event graphic.', style: 'orbit', palette: ['#171022', '#7b3bb8', '#f04f75', '#ffd35c'], edition: '06 / Music' },
  { slug: 'stone-and-sun', title: 'Stone & Sun', brief: 'Architectural layers meet a crisp, minimal sun disc.', style: 'architecture', palette: ['#25201b', '#99724f', '#dfb56b', '#f4ead4'], edition: '07 / Place' },
  { slug: 'signal-red', title: 'Signal Red', brief: 'An abstract signal pattern built for bold campaign use.', style: 'signal', palette: ['#181518', '#891e2c', '#ed423c', '#ffc20e'], edition: '08 / Campaign' },
]
