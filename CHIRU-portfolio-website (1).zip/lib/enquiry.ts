export const enquiryFrom = process.env.ENQUIRY_FROM

const EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
const PHONE = /^\+?[\d\s().-]+$/

export interface Enquiry {
  name: string
  contact: string
  message: string
  services: string
  deadline: string
}

export function isEmail(value: string) {
  return EMAIL.test(value)
}

export function isPhone(value: string) {
  const digits = value.replace(/\D/g, '')
  return PHONE.test(value) && digits.length >= 7 && digits.length <= 15
}

function field(value: unknown, max: number, multiline = false) {
  if (typeof value !== 'string') return null
  const trimmed = value.trim()
  const controlChars = multiline ? /[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/ : /[\u0000-\u001f\u007f]/
  return trimmed && trimmed.length <= max && !controlChars.test(trimmed) ? trimmed : null
}

export function parseEnquiry(body: unknown): Enquiry | null {
  if (typeof body !== 'object' || body === null || Array.isArray(body)) return null
  const data = body as Record<string, unknown>
  const name = field(data.name, 120)
  const contact = field(data.contact, 200)
  const message = field(data.message, 5000, true)
  const deadline = field(data.deadline, 100)
  const privacyAcknowledged = data.privacyAcknowledged === true
  const services = Array.isArray(data.services)
    ? data.services
        .filter((service): service is string => typeof service === 'string')
        .map((service) => field(service, 60))
        .filter((service): service is string => service !== null)
        .slice(0, 10)
        .join(', ')
    : ''

  if (
    !name ||
    !contact ||
    (!isEmail(contact) && !isPhone(contact)) ||
    !deadline ||
    !privacyAcknowledged ||
    !message ||
    message.length < 10
  ) {
    return null
  }
  return { name, contact, message, services, deadline }
}

export function buildAdminEmail(enquiry: Enquiry) {
  return {
    subject: `New enquiry from ${enquiry.name}`,
    replyTo: isEmail(enquiry.contact) ? enquiry.contact : undefined,
    text: [
      `Name: ${enquiry.name}`,
      `Reach me at: ${enquiry.contact}`,
      `Services: ${enquiry.services || 'Not specified'}`,
      `Deadline: ${enquiry.deadline}`,
      '',
      enquiry.message,
    ].join('\n'),
  }
}

export function buildConfirmationEmail(enquiry: Enquiry) {
  return {
    subject: 'We received your enquiry to CHIRU',
    text: [
      `Hi ${enquiry.name},`,
      '',
      'Thank you for your enquiry. Your brief has been received and CHIRU will reply to this email address.',
      '',
      `Services: ${enquiry.services || 'Not specified'}`,
      `Deadline: ${enquiry.deadline}`,
      '',
      'Your message:',
      enquiry.message,
    ].join('\n'),
  }
}
