import { describe, expect, it } from 'vitest'
import { buildAdminEmail, buildConfirmationEmail, isEmail, isPhone, parseEnquiry } from './enquiry'

const valid = {
  name: ' Asha ',
  contact: 'asha@example.com',
  message: 'Need 500 flyers for a local festival.',
  deadline: 'This week',
  services: ['Online printing', 'Design & DTP'],
  privacyAcknowledged: true,
}

describe('parseEnquiry', () => {
  it('trims fields and joins services', () => {
    expect(parseEnquiry(valid)).toEqual({
      name: 'Asha',
      contact: 'asha@example.com',
      message: 'Need 500 flyers for a local festival.',
      services: 'Online printing, Design & DTP',
      deadline: 'This week',
    })
  })

  it('accepts a missing services list', () => {
    expect(parseEnquiry({ ...valid, services: undefined })?.services).toBe('')
  })

  it('rejects a missing body', () => {
    expect(parseEnquiry(null)).toBeNull()
    expect(parseEnquiry('text')).toBeNull()
  })

  it('rejects blank or short required fields', () => {
    expect(parseEnquiry({ ...valid, name: '   ' })).toBeNull()
    expect(parseEnquiry({ ...valid, contact: '' })).toBeNull()
    expect(parseEnquiry({ ...valid, deadline: undefined })).toBeNull()
    expect(parseEnquiry({ ...valid, message: 'too short' })).toBeNull()
  })

  it('rejects overlong fields and control characters', () => {
    expect(parseEnquiry({ ...valid, name: 'a'.repeat(121) })).toBeNull()
    expect(parseEnquiry({ ...valid, name: 'Asha\nB' })).toBeNull()
    expect(parseEnquiry({ ...valid, message: 'a'.repeat(5001) })).toBeNull()
  })

  it('requires a valid email address or phone number', () => {
    expect(parseEnquiry({ ...valid, contact: 'not a contact' })).toBeNull()
    expect(parseEnquiry({ ...valid, contact: '+91 98450 00000' })).not.toBeNull()
  })

  it('requires an explicit privacy acknowledgement', () => {
    expect(parseEnquiry({ ...valid, privacyAcknowledged: false })).toBeNull()
    expect(parseEnquiry({ ...valid, privacyAcknowledged: 'yes' })).toBeNull()
  })

  it('rejects non-object request bodies', () => {
    expect(parseEnquiry([])).toBeNull()
    expect(parseEnquiry(42)).toBeNull()
  })

  it('ignores non-string service entries and caps the list at ten', () => {
    const services = [1, 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k']
    expect(parseEnquiry({ ...valid, services })?.services).toBe(
      'a, b, c, d, e, f, g, h, i, j',
    )
  })
})

describe('isEmail', () => {
  it('detects email addresses and phone numbers', () => {
    expect(isEmail('asha@example.com')).toBe(true)
    expect(isEmail('+91 98450 00000')).toBe(false)
    expect(isPhone('+91 98450 00000')).toBe(true)
    expect(isPhone('123')).toBe(false)
  })
})

describe('buildAdminEmail', () => {
  const enquiry = parseEnquiry(valid)!

  it('sets the reply-to to an email contact', () => {
    const email = buildAdminEmail(enquiry)
    expect(email.subject).toBe('New enquiry from Asha')
    expect(email.replyTo).toBe('asha@example.com')
    expect(email.text).toContain('Services: Online printing, Design & DTP')
    expect(email.text).toContain('Need 500 flyers for a local festival.')
  })

  it('omits reply-to for a phone contact', () => {
    const email = buildAdminEmail({ ...enquiry, contact: '+91 98450 00000' })
    expect(email.replyTo).toBeUndefined()
    expect(email.text).toContain('Reach me at: +91 98450 00000')
  })
})

describe('buildConfirmationEmail', () => {
  it('addresses the client and summarises the brief', () => {
    const email = buildConfirmationEmail(parseEnquiry({ ...valid, services: [] })!)
    expect(email.subject).toBe('We received your enquiry to CHIRU')
    expect(email.text).toContain('Hi Asha,')
    expect(email.text).toContain('Services: Not specified')
    expect(email.text).toContain('Deadline: This week')
  })
})
