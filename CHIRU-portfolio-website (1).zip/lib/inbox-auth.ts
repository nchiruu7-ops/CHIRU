import { createHash, createHmac, timingSafeEqual } from 'node:crypto'

export const inboxCookie = 'chiru_inbox_session'
const sessionLifetime = 12 * 60 * 60

function adminPassword() {
  const value = process.env.INBOX_ADMIN_PASSWORD
  return value && value.length >= 16 ? value : null
}

function digest(value: string) {
  return createHash('sha256').update(value).digest()
}

export function passwordMatches(value: unknown) {
  const expected = adminPassword()
  if (!expected || typeof value !== 'string') return false
  return timingSafeEqual(digest(value), digest(expected))
}

export function createInboxSession() {
  const secret = adminPassword()
  if (!secret) return null
  const expires = Math.floor(Date.now() / 1000) + sessionLifetime
  const signature = createHmac('sha256', secret).update(String(expires)).digest('base64url')
  return { value: `${expires}.${signature}`, maxAge: sessionLifetime }
}

export function hasInboxSession(request: Request) {
  const secret = adminPassword()
  if (!secret) return false
  const cookieHeader = request.headers.get('cookie') ?? ''
  const value = cookieHeader
    .split(';')
    .map((part) => part.trim())
    .find((part) => part.startsWith(`${inboxCookie}=`))
    ?.slice(inboxCookie.length + 1)
  if (!value) return false
  const [expiresText, signature] = value.split('.')
  const expires = Number(expiresText)
  if (!Number.isSafeInteger(expires) || expires <= Math.floor(Date.now() / 1000) || !signature) return false
  const expected = createHmac('sha256', secret).update(expiresText).digest('base64url')
  return timingSafeEqual(digest(signature), digest(expected))
}

export function sameOriginRequest(request: Request) {
  return request.headers.get('origin') === new URL(request.url).origin
}

export const inboxCookieOptions = (maxAge: number) =>
  `${inboxCookie}=; Path=/; HttpOnly; SameSite=Strict; Max-Age=${maxAge}${process.env.NODE_ENV === 'production' ? '; Secure' : ''}`
