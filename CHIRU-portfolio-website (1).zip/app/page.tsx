import { ArrowRight } from 'lucide-react'
import Link from 'next/link'
import { ConnectHub } from '@/components/connect-hub'
import { CreativeServices } from '@/components/creative-services'
import { FeaturedReel } from '@/components/featured-reel'
import { HeritageDivider } from '@/components/heritage-frame'
import { Hero } from '@/components/hero'
import { LiveScene } from '@/components/live-scene'
import type { LiveSceneVariant } from '@/lib/scenes'
import { KannadaMotto } from '@/components/kannada-motto'
import { ProjectGallery } from '@/components/project-gallery'
import { Reveal } from '@/components/reveal'
import { TeamWork } from '@/components/team-work'
import { TiltCard } from '@/components/tilt-card'
import { ToolMarquee } from '@/components/tool-marquee'
import { projects } from '@/lib/projects'

const offers = [
  {
    visual: (
      <svg viewBox="0 0 28 28" className="size-8" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
        <rect x="3" y="5" width="22" height="17" rx="3" />
        <path d="M11 10.5v6l5-3z" fill="currentColor" />
        <path d="M22 3v4M20 5h4" />
      </svg>
    ),
    title: 'AI Content',
    text: 'Images, videos and scripts made with the best AI tools and sharp prompts.',
    href: '/ai-content',
    variant: 'ai-generate' as LiveSceneVariant,
    poster: '/projects/ai-cinematic.png',
    overlay: 'from-flag-red/70 via-charcoal/10 to-transparent',
  },
  {
    visual: (
      <svg viewBox="0 0 28 28" className="size-8" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
        <path d="M3 21 C 9 21, 9 7, 15 7 S 21 17, 25 9" />
        <circle cx="3" cy="21" r="2" fill="currentColor" />
        <circle cx="15" cy="7" r="2" fill="currentColor" />
        <circle cx="25" cy="9" r="2" fill="currentColor" />
        <path d="M3 26h22" opacity="0.45" />
      </svg>
    ),
    title: 'Motion Graphics',
    text: 'Titles, promos and reels that move with rhythm and purpose.',
    href: '/motion-graphics',
    variant: 'motion-kinetic' as LiveSceneVariant,
    poster: '/projects/motion-graphics.png',
    overlay: 'from-flag-yellow/60 via-charcoal/10 to-transparent',
  },
  {
    visual: (
      <svg viewBox="0 0 28 28" className="size-8" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
        <path d="M8 11V4h12v7" />
        <rect x="3" y="11" width="22" height="9" rx="2" />
        <rect x="8" y="17" width="12" height="7" fill="currentColor" />
      </svg>
    ),
    title: 'Online Printing',
    text: 'Cards, flyers, banners and more, printed and delivered.',
    href: '/services/online-printing',
    variant: 'print-press' as LiveSceneVariant,
    poster: '/projects/printing.png',
    overlay: 'from-flag-red/60 via-charcoal/10 to-transparent',
  },
  {
    visual: (
      <svg viewBox="0 0 28 28" className="size-8" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
        <rect x="3" y="3" width="14" height="14" rx="2" />
        <rect x="11" y="11" width="14" height="14" rx="2" fill="currentColor" fillOpacity="0.25" />
        <circle cx="3" cy="3" r="1.5" fill="currentColor" />
        <circle cx="25" cy="25" r="1.5" fill="currentColor" />
      </svg>
    ),
    title: 'Design & DTP',
    text: 'Brand identity, layouts and print-ready files for any medium.',
    href: '/services/design-dtp',
    variant: 'layout-snap' as LiveSceneVariant,
    poster: '/projects/brand-identity.png',
    overlay: 'from-flag-yellow/50 via-charcoal/10 to-transparent',
  },
]

export default function HomePage() {
  const featured = projects.filter((p) => p.featured).slice(0, 6)

  return (
    <>
      <Hero />
      <ToolMarquee />

      <section
        aria-labelledby="offer-heading"
        className="relative z-10 mx-auto max-w-7xl px-5 py-20 md:px-8 md:py-28"
      >
        <Reveal>
          <p className="mb-4 text-sm font-semibold uppercase tracking-[0.2em] text-flag-yellow">
            What I do
          </p>
          <h2
            id="offer-heading"
            className="max-w-3xl font-display text-4xl font-extrabold leading-tight tracking-tight text-balance md:text-6xl"
          >
            From pixels to <span className="text-flag-gradient">paper</span>
          </h2>
        </Reveal>
        <ul className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {offers.map((o, i) => (
            <li key={o.title}>
              <Reveal delay={i * 90} className="h-full">
                <TiltCard className="h-full rounded-3xl">
                  <Link
                    href={o.href}
                    className="group flex h-full flex-col overflow-hidden rounded-3xl border border-border bg-card p-7 transition-colors hover:border-flag-yellow/60"
                  >
                    <span className="relative -mx-7 -mt-7 mb-6 block aspect-video overflow-hidden">
                      <LiveScene
                        variant={o.variant}
                        label={`${o.title} live 3D scene`}
                        poster={o.poster}
                        className="size-full transition-transform duration-700 group-hover:scale-105"
                      />
                      <span aria-hidden="true" className={`absolute inset-0 bg-gradient-to-t ${o.overlay}`} />
                    </span>
                    <span className="flex size-14 items-center justify-center rounded-2xl bg-gradient-to-b from-flag-yellow to-flag-red text-charcoal">
                      {o.visual}
                    </span>
                    <h3 className="mt-6 font-display text-2xl font-bold">{o.title}</h3>
                    <p className="mt-2 flex-1 leading-relaxed text-muted-foreground">
                      {o.text}
                    </p>
                    <span className="mt-6 inline-flex items-center gap-2 text-sm font-semibold text-flag-yellow">
                      Explore
                      <ArrowRight className="size-4 transition-transform group-hover:translate-x-1" />
                    </span>
                  </Link>
                </TiltCard>
              </Reveal>
            </li>
          ))}
        </ul>
      </section>

      <div className="relative z-10 mx-auto max-w-7xl px-5 md:px-8">
        <HeritageDivider />
      </div>

      <CreativeServices />
      <TeamWork />
      <KannadaMotto />
      <FeaturedReel />

      <div className="relative z-10 mx-auto max-w-7xl px-5 md:px-8">
        <HeritageDivider />
      </div>

      <section
        aria-labelledby="featured-heading"
        className="relative z-10 mx-auto max-w-7xl px-5 py-20 md:px-8 md:py-28"
      >
        <Reveal className="mb-12 flex flex-wrap items-end justify-between gap-6">
          <div>
            <p className="mb-4 text-sm font-semibold uppercase tracking-[0.2em] text-flag-yellow">
              Selected projects
            </p>
            <h2
              id="featured-heading"
              className="font-display text-4xl font-extrabold leading-tight tracking-tight md:text-6xl"
            >
              AI creative <span className="text-flag-gradient">showcase</span>
            </h2>
          </div>
          <Link
            href="/portfolio"
            className="group inline-flex items-center gap-2 rounded-full border border-border px-6 py-3 text-sm font-semibold transition-colors hover:border-flag-yellow hover:text-flag-yellow"
          >
            Full portfolio
            <ArrowRight className="size-4 transition-transform group-hover:translate-x-1" />
          </Link>
        </Reveal>
        <ProjectGallery projects={featured} showFilters={false} />
      </section>

      <div className="relative z-10 mx-auto max-w-7xl px-5 md:px-8">
        <HeritageDivider />
      </div>

      <ConnectHub />

      <section className="relative z-10 mx-auto max-w-7xl px-5 md:px-8">
        <Reveal>
          <div className="relative overflow-hidden rounded-[2rem] bg-gradient-to-b from-flag-yellow to-flag-red p-10 text-charcoal md:p-16">
            <div aria-hidden="true" className="absolute -right-16 -top-16 size-72 rounded-full bg-white/20 blur-2xl" />
            <h2 className="relative max-w-2xl font-display text-4xl font-extrabold leading-tight text-balance md:text-6xl">
              Have a print job or a big idea?
            </h2>
            <p className="relative mt-4 max-w-xl text-lg font-medium text-charcoal/80">
              Tell me what you need. I&apos;ll design it, prepare it and print it.
            </p>
            <Link
              href="/contact"
              className="group relative mt-8 inline-flex items-center gap-2 rounded-full bg-charcoal px-8 py-4 font-semibold text-white transition-transform hover:-translate-y-0.5"
            >
              Start a project
              <ArrowRight className="size-4 transition-transform group-hover:translate-x-1" />
            </Link>
          </div>
        </Reveal>
      </section>
    </>
  )
}
