import { Brain, Clapperboard, ImageIcon, PenLine } from 'lucide-react'
import type { Metadata } from 'next'
import { LiveScene } from '@/components/live-scene'
import { PageHero } from '@/components/page-hero'
import { ProjectGallery } from '@/components/project-gallery'
import { Reveal } from '@/components/reveal'
import { ToolMarquee } from '@/components/tool-marquee'
import { projects } from '@/lib/projects'

export const metadata: Metadata = {
  title: 'AI Content',
  description:
    'AI-generated videos, images and scripts: prompt design, visual storytelling and campaign content by CHIRU.',
}

const pillars = [
  { icon: PenLine, title: 'Prompt design', text: 'Structured prompts that give consistent, controllable results.' },
  { icon: ImageIcon, title: 'AI imagery', text: 'Characters, posters and campaign visuals with a clear art direction.' },
  { icon: Clapperboard, title: 'AI video', text: 'Short cinematic clips and reels animated from designed keyframes.' },
  { icon: Brain, title: 'Strategy', text: 'Scripts, SEO basics and content plans built around the audience.' },
]

export default function AiContentPage() {
  const ai = projects.filter((p) => p.aiContent)
  return (
    <>
      <PageHero
        eyebrow="AI Content"
        title="Imagination,"
        accent="directed"
        text="AI is the camera. Prompts are the direction. Here is a selection of AI-driven creative work across video, characters and posters."
      />
      <ToolMarquee />
      <section className="relative z-10 mx-auto max-w-7xl px-5 md:px-8">
        <Reveal>
          <LiveScene
            variant="ai-generate"
            label="Particles gather from an orb and reveal a generated cinematic landscape"
            poster="/projects/ai-cinematic.png"
            className="aspect-video w-full rounded-[2rem] border border-border"
          />
        </Reveal>
      </section>
      <section className="relative z-10 mx-auto max-w-7xl px-5 py-20 md:px-8">
        <ul className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {pillars.map((p, i) => (
            <li key={p.title}>
              <Reveal delay={i * 80} className="h-full">
                <div className="h-full rounded-3xl border border-border bg-card p-6">
                  <p.icon className="size-8 text-flag-yellow" />
                  <h2 className="mt-5 font-display text-xl font-bold">{p.title}</h2>
                  <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{p.text}</p>
                </div>
              </Reveal>
            </li>
          ))}
        </ul>
      </section>
      <section className="relative z-10 mx-auto max-w-7xl px-5 md:px-8">
        <ProjectGallery projects={ai} showFilters={false} />
      </section>
    </>
  )
}
