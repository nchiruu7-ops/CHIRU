import type { Metadata } from 'next'
import Link from 'next/link'
import { ArrowUpRight } from 'lucide-react'
import { LiveScene } from '@/components/live-scene'
import { PageHero } from '@/components/page-hero'
import { PosterArt } from '@/components/poster-art'
import { Reveal } from '@/components/reveal'
import { posters } from '@/lib/posters'

export const metadata: Metadata = {
  title: 'Poster Gallery',
  description: 'Eight original, vector-generated poster concepts by CHIRU.',
}

export default function PostersPage() {
  return (
    <>
      <PageHero eyebrow="Poster gallery" title="Eight directions." accent="One bold wall." text="A set of original, generated poster studies spanning atmosphere, culture, nature, editorial, botanical, music, architecture and campaign design. These are concepts, not client commissions." />
      <section className="relative z-10 mx-auto max-w-7xl px-5 md:px-8">
        <Reveal>
          <LiveScene variant="poster-flip" label="Four animated poster designs turn on a gallery wall" poster="/projects/poster.png" className="aspect-[16/8] w-full rounded-[2rem] border border-border" />
        </Reveal>
        <ul className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {posters.map((poster, i) => (
            <li key={poster.slug}>
              <Reveal delay={(i % 4) * 60}>
                <article className="overflow-hidden rounded-3xl border border-border bg-card">
                  <PosterArt poster={poster} className="block aspect-[3/4] w-full" />
                  <div className="p-5">
                    <p className="text-xs font-semibold uppercase tracking-widest text-flag-yellow">{poster.edition}</p>
                    <h2 className="mt-2 font-display text-xl font-bold">{poster.title}</h2>
                    <p className="mt-2 min-h-12 text-sm leading-relaxed text-muted-foreground">{poster.brief}</p>
                    <Link href="/contact?service=Poster%20design" className="mt-4 inline-flex items-center gap-2 text-sm font-semibold text-flag-yellow hover:underline">
                      Commission a poster <ArrowUpRight className="size-4" />
                    </Link>
                  </div>
                </article>
              </Reveal>
            </li>
          ))}
        </ul>
        <p className="mt-8 text-sm text-muted-foreground">Need a print-ready version? Include size, quantity, location and deadline in your <Link href="/contact?service=Poster%20design" className="text-flag-yellow underline">project enquiry</Link>.</p>
      </section>
    </>
  )
}
