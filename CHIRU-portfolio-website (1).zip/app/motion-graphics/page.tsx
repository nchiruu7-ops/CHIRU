import { Clapperboard, Film, Type, Zap } from 'lucide-react'
import type { Metadata } from 'next'
import Link from 'next/link'
import { LiveScene } from '@/components/live-scene'
import { PageHero } from '@/components/page-hero'
import { Reveal } from '@/components/reveal'

export const metadata: Metadata = {
  title: 'Motion Graphics',
  description:
    'Titles, promos and reels that move with rhythm and purpose: motion graphics by CHIRU.',
}

const offers = [
  { icon: Type, title: 'Titles and lower thirds', text: 'Clean, timed text that reads clearly on every screen.' },
  { icon: Zap, title: 'Promos and openers', text: 'Short, punchy motion built to hold attention in the first seconds.' },
  { icon: Film, title: 'Reels and shorts', text: 'Vertical edits cut to the beat of the music or the script.' },
  { icon: Clapperboard, title: 'Animated stories', text: 'Scenes that combine AI-made visuals with designed motion.' },
]

export default function MotionGraphicsPage() {
  return (
    <>
      <PageHero
        eyebrow="Motion Graphics"
        title="Motion with"
        accent="rhythm."
        text="Titles, promos and reels that move with purpose. Designed frame by frame and paced to suit the platform they are made for."
      />

      <section className="relative z-10 mx-auto max-w-7xl px-5 md:px-8">
        <Reveal>
          <div className="overflow-hidden rounded-[2rem] border border-border bg-black">
            <LiveScene
              variant="motion-kinetic"
              label="A ball drops and rebounds across a springing field of motion tiles"
              poster="/projects/motion-graphics.png"
              className="aspect-video w-full"
            />
          </div>
        </Reveal>

        <ul className="mt-14 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {offers.map((o, i) => (
            <li key={o.title}>
              <Reveal delay={i * 80} className="h-full">
                <div className="h-full rounded-3xl border border-border bg-card p-6">
                  <o.icon className="size-8 text-flag-red" />
                  <h2 className="mt-5 font-display text-xl font-bold">{o.title}</h2>
                  <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{o.text}</p>
                </div>
              </Reveal>
            </li>
          ))}
        </ul>

        <div className="mt-16 flex flex-wrap items-center justify-between gap-6 rounded-[2rem] border border-flag-yellow/30 bg-charcoal-2 p-8 md:p-12">
          <div>
            <h2 className="font-display text-3xl font-extrabold">Have a reel or title in mind?</h2>
            <p className="mt-2 text-muted-foreground">Share the script, length and platform. I will reply with a plan.</p>
          </div>
          <Link
            href="/contact"
            className="inline-flex rounded-full bg-gradient-to-b from-flag-yellow to-[#f08a1c] px-8 py-4 font-semibold text-charcoal transition-transform hover:-translate-y-0.5"
          >
            Start a project
          </Link>
        </div>
      </section>
    </>
  )
}
