import { Check } from 'lucide-react'
import type { Metadata } from 'next'
import Link from 'next/link'
import { PageHero } from '@/components/page-hero'
import { LiveScene } from '@/components/live-scene'
import { Reveal } from '@/components/reveal'
import { services } from '@/lib/site'

export const metadata: Metadata = {
  title: 'Design & DTP',
  description:
    'Brand identity, layouts and print-ready files for any medium. Design and DTP by CHIRU.',
}

const design = services.find((s) => s.title === 'Design Solutions')!
const dtp = services.find((s) => s.title === 'DTP Works')!

export default function DesignDtpPage() {
  return (
    <>
      <PageHero
        eyebrow="Design & DTP"
        title="Brand first,"
        accent="layout next."
        text="Logos, brand kits, layouts and print-ready files, set up so the same identity works on paper and on screen."
      />

      <section className="relative z-10 mx-auto max-w-7xl px-5 md:px-8">
        <Reveal>
          <div className="overflow-hidden rounded-[2rem] border border-border bg-black">
            <LiveScene
              variant="layout-snap"
              label="Design and DTP layout elements assemble into a print-ready page"
              poster="/projects/brand-identity.png"
              className="aspect-video w-full"
            />
          </div>
        </Reveal>

        <ul className="mt-14 grid gap-5 md:grid-cols-2">
          {[design, dtp].map((s, i) => (
            <li key={s.title}>
              <Reveal delay={i * 100} className="h-full">
                <article className="h-full rounded-3xl border border-border bg-card p-8">
                  <p className="font-display text-sm font-bold text-flag-yellow">{s.title}</p>
                  <p className="mt-3 leading-relaxed text-muted-foreground">{s.description}</p>
                  <ul className="mt-6 space-y-2.5">
                    {s.items.map((it) => (
                      <li key={it} className="flex items-start gap-3 text-sm">
                        <span className="mt-0.5 flex size-5 shrink-0 items-center justify-center rounded-full bg-flag-yellow text-charcoal">
                          <Check className="size-3" strokeWidth={3} />
                        </span>
                        {it}
                      </li>
                    ))}
                  </ul>
                </article>
              </Reveal>
            </li>
          ))}
        </ul>

        <div className="mt-16 text-center">
          <Link
            href="/contact"
            className="inline-flex rounded-full bg-gradient-to-b from-flag-yellow to-[#f08a1c] px-8 py-4 font-semibold text-charcoal transition-transform hover:-translate-y-0.5"
          >
            Request a quote
          </Link>
        </div>
      </section>
    </>
  )
}
