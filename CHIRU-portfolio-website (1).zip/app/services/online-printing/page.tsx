import { Check } from 'lucide-react'
import type { Metadata } from 'next'
import Link from 'next/link'
import { LiveScene } from '@/components/live-scene'
import { PageHero } from '@/components/page-hero'
import { Reveal } from '@/components/reveal'
import { processSteps, services } from '@/lib/site'

export const metadata: Metadata = {
  title: 'Online Printing',
  description:
    'Cards, flyers, banners and more, printed and delivered. Online printing by CHIRU.',
}

const printing = services.find((s) => s.title === 'Online Printing')!

export default function OnlinePrintingPage() {
  return (
    <>
      <PageHero
        eyebrow="Online Printing"
        title="Printed,"
        accent="and delivered."
        text="Send your artwork or ask for a design. The files are checked for print before anything goes to press."
      />

      <section className="relative z-10 mx-auto max-w-7xl px-5 md:px-8">
        <div className="grid items-center gap-10 lg:grid-cols-2">
          <Reveal>
            <div className="overflow-hidden rounded-[2rem] border border-border bg-black">
              <LiveScene
                variant="print-press"
                label="A sheet feeds through a print press, receives colour, and stacks after ejection"
                poster="/projects/printing.png"
                className="aspect-[4/3] w-full"
              />
            </div>
          </Reveal>
          <Reveal delay={120}>
            <div className="rounded-[2rem] border border-border bg-card p-8 md:p-10">
              <p className="font-display text-sm font-bold text-flag-red">What I print</p>
              <p className="mt-3 leading-relaxed text-muted-foreground">{printing.description}</p>
              <ul className="mt-8 space-y-3">
                {printing.items.map((it) => (
                  <li key={it} className="flex items-start gap-3">
                    <span className="mt-0.5 flex size-5 shrink-0 items-center justify-center rounded-full bg-flag-red text-white">
                      <Check className="size-3" strokeWidth={3} />
                    </span>
                    {it}
                  </li>
                ))}
              </ul>
            </div>
          </Reveal>
        </div>

        <section aria-labelledby="print-process" className="mt-24">
          <h2 id="print-process" className="font-display text-4xl font-extrabold md:text-5xl">
            How it <span className="text-flag-gradient">works</span>
          </h2>
          <ol className="mt-10 grid gap-5 md:grid-cols-4">
            {processSteps.map((p, i) => (
              <li key={p.step}>
                <Reveal delay={i * 100} className="h-full">
                  <div className="h-full rounded-3xl border border-border bg-card p-6">
                    <span className="font-display text-5xl font-extrabold text-flag-gradient">{p.step}</span>
                    <h3 className="mt-4 font-display text-xl font-bold">{p.title}</h3>
                    <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{p.text}</p>
                  </div>
                </Reveal>
              </li>
            ))}
          </ol>
        </section>

        <div className="mt-16 text-center">
          <Link
            href="/contact"
            className="inline-flex rounded-full bg-gradient-to-b from-flag-yellow to-[#f08a1c] px-8 py-4 font-semibold text-charcoal transition-transform hover:-translate-y-0.5"
          >
            Request a quote
          </Link>
        </div>
      </section>
    </>
  )
}
