import { Check } from 'lucide-react'
import type { Metadata } from 'next'
import Image from 'next/image'
import Link from 'next/link'
import { HeritageDivider } from '@/components/heritage-frame'
import { PageHero } from '@/components/page-hero'
import { Reveal } from '@/components/reveal'
import { TiltCard } from '@/components/tilt-card'
import { processSteps, services } from '@/lib/site'

const creativeRoutes = [
  { href: '/posters', title: 'Poster design', text: 'Eight original concept directions and custom commissions.' },
  { href: '/product-promotion', title: 'Product promotion', text: 'Hero visuals and launch-ready campaign assets.' },
  { href: '/brand-promotion', title: 'Brand promotion', text: 'Consistent identity across campaign touchpoints.' },
  { href: '/brand-strategy', title: 'Brand strategy', text: 'Audience, message and a practical creative direction.' },
]

export const metadata: Metadata = {
  title: 'Online Printing, Design & DTP',
  description:
    'Online printing services, design solutions, DTP works and digital solutions for print and screen.',
}

export default function ServicesPage() {
  return (
    <>
      <PageHero
        eyebrow="Print & DTP"
        title="Designed right."
        accent="Printed right."
        text="Online printing services, design solutions, DTP and digital work. One place for artwork, files and finished output."
      />

      <section className="relative z-10 mx-auto max-w-7xl px-5 md:px-8">
        <HeritageDivider className="mb-12" />
        <Reveal>
          <div className="relative aspect-[16/9] overflow-hidden rounded-[2rem] border border-border md:aspect-[21/9]">
            <Image
              src="/projects/printing.png"
              alt="Printing press output with colour swatches and finished brochures"
              fill
              priority
              sizes="(min-width:1280px) 1200px, 100vw"
              className="object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-charcoal/80 to-transparent" />
          </div>
        </Reveal>

        <ul className="mt-14 grid gap-5 md:grid-cols-2">
          {services.map((s, i) => (
            <li key={s.title}>
              <Reveal delay={(i % 2) * 100} className="h-full">
                <TiltCard className="h-full rounded-3xl" max={4}>
                  <article className="h-full rounded-3xl border border-border bg-card p-8">
                    <p className="font-display text-sm font-bold text-flag-yellow">
                      0{i + 1}
                    </p>
                    <h2 className="mt-2 font-display text-3xl font-bold">{s.title}</h2>
                    <p className="mt-3 leading-relaxed text-muted-foreground">{s.description}</p>
                    <ul className="mt-6 space-y-2.5">
                      {s.items.map((it) => (
                        <li key={it} className="flex items-start gap-3 text-sm">
                          <span className="mt-0.5 flex size-5 shrink-0 items-center justify-center rounded-full bg-flag-yellow text-charcoal">
                            <Check className="size-3" strokeWidth={3} />
                          </span>
                          {it}
                        </li>
                      ))}
                    </ul>
                  </article>
                </TiltCard>
              </Reveal>
            </li>
          ))}
        </ul>

        <div className="mt-16">
          <h2 className="font-display text-3xl font-extrabold md:text-4xl">More creative services</h2>
          <ul className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {creativeRoutes.map((route) => (
              <li key={route.href}>
                <Link href={route.href} className="block h-full rounded-3xl border border-border bg-card p-6 transition-colors hover:border-flag-yellow/60">
                  <h3 className="font-display text-lg font-bold">{route.title}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{route.text}</p>
                </Link>
              </li>
            ))}
          </ul>
        </div>
      </section>

      <section
        aria-labelledby="process-heading"
        className="relative z-10 mx-auto max-w-7xl px-5 py-24 md:px-8"
      >
        <Reveal>
          <h2 id="process-heading" className="font-display text-4xl font-extrabold md:text-5xl">
            How it <span className="text-flag-gradient">works</span>
          </h2>
        </Reveal>
        <ol className="mt-12 grid gap-5 md:grid-cols-4">
          {processSteps.map((p, i) => (
            <li key={p.step}>
              <Reveal delay={i * 100} className="h-full">
                <div className="h-full rounded-3xl border border-border bg-card p-6">
                  <span className="font-display text-5xl font-extrabold text-flag-gradient">
                    {p.step}
                  </span>
                  <h3 className="mt-4 font-display text-xl font-bold">{p.title}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{p.text}</p>
                </div>
              </Reveal>
            </li>
          ))}
        </ol>
        <div className="mt-12 text-center">
          <Link
            href="/contact"
            className="inline-flex rounded-full bg-gradient-to-b from-flag-yellow to-[#f08a1c] px-8 py-4 font-semibold text-charcoal transition-transform hover:-translate-y-0.5"
          >
            Request a quote
          </Link>
        </div>
      </section>
    </>
  )
}
