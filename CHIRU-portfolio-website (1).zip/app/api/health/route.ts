import { checkDatabaseConnection } from '@/lib/db'
import { enquiryFrom, isEmail } from '@/lib/enquiry'
import { enquiryRecipient } from '@/lib/site'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

export async function GET() {
  let database = false
  if (process.env.DATABASE_URL) {
    try {
      await checkDatabaseConnection()
      database = true
    } catch {
      database = false
    }
  }

  const senderAddress = enquiryFrom?.match(/<([^<>]+)>/)?.[1] ?? enquiryFrom
  const recipient = process.env.ENQUIRY_TO || enquiryRecipient
  const email = Boolean(
    process.env.RESEND_API_KEY && senderAddress && isEmail(senderAddress) && isEmail(recipient),
  )
  const ready = database && email

  return Response.json(
    { status: ready ? 'ready' : 'not_ready', services: { database, email } },
    {
      status: ready ? 200 : 503,
      headers: { 'Cache-Control': 'no-store' },
    },
  )
}
