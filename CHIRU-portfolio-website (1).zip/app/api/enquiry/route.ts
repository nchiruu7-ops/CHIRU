import { eq } from 'drizzle-orm'
import { Resend } from 'resend'
import { buildAdminEmail, buildConfirmationEmail, enquiryFrom, isEmail, parseEnquiry } from '@/lib/enquiry'
import { db } from '@/lib/db'
import { enquiries } from '@/lib/db/schema'
import { enquiryRecipient } from '@/lib/site'

export const runtime = 'nodejs'

const MAX_BODY_BYTES = 16_384

async function readBody(request: Request) {
  if (!request.body) return ''
  const reader = request.body.getReader()
  const chunks: Uint8Array[] = []
  let size = 0

  while (true) {
    const { done, value } = await reader.read()
    if (done) break
    size += value.byteLength
    if (size > MAX_BODY_BYTES) {
      await reader.cancel()
      return null
    }
    chunks.push(value)
  }

  const bytes = new Uint8Array(size)
  let offset = 0
  for (const chunk of chunks) {
    bytes.set(chunk, offset)
    offset += chunk.byteLength
  }
  return new TextDecoder().decode(bytes)
}

export async function POST(request: Request) {
  const contentType = request.headers.get('content-type')?.split(';', 1)[0].trim().toLowerCase()
  if (contentType !== 'application/json') {
    return Response.json({ ok: false, error: 'Send the enquiry as JSON.' }, { status: 415 })
  }

  const body = await readBody(request)
  if (body === null) {
    return Response.json({ ok: false, error: 'The enquiry is too large.' }, { status: 413 })
  }

  let payload: unknown
  try {
    payload = JSON.parse(body)
  } catch {
    payload = null
  }
  const enquiry = parseEnquiry(payload)
  if (!enquiry) {
    return Response.json({ ok: false, error: 'Please check the enquiry details and try again.' }, { status: 400 })
  }
  let enquiryId: string | undefined
  if (process.env.DATABASE_URL) {
    try {
      const [row] = await db
        .insert(enquiries)
        .values({ ...enquiry, privacyAcknowledgedAt: new Date() })
        .returning({ id: enquiries.id })
      enquiryId = row?.id
    } catch (err) {
      console.error('Enquiry persistence failed', err)
    }
  }

  let adminNotified = false
  let confirmationSent = false
  const apiKey = process.env.RESEND_API_KEY
  const recipient = process.env.ENQUIRY_TO || enquiryRecipient

  if (apiKey && enquiryFrom && recipient) {
      const resend = new Resend(apiKey)
      try {
        const admin = await resend.emails.send({
          from: enquiryFrom,
          to: recipient,
          ...buildAdminEmail(enquiry),
        })
        if (admin.error) throw new Error(admin.error.message)
        adminNotified = true
        if (enquiryId) {
          await db
            .update(enquiries)
            .set({ adminNotifiedAt: new Date() })
            .where(eq(enquiries.id, enquiryId))
            .catch((err) => console.error('Admin notification status update failed', err))
        }
      } catch (err) {
        console.error('Enquiry notification failed', err)
      }

      if (isEmail(enquiry.contact)) {
        try {
          const confirmation = await resend.emails.send({
            from: enquiryFrom,
            to: enquiry.contact,
            ...buildConfirmationEmail(enquiry),
          })
          if (confirmation.error) throw new Error(confirmation.error.message)
          confirmationSent = true
          if (enquiryId) {
            await db
              .update(enquiries)
              .set({ confirmationSentAt: new Date() })
              .where(eq(enquiries.id, enquiryId))
              .catch((err) => console.error('Confirmation status update failed', err))
          }
        } catch (err) {
          console.error('Enquiry confirmation failed', err)
        }
      }
  }

  if (!enquiryId) {
    return Response.json(
      {
        ok: false,
        saved: false,
        adminNotified,
        error: adminNotified
          ? 'Your enquiry reached email but could not be recorded in the website inbox. Use WhatsApp or email below to keep a direct copy.'
          : 'The website inbox could not save this enquiry. Use WhatsApp or email below to send it directly.',
      },
      { status: 503 },
    )
  }

  return Response.json(
    { ok: true, saved: Boolean(enquiryId), adminNotified, confirmationSent },
    { status: 201 },
  )
}
