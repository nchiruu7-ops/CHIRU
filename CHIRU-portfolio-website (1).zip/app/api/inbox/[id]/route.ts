import { eq } from 'drizzle-orm'
import { hasInboxSession, sameOriginRequest } from '@/lib/inbox-auth'
import { db } from '@/lib/db'
import { enquiries } from '@/lib/db/schema'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

const statuses = ['new', 'in_progress', 'waiting', 'completed'] as const

export async function PATCH(request: Request, context: { params: Promise<{ id: string }> }) {
  if (!hasInboxSession(request)) return Response.json({ error: 'Sign in to update enquiries.' }, { status: 401 })
  if (!sameOriginRequest(request)) return Response.json({ error: 'Invalid request origin.' }, { status: 403 })
  if (!process.env.DATABASE_URL) return Response.json({ error: 'Enquiry storage is not configured.' }, { status: 503 })
  if (request.headers.get('content-type')?.split(';', 1)[0].trim().toLowerCase() !== 'application/json') {
    return Response.json({ error: 'Send the update as JSON.' }, { status: 415 })
  }

  const raw = await request.text()
  if (raw.length > 12_000) return Response.json({ error: 'The update is too large.' }, { status: 413 })
  let payload: unknown
  try {
    payload = JSON.parse(raw)
  } catch {
    payload = null
  }
  if (typeof payload !== 'object' || payload === null || Array.isArray(payload)) {
    return Response.json({ error: 'Invalid enquiry update.' }, { status: 400 })
  }

  const data = payload as Record<string, unknown>
  const updates: { status?: (typeof statuses)[number]; internalNotes?: string } = {}
  if ('status' in data) {
    if (typeof data.status !== 'string' || !statuses.includes(data.status as (typeof statuses)[number])) {
      return Response.json({ error: 'Choose a valid enquiry status.' }, { status: 400 })
    }
    updates.status = data.status as (typeof statuses)[number]
  }
  if ('internalNotes' in data) {
    if (typeof data.internalNotes !== 'string' || data.internalNotes.length > 5000 || /[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/.test(data.internalNotes)) {
      return Response.json({ error: 'Notes must be under 5,000 characters.' }, { status: 400 })
    }
    updates.internalNotes = data.internalNotes.trim()
  }
  if (!Object.keys(updates).length) return Response.json({ error: 'No changes provided.' }, { status: 400 })

  const { id } = await context.params
  if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(id)) {
    return Response.json({ error: 'Enquiry not found.' }, { status: 404 })
  }

  try {
    const [record] = await db.update(enquiries).set(updates).where(eq(enquiries.id, id)).returning()
    if (!record) return Response.json({ error: 'Enquiry not found.' }, { status: 404 })
    return Response.json({ enquiry: record }, { headers: { 'Cache-Control': 'no-store' } })
  } catch (error) {
    console.error('Inbox update failed', error)
    return Response.json({ error: 'The enquiry could not be updated.' }, { status: 503 })
  }
}
