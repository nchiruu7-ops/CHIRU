import { desc } from 'drizzle-orm'
import { hasInboxSession } from '@/lib/inbox-auth'
import { db } from '@/lib/db'
import { enquiries } from '@/lib/db/schema'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

export async function GET(request: Request) {
  if (!hasInboxSession(request)) return Response.json({ error: 'Sign in to view enquiries.' }, { status: 401 })
  if (!process.env.DATABASE_URL) {
    return Response.json({ error: 'Enquiry storage is not configured.' }, { status: 503 })
  }

  try {
    const records = await db.select().from(enquiries).orderBy(desc(enquiries.createdAt)).limit(200)
    return Response.json({ enquiries: records }, { headers: { 'Cache-Control': 'no-store' } })
  } catch (error) {
    console.error('Inbox query failed', error)
    return Response.json({ error: 'Inbox storage is unavailable. Apply the database migrations and try again.' }, { status: 503 })
  }
}
