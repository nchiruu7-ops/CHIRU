import { createInboxSession, hasInboxSession, inboxCookie, inboxCookieOptions, passwordMatches, sameOriginRequest } from '@/lib/inbox-auth'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

export async function GET(request: Request) {
  const configured = Boolean(process.env.INBOX_ADMIN_PASSWORD && process.env.INBOX_ADMIN_PASSWORD.length >= 16)
  return Response.json(
    { authenticated: configured && hasInboxSession(request), configured },
    { headers: { 'Cache-Control': 'no-store' } },
  )
}

export async function POST(request: Request) {
  if (!sameOriginRequest(request)) return Response.json({ error: 'Invalid request origin.' }, { status: 403 })
  if (!process.env.INBOX_ADMIN_PASSWORD || process.env.INBOX_ADMIN_PASSWORD.length < 16) {
    return Response.json({ error: 'Inbox access is not configured.' }, { status: 503 })
  }
  if (request.headers.get('content-type')?.split(';', 1)[0].trim().toLowerCase() !== 'application/json') {
    return Response.json({ error: 'Send the password as JSON.' }, { status: 415 })
  }

  let payload: unknown
  try {
    payload = await request.json()
  } catch {
    payload = null
  }
  const password = typeof payload === 'object' && payload !== null && 'password' in payload
    ? payload.password
    : null
  if (!passwordMatches(password)) return Response.json({ error: 'Incorrect password.' }, { status: 401 })

  const session = createInboxSession()
  if (!session) return Response.json({ error: 'Inbox access is not configured.' }, { status: 503 })
  return Response.json(
    { authenticated: true },
    {
      headers: {
        'Set-Cookie': `${inboxCookie}=${session.value}; Path=/; HttpOnly; SameSite=Strict; Max-Age=${session.maxAge}${process.env.NODE_ENV === 'production' ? '; Secure' : ''}`,
        'Cache-Control': 'no-store',
      },
    },
  )
}

export async function DELETE(request: Request) {
  if (!sameOriginRequest(request)) return Response.json({ error: 'Invalid request origin.' }, { status: 403 })
  return Response.json(
    { authenticated: false },
    { headers: { 'Set-Cookie': inboxCookieOptions(0), 'Cache-Control': 'no-store' } },
  )
}
