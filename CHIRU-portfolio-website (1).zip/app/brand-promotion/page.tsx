import type { Metadata } from 'next'
import { OfferShowcase } from '@/components/offer-showcase'

export const metadata: Metadata = {
  title: 'Brand Promotion',
  description: 'Consistent brand campaign visuals across print, digital, social and merchandise.',
}

export default function BrandPromotionPage() {
  return <OfferShowcase kind="brand" />
}
