import type { Metadata } from 'next'
import Link from 'next/link'
import { PageHero } from '@/components/page-hero'
import { site } from '@/lib/site'

export const metadata: Metadata = {
  title: 'Privacy Notice',
  description: 'How CHIRU handles contact enquiries, optional analytics and embedded media.',
}

const sections = [
  {
    title: 'Information collected',
    text: 'When you submit an enquiry, the site records the name, email address or phone number, message, selected services, requested deadline and submission time you provide. The form does not request payment-card details or account passwords.',
  },
  {
    title: 'Why it is used',
    text: 'Enquiry details are used to respond to your brief, discuss requested creative or printing work, and maintain a record of the conversation. If you provide an email address, an automatic receipt may be sent when email delivery is configured.',
  },
  {
    title: 'Storage and service providers',
    text: 'Enquiry records are stored in the site database when the production database is configured. Email delivery uses Resend when configured. Optional site analytics are disabled unless you allow them. Provider processing and hosting locations depend on the accounts selected for deployment; confirm those settings before launch.',
  },
  {
    title: 'External media and analytics',
    text: 'Instagram and YouTube embeds load only after you choose to play them. Optional Vercel Analytics loads only after you allow analytics. Your choice is stored in this browser’s local storage and can be changed using the Privacy choices control.',
  },
  {
    title: 'Retention and your choices',
    text: 'Enquiry records are kept only as long as needed to handle the conversation and applicable business record-keeping. To request access, correction or deletion of an enquiry, contact the address below. Legal requirements may limit deletion of some records.',
  },
  {
    title: 'Contact',
    text: `For privacy questions or requests, email ${site.email}. Include enough detail to identify the enquiry; do not send sensitive identity or payment information through the contact form.`,
  },
]

export default function PrivacyPage() {
  return (
    <>
      <PageHero eyebrow="Legal" title="Privacy, handled" accent="with care." text="This notice describes the information used by the portfolio and its enquiry flow. It should be reviewed against the final hosting, email and analytics accounts before launch." />
      <main className="relative z-10 mx-auto max-w-4xl px-5 pb-24 md:px-8">
        <div className="space-y-5">
          {sections.map((section) => (
            <section key={section.title} className="rounded-3xl border border-border bg-card p-6 md:p-8">
              <h2 className="font-display text-xl font-bold">{section.title}</h2>
              <p className="mt-3 leading-relaxed text-muted-foreground">{section.text}</p>
            </section>
          ))}
        </div>
        <p className="mt-8 text-sm text-muted-foreground">Need to change an analytics choice? <Link href="/cookies" className="text-flag-yellow underline">Open cookie details</Link>.</p>
      </main>
    </>
  )
}
