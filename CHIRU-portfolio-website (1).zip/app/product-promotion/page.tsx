import type { Metadata } from 'next'
import { OfferShowcase } from '@/components/offer-showcase'

export const metadata: Metadata = {
  title: 'Creative Product Promotion',
  description: 'Product-focused visuals, promotional reels and campaign-ready creative assets by CHIRU.',
}

export default function ProductPromotionPage() {
  return <OfferShowcase kind="product" />
}
