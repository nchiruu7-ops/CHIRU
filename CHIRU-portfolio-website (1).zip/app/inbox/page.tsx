'use client'

import { useCallback, useEffect, useMemo, useState } from 'react'
import { Check, Clock3, Inbox, LogOut, Mail, MessageCircle, RefreshCw, Save, Search } from 'lucide-react'

type Enquiry = {
  id: string
  name: string
  contact: string
  message: string
  services: string
  deadline: string
  createdAt: string
  status: 'new' | 'in_progress' | 'waiting' | 'completed'
  internalNotes: string
  adminNotifiedAt: string | null
  confirmationSentAt: string | null
}

const statuses: Enquiry['status'][] = ['new', 'in_progress', 'waiting', 'completed']
const statusLabels: Record<Enquiry['status'], string> = {
  new: 'New',
  in_progress: 'In progress',
  waiting: 'Waiting',
  completed: 'Completed',
}

function contactLinks(enquiry: Enquiry) {
  const brief = `Hi ${enquiry.name}, following up on your enquiry to CHIRU about ${enquiry.services || 'your project'}.`
  const digits = enquiry.contact.replace(/\D/g, '')
  const whatsapp = digits.length >= 7 && digits.length <= 15
    ? `https://wa.me/${digits}?text=${encodeURIComponent(brief)}`
    : null
  const email = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(enquiry.contact)
    ? `mailto:${enquiry.contact}?subject=${encodeURIComponent('Following up on your CHIRU enquiry')}&body=${encodeURIComponent(brief)}`
    : null
  return { whatsapp, email }
}

export default function InboxPage() {
  const [hydrated, setHydrated] = useState(false)
  const [configured, setConfigured] = useState(true)
  const [authenticated, setAuthenticated] = useState(false)
  const [password, setPassword] = useState('')
  const [enquiries, setEnquiries] = useState<Enquiry[]>([])
  const [selectedId, setSelectedId] = useState<string | null>(null)
  const [filter, setFilter] = useState<'all' | Enquiry['status']>('all')
  const [query, setQuery] = useState('')
  const [notes, setNotes] = useState('')
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState('')

  const selected = enquiries.find((item) => item.id === selectedId) ?? null
  const loadEnquiries = useCallback(async () => {
    setError('')
    try {
      const response = await fetch('/api/inbox', { cache: 'no-store' })
      const data = await response.json()
      if (!response.ok) throw new Error(data.error || 'Could not load enquiries.')
      const records: Enquiry[] = data.enquiries
      setEnquiries(records)
      setSelectedId((current) => records.some((item) => item.id === current) ? current : records[0]?.id ?? null)
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : 'Could not load enquiries.')
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    setHydrated(true)
    fetch('/api/inbox/auth', { cache: 'no-store' })
      .then((response) => response.json())
      .then((data: { configured: boolean; authenticated: boolean }) => {
        setConfigured(data.configured)
        setAuthenticated(data.authenticated)
        if (data.authenticated) void loadEnquiries()
        else setLoading(false)
      })
      .catch(() => {
        setError('Inbox access could not be checked.')
        setLoading(false)
      })
  }, [loadEnquiries])

  useEffect(() => {
    setNotes(selected?.internalNotes ?? '')
  }, [selected?.id, selected?.internalNotes])

  const visibleEnquiries = useMemo(() => {
    const needle = query.trim().toLowerCase()
    return enquiries.filter((item) => {
      const matchesStatus = filter === 'all' || item.status === filter
      const matchesSearch = !needle || [item.name, item.contact, item.services, item.message].join(' ').toLowerCase().includes(needle)
      return matchesStatus && matchesSearch
    })
  }, [enquiries, filter, query])

  async function signIn(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault()
    setError('')
    setSaving(true)
    try {
      const response = await fetch('/api/inbox/auth', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ password }),
      })
      const data = await response.json()
      if (!response.ok) throw new Error(data.error || 'Could not sign in.')
      setAuthenticated(true)
      setPassword('')
      setLoading(true)
      await loadEnquiries()
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : 'Could not sign in.')
    } finally {
      setSaving(false)
    }
  }

  async function signOut() {
    await fetch('/api/inbox/auth', { method: 'DELETE' })
    setAuthenticated(false)
    setEnquiries([])
    setSelectedId(null)
  }

  async function updateEnquiry(changes: Partial<Pick<Enquiry, 'status' | 'internalNotes'>>) {
    if (!selected) return
    setSaving(true)
    setError('')
    try {
      const response = await fetch(`/api/inbox/${selected.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(changes),
      })
      const data = await response.json()
      if (!response.ok) throw new Error(data.error || 'Could not update enquiry.')
      const updated = data.enquiry as Enquiry
      setEnquiries((current) => current.map((item) => item.id === updated.id ? updated : item))
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : 'Could not update enquiry.')
    } finally {
      setSaving(false)
    }
  }

  const counts = statuses.reduce((result, status) => {
    result[status] = enquiries.filter((item) => item.status === status).length
    return result
  }, {} as Record<Enquiry['status'], number>)

  return (
    <main className="relative z-10 mx-auto min-h-[70vh] max-w-7xl px-5 py-12 md:px-8 md:py-16">
      <div className="mb-8 flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="text-xs font-bold uppercase tracking-[0.25em] text-flag-yellow">Private workspace</p>
          <h1 className="mt-2 font-display text-4xl font-extrabold md:text-5xl">Enquiry inbox</h1>
          <p className="mt-2 max-w-xl text-sm text-muted-foreground">Review project briefs, track follow-ups, and keep your conversations in one place.</p>
        </div>
        {authenticated && (
          <div className="flex gap-2">
            <button onClick={() => { setLoading(true); void loadEnquiries() }} className="inline-flex items-center gap-2 rounded-full border border-border bg-card px-4 py-2.5 text-sm font-semibold hover:border-flag-yellow">
              <RefreshCw className="size-4" /> Refresh
            </button>
            <button onClick={() => void signOut()} className="inline-flex items-center gap-2 rounded-full border border-border bg-card px-4 py-2.5 text-sm font-semibold hover:border-flag-yellow">
              <LogOut className="size-4" /> Sign out
            </button>
          </div>
        )}
      </div>

      {!configured ? (
        <section className="rounded-3xl border border-border bg-card p-8">
          <h2 className="font-display text-2xl font-bold">Inbox setup required</h2>
          <p className="mt-3 max-w-2xl text-sm leading-relaxed text-muted-foreground">Set a strong <code>INBOX_ADMIN_PASSWORD</code> (at least 16 characters) and configure <code>DATABASE_URL</code> for the site deployment. Then apply the database migrations to enable saved enquiries.</p>
        </section>
      ) : !authenticated ? hydrated ? (
        <form onSubmit={signIn} className="mx-auto max-w-md rounded-3xl border border-border bg-card p-7 md:p-9">
          <div className="grid size-12 place-items-center rounded-2xl bg-flag-yellow text-charcoal"><Inbox className="size-6" /></div>
          <h2 className="mt-5 font-display text-2xl font-bold">Admin sign in</h2>
          <label htmlFor="inbox-password" className="mt-6 block text-sm text-muted-foreground">Inbox password</label>
          <input id="inbox-password" type="password" autoComplete="current-password" required value={password} onChange={(event) => setPassword(event.target.value)} className="mt-2 w-full rounded-2xl border border-border bg-charcoal px-4 py-3.5 outline-none focus:border-flag-yellow" />
          {error && <p role="alert" className="mt-3 text-sm text-[#ff8a8a]">{error}</p>}
          <button disabled={saving} className="mt-5 w-full rounded-full bg-gradient-to-b from-flag-yellow to-[#f08a1c] px-5 py-3.5 font-semibold text-charcoal disabled:opacity-60">{saving ? 'Signing in...' : 'Open inbox'}</button>
        </form>
      ) : <div aria-hidden="true" className="mx-auto min-h-[280px] max-w-md rounded-3xl border border-border bg-card" /> : (
        <>
          <section className="mb-6 grid grid-cols-2 gap-3 lg:grid-cols-4">
            {statuses.map((status) => (
              <button key={status} onClick={() => setFilter(filter === status ? 'all' : status)} className={`rounded-2xl border p-4 text-left transition-colors ${filter === status ? 'border-flag-yellow bg-flag-yellow/10' : 'border-border bg-card hover:border-flag-yellow/60'}`}>
                <span className="text-sm text-muted-foreground">{statusLabels[status]}</span>
                <span className="mt-1 block font-display text-2xl font-bold">{counts[status]}</span>
              </button>
            ))}
          </section>
          <div className="grid min-h-[540px] gap-5 lg:grid-cols-[0.85fr_1.4fr]">
            <section className="overflow-hidden rounded-3xl border border-border bg-card">
              <div className="border-b border-border p-4">
                <label className="flex items-center gap-2 rounded-xl border border-border bg-charcoal px-3">
                  <Search className="size-4 text-muted-foreground" />
                  <input aria-label="Search enquiries" value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Search enquiries" className="min-w-0 flex-1 bg-transparent py-3 text-sm outline-none placeholder:text-muted-foreground" />
                </label>
                <div className="mt-3 flex items-center justify-between text-xs text-muted-foreground"><span>{filter === 'all' ? 'All enquiries' : statusLabels[filter]}</span><span>{visibleEnquiries.length} shown</span></div>
              </div>
              <div className="max-h-[620px] overflow-y-auto">
                {loading ? <p className="p-6 text-sm text-muted-foreground">Loading enquiries...</p> : visibleEnquiries.length ? visibleEnquiries.map((item) => (
                  <button key={item.id} onClick={() => setSelectedId(item.id)} className={`block w-full border-b border-border p-4 text-left transition-colors hover:bg-charcoal/70 ${selectedId === item.id ? 'bg-charcoal' : ''}`}>
                    <span className="flex items-center justify-between gap-3"><span className="truncate font-semibold">{item.name}</span><span className="shrink-0 rounded-full bg-flag-yellow/10 px-2.5 py-1 text-[11px] font-semibold text-flag-yellow">{statusLabels[item.status]}</span></span>
                    <span className="mt-1 block truncate text-xs text-muted-foreground">{item.services || 'General enquiry'} · {item.contact}</span>
                    <span className="mt-2 block line-clamp-2 text-sm text-muted-foreground">{item.message}</span>
                    <span className="mt-2 flex items-center gap-1.5 text-[11px] text-muted-foreground"><Clock3 className="size-3" />{new Date(item.createdAt).toLocaleString()}</span>
                  </button>
                )) : <p className="p-6 text-sm text-muted-foreground">{enquiries.length ? 'No enquiries match this search.' : 'No saved enquiries yet. New website submissions will appear here once storage is configured.'}</p>}
              </div>
            </section>

            <section className="rounded-3xl border border-border bg-card p-5 md:p-7">
              {selected ? (() => {
                const links = contactLinks(selected)
                return <>
                  <div className="flex flex-wrap items-start justify-between gap-4 border-b border-border pb-5">
                    <div><p className="text-xs font-bold uppercase tracking-[0.2em] text-flag-yellow">Project enquiry</p><h2 className="mt-2 font-display text-3xl font-bold">{selected.name}</h2><p className="mt-1 text-sm text-muted-foreground">Received {new Date(selected.createdAt).toLocaleString()}</p></div>
                    <select aria-label="Enquiry status" value={selected.status} onChange={(event) => void updateEnquiry({ status: event.target.value as Enquiry['status'] })} disabled={saving} className="rounded-full border border-border bg-charcoal px-4 py-2.5 text-sm font-semibold outline-none focus:border-flag-yellow">
                      {statuses.map((status) => <option key={status} value={status}>{statusLabels[status]}</option>)}
                    </select>
                  </div>
                  <div className="grid gap-4 py-5 sm:grid-cols-2">
                    <div><p className="text-xs uppercase tracking-widest text-muted-foreground">Contact</p><p className="mt-1 break-all font-semibold">{selected.contact}</p></div>
                    <div><p className="text-xs uppercase tracking-widest text-muted-foreground">Deadline</p><p className="mt-1 font-semibold">{selected.deadline}</p></div>
                    <div className="sm:col-span-2"><p className="text-xs uppercase tracking-widest text-muted-foreground">Services</p><p className="mt-1 font-semibold">{selected.services || 'Not specified'}</p></div>
                  </div>
                  <div className="rounded-2xl bg-charcoal p-5"><p className="mb-2 text-xs font-semibold uppercase tracking-widest text-muted-foreground">Project brief</p><p className="whitespace-pre-wrap break-words text-sm leading-relaxed">{selected.message}</p></div>
                  <div className="mt-5 flex flex-wrap gap-2">
                    {links.email && <a href={links.email} className="inline-flex items-center gap-2 rounded-full border border-border px-4 py-2.5 text-sm font-semibold hover:border-flag-yellow"><Mail className="size-4" /> Reply by email</a>}
                    {links.whatsapp && <a href={links.whatsapp} target="_blank" rel="noreferrer" className="inline-flex items-center gap-2 rounded-full border border-border px-4 py-2.5 text-sm font-semibold hover:border-flag-yellow"><MessageCircle className="size-4" /> Follow up on WhatsApp</a>}
                  </div>
                  <div className="mt-6 border-t border-border pt-5">
                    <label htmlFor="internal-notes" className="text-sm font-semibold">Internal notes</label>
                    <textarea id="internal-notes" value={notes} onChange={(event) => setNotes(event.target.value)} rows={4} maxLength={5000} placeholder="Keep private project details or follow-up reminders here..." className="mt-2 w-full resize-y rounded-2xl border border-border bg-charcoal px-4 py-3 text-sm outline-none focus:border-flag-yellow" />
                    <div className="mt-2 flex flex-wrap items-center justify-between gap-3"><span className="text-xs text-muted-foreground">Only visible in this protected inbox.</span><button disabled={saving || notes === selected.internalNotes} onClick={() => void updateEnquiry({ internalNotes: notes })} className="inline-flex items-center gap-2 rounded-full bg-flag-yellow px-4 py-2.5 text-sm font-semibold text-charcoal disabled:opacity-50"><Save className="size-4" /> Save notes</button></div>
                  </div>
                  <div className="mt-5 flex flex-wrap gap-4 text-xs text-muted-foreground">
                    <span className="inline-flex items-center gap-1.5"><Check className="size-3.5" /> Owner email {selected.adminNotifiedAt ? 'sent' : 'not recorded'}</span>
                    <span className="inline-flex items-center gap-1.5"><Check className="size-3.5" /> Client confirmation {selected.confirmationSentAt ? 'sent' : 'not recorded'}</span>
                  </div>
                </>
              })() : <div className="grid min-h-[400px] place-items-center text-center"><div><Inbox className="mx-auto size-9 text-muted-foreground" /><p className="mt-3 font-semibold">Select an enquiry to review</p></div></div>}
              {error && <p role="alert" className="mt-4 rounded-xl border border-[#ff8a8a]/30 bg-[#ff8a8a]/5 p-3 text-sm text-[#ff8a8a]">{error}</p>}
            </section>
          </div>
        </>
      )}
    </main>
  )
}
