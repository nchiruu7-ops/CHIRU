import type { Metadata } from 'next'
import { HeritageDivider } from '@/components/heritage-frame'
import { PageHero } from '@/components/page-hero'
import { ProjectGallery } from '@/components/project-gallery'
import { projects } from '@/lib/projects'

export const metadata: Metadata = {
  title: 'Portfolio',
  description:
    'AI videos, motion graphics, 3D animation, brand identity, promotional reels, posters and print design by CHIRU.',
}

export default function PortfolioPage() {
  return (
    <>
      <PageHero
        eyebrow="Portfolio"
        title="Work that"
        accent="moves people"
        text="Filter by category and open any project to see what it is and which software went into it."
      />
      <section className="relative z-10 mx-auto max-w-7xl px-5 md:px-8">
        <HeritageDivider className="mb-12" />
        <ProjectGallery projects={projects} />
      </section>
    </>
  )
}
