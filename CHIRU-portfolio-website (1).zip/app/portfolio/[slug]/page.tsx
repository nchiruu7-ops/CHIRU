import { ArrowLeft, ArrowRight, Check } from 'lucide-react'
import type { Metadata } from 'next'
import Link from 'next/link'
import { notFound } from 'next/navigation'
import { VideoEmbed } from '@/components/video-embed'
import { getProject, projects } from '@/lib/projects'

export function generateStaticParams() {
  return projects.map((p) => ({ slug: p.slug }))
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>
}): Promise<Metadata> {
  const { slug } = await params
  const project = getProject(slug)
  if (!project) return { title: 'Project not found' }
  return { title: project.title, description: project.summary }
}

export default async function ProjectPage({
  params,
}: {
  params: Promise<{ slug: string }>
}) {
  const { slug } = await params
  const project = getProject(slug)
  if (!project) notFound()

  return (
    <section className="relative z-10 mx-auto max-w-7xl px-5 pb-24 pt-32 md:px-8 md:pt-44">
      <Link
        href="/portfolio"
        className="group mb-8 inline-flex items-center gap-2 text-sm font-semibold text-muted-foreground transition-colors hover:text-flag-yellow"
      >
        <ArrowLeft className="size-4 transition-transform group-hover:-translate-x-1" />
        Back to portfolio
      </Link>

      <div className="grid gap-10 lg:grid-cols-[minmax(0,1fr)_minmax(0,1fr)] lg:gap-14">
        <div>
          <VideoEmbed
            url={project.videoUrl}
            title={project.title}
            poster={project.posterSrc}
            sceneVariant={project.sceneVariant}
          />
        </div>

        <div>
          <span className="inline-flex rounded-full bg-flag-yellow px-3 py-1 text-xs font-semibold text-charcoal">
            {project.category}
          </span>
          <h1 className="mt-5 font-display text-4xl font-extrabold leading-tight text-balance md:text-5xl">
            {project.title}
          </h1>
          <p className="mt-4 text-lg leading-relaxed text-muted-foreground">{project.summary}</p>

          <dl className="mt-8 grid grid-cols-2 gap-4 rounded-3xl border border-border bg-card p-6 text-sm">
            <div>
              <dt className="text-muted-foreground">Client</dt>
              <dd className="mt-1 font-semibold">{project.client}</dd>
            </div>
            <div>
              <dt className="text-muted-foreground">Year</dt>
              <dd className="mt-1 font-semibold">{project.year}</dd>
            </div>
          </dl>

          <h2 className="mt-10 font-display text-xl font-bold">The brief</h2>
          <p className="mt-3 leading-relaxed text-muted-foreground">{project.brief}</p>

          <h2 className="mt-10 font-display text-xl font-bold">How it was made</h2>
          <ol className="mt-4 space-y-3">
            {project.process.map((step) => (
              <li key={step} className="flex items-start gap-3 text-sm leading-relaxed">
                <span className="mt-0.5 flex size-5 shrink-0 items-center justify-center rounded-full bg-flag-yellow text-charcoal">
                  <Check className="size-3" strokeWidth={3} />
                </span>
                {step}
              </li>
            ))}
          </ol>

          <p className="mt-10 text-xs font-semibold uppercase tracking-widest text-muted-foreground">
            Software used
          </p>
          <ul className="mt-3 flex flex-wrap gap-2">
            {project.software.map((s) => (
              <li key={s} className="rounded-full border border-border bg-card px-3 py-1 text-sm">
                {s}
              </li>
            ))}
          </ul>
        </div>
      </div>

      <div className="mt-20 flex flex-col items-start justify-between gap-6 rounded-[2rem] bg-gradient-to-b from-flag-yellow to-flag-red p-8 text-charcoal md:flex-row md:items-center md:p-12">
        <div>
          <p className="font-display text-2xl font-extrabold md:text-3xl">{project.cta}</p>
          <p className="mt-2 text-sm font-medium text-charcoal/80">
            Tell me about your brief and I will reply to you with next steps.
          </p>
        </div>
        <Link
          href={`/contact?project=${project.slug}`}
          className="group inline-flex items-center gap-2 rounded-full bg-charcoal px-7 py-4 font-semibold text-white transition-transform hover:-translate-y-0.5"
        >
          Start this project
          <ArrowRight className="size-4 transition-transform group-hover:translate-x-1" />
        </Link>
      </div>
    </section>
  )
}
