import { Mail } from 'lucide-react'
import type { Metadata } from 'next'
import { ContactForm } from '@/components/contact-form'
import { HeritageDivider } from '@/components/heritage-frame'
import { PageHero } from '@/components/page-hero'
import { getProject } from '@/lib/projects'
import { site } from '@/lib/site'

export const metadata: Metadata = {
  title: 'Contact',
  description: 'Get in touch with CHIRU for AI content, motion graphics, printing, DTP and design work.',
}

export default async function ContactPage({
  searchParams,
}: {
  searchParams: Promise<{ project?: string; service?: string }>
}) {
  const { project: slug, service } = await searchParams
  const project = slug ? getProject(slug) : undefined

  return (
    <>
      <PageHero
        eyebrow="Contact"
        title="Let's make"
        accent="something great"
        text="Send a brief for printing, design, DTP or AI content and I'll get back to you."
      />
      <div className="relative z-10 mx-auto max-w-7xl px-5 md:px-8">
        <HeritageDivider className="mb-12" />
      </div>
      <div className="relative z-10 mx-auto grid max-w-7xl gap-10 px-5 md:px-8 lg:grid-cols-[1.3fr_1fr]">
        <ContactForm initialProject={project ? { title: project.title } : undefined} initialService={service} />
        <aside className="space-y-8">
          <div className="rounded-3xl border border-border bg-card p-8">
            <Mail className="size-8 text-flag-yellow" />
            <p className="mt-4 text-sm text-muted-foreground">Email</p>
            <a
              href={`mailto:${site.email}`}
              className="break-all font-display text-xl font-bold transition-colors hover:text-flag-yellow"
            >
              {site.email}
            </a>
          </div>
          <div>
            <h2 className="mb-4 font-display text-xl font-bold">Hello, and welcome!</h2>
            <ul className="flex flex-wrap gap-3">
              <li>
                <a
                  href={`mailto:${site.email}`}
                  className="group inline-flex items-center gap-2.5 rounded-full border border-border bg-card px-5 py-3 text-sm font-medium transition-all hover:-translate-y-0.5 hover:border-flag-yellow hover:text-flag-yellow"
                >
                  <Mail className="size-4" />
                  Welcome! Let’s bring your ideas to life with stunning AI visuals and motion graphics. Get in touch, and let’s create something extraordinary.
                </a>
              </li>
            </ul>
          </div>
        </aside>
      </div>
    </>
  )
}
