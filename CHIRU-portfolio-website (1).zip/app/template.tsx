export default function Template({ children }: { children: React.ReactNode }) {
  return (
    <>
      <div aria-hidden="true" className="route-curtain" />
      <main className="animate-in fade-in slide-in-from-bottom-3 duration-500">
        {children}
      </main>
    </>
  )
}
