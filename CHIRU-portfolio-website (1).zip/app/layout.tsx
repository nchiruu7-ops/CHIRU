import { AnalyticsConsent } from '@/components/analytics-consent'
import type { Metadata, Viewport } from 'next'
import { Bricolage_Grotesque, DM_Sans, Noto_Sans_Kannada } from 'next/font/google'
import { CursorGlow } from '@/components/cursor-glow'
import { SiteFooter } from '@/components/site-footer'
import { SiteHeader } from '@/components/site-header'
import { site } from '@/lib/site'
import './globals.css'

const bricolage = Bricolage_Grotesque({
  subsets: ['latin'],
  variable: '--font-bricolage',
  display: 'swap',
})
const dmSans = DM_Sans({
  subsets: ['latin'],
  variable: '--font-dm-sans',
  display: 'swap',
})
const notoKannada = Noto_Sans_Kannada({
  subsets: ['kannada'],
  weight: ['700', '800'],
  variable: '--font-noto-kannada',
  display: 'swap',
})

export const metadata: Metadata = {
  title: {
    default: `${site.name} | AI Content Creator, Motion Graphics & Print Design`,
    template: `%s | ${site.name}`,
  },
  description: site.description,
  keywords: [
    'AI content creator',
    'motion graphics designer',
    'online printing',
    'DTP services',
    'brand identity',
    'Karnataka',
    'Chiru',
    'AI animation',
  ],
  authors: [{ name: site.fullName }],
  openGraph: {
    title: `${site.name} | ${site.role}`,
    description: site.description,
    type: 'website',
  },
}

export const viewport: Viewport = {
  colorScheme: 'dark',
  themeColor: '#121214',
  width: 'device-width',
  initialScale: 1,
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html
      lang="en"
      data-scroll-behavior="smooth"
      className={`${bricolage.variable} ${dmSans.variable} ${notoKannada.variable}`}
    >
      <body>
        <a
          href="#main"
          className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-[100] focus:rounded-full focus:bg-flag-yellow focus:px-4 focus:py-2 focus:text-charcoal"
        >
          Skip to content
        </a>
        <CursorGlow />
        <SiteHeader />
        <div id="main">{children}</div>
        <SiteFooter />
        <AnalyticsConsent />
      </body>
    </html>
  )
}
