import type { Metadata } from 'next'
import { OfferShowcase } from '@/components/offer-showcase'

export const metadata: Metadata = {
  title: 'Brand Strategy',
  description: 'Audience, positioning, message and a practical visual direction for creative work.',
}

export default function BrandStrategyPage() {
  return <OfferShowcase kind="strategy" />
}
