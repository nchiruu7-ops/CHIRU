import type { Metadata } from 'next'
import { PrivacyChoicesButton } from '@/components/analytics-consent'
import { PageHero } from '@/components/page-hero'

export const metadata: Metadata = {
  title: 'Cookie and Analytics Choices',
  description: 'Details about local storage, optional analytics and click-to-load media.',
}

export default function CookiesPage() {
  return (
    <>
      <PageHero eyebrow="Privacy choices" title="You choose what" accent="loads here." text="Optional site analytics are off until you opt in. You can change that choice whenever you like." />
      <main className="relative z-10 mx-auto max-w-4xl space-y-5 px-5 pb-24 md:px-8">
        <section className="rounded-3xl border border-border bg-card p-6 md:p-8">
          <h2 className="font-display text-xl font-bold">Essential browser storage</h2>
          <p className="mt-3 leading-relaxed text-muted-foreground">The site stores your analytics choice in local storage so it can remember whether you accepted or declined. This preference is needed to honour your choice; it does not enable analytics by itself.</p>
        </section>
        <section className="rounded-3xl border border-border bg-card p-6 md:p-8">
          <h2 className="font-display text-xl font-bold">Optional analytics</h2>
          <p className="mt-3 leading-relaxed text-muted-foreground">If you opt in, Vercel Analytics loads to measure aggregate site usage. Declining keeps that component disabled in this browser. Your choice can be changed at any time.</p>
        </section>
        <section className="rounded-3xl border border-border bg-card p-6 md:p-8">
          <h2 className="font-display text-xl font-bold">Embedded media</h2>
          <p className="mt-3 leading-relaxed text-muted-foreground">Instagram and YouTube embeds are click-to-load. Choosing to play one connects your browser to that platform, which may receive technical information under its own privacy terms.</p>
        </section>
        <PrivacyChoicesButton />
      </main>
    </>
  )
}
