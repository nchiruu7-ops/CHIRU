import type { Metadata } from 'next'
import Link from 'next/link'
import { PageHero } from '@/components/page-hero'

export const metadata: Metadata = {
  title: 'Website Terms',
  description: 'Terms for using the CHIRU portfolio and submitting project enquiries.',
}

const terms = [
  {
    title: 'Portfolio and concept work',
    text: 'Project images, motion studies and generated scenes are shown to illustrate creative direction. A concept sample is not a claim of commissioned client work, a guaranteed result or an endorsement by a named client. Rights to third-party marks and assets remain with their respective owners.',
  },
  {
    title: 'Enquiries and project agreements',
    text: 'Submitting the contact form starts a conversation and does not itself create a booking or contract. Scope, deliverables, schedule, fees, revisions, production specifications, delivery and ownership or usage rights must be agreed in a written proposal before work begins.',
  },
  {
    title: 'Print and digital proofs',
    text: 'Where a project involves print, the customer should review and approve the final proof, spelling, dimensions, quantity, colours and delivery details before production. Display colour may differ from printed output. Any project-specific tolerances or remedies should be stated in the accepted quotation.',
  },
  {
    title: 'Use of this site',
    text: 'You may browse the site and use the contact form for genuine project enquiries. Do not attempt to disrupt the site, submit unlawful material or use portfolio content in a way that infringes another person’s rights.',
  },
  {
    title: 'External services and changes',
    text: 'Optional embedded media and site analytics are provided by third parties when enabled by your choices. Site information may change; project-specific written terms control the work once accepted.',
  },
]

export default function TermsPage() {
  return (
    <>
      <PageHero eyebrow="Legal" title="Clear terms for" accent="creative work." text="These website terms cover browsing the portfolio and sending an enquiry. Each commissioned project still needs its own accepted written scope and quotation." />
      <main className="relative z-10 mx-auto max-w-4xl space-y-5 px-5 pb-24 md:px-8">
        {terms.map((section) => (
          <section key={section.title} className="rounded-3xl border border-border bg-card p-6 md:p-8">
            <h2 className="font-display text-xl font-bold">{section.title}</h2>
            <p className="mt-3 leading-relaxed text-muted-foreground">{section.text}</p>
          </section>
        ))}
        <p className="text-sm text-muted-foreground">Questions about a project? <Link href="/contact" className="text-flag-yellow underline">Start an enquiry</Link>.</p>
      </main>
    </>
  )
}
