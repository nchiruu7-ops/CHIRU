import type { Metadata } from 'next'
import { PageHero } from '@/components/page-hero'
import { PortraitReveal } from '@/components/portrait-reveal'
import { Reveal } from '@/components/reveal'
import { SocialLinks } from '@/components/social-links'
import { education, experience, site, skills, teamWork, tools } from '@/lib/site'

export const metadata: Metadata = {
  title: 'About',
  description:
    'About CHIRU: AI content creator and motion graphics designer with a printing technology background.',
}

export default function AboutPage() {
  return (
    <>
      <PageHero
        eyebrow="About"
        title="Hi, I'm"
        accent={site.fullName}
        text="An AI content creator and motion graphics designer who understands both screens and printing presses. I turn ideas into visuals that look great everywhere."
      />

      <section className="relative z-10 mx-auto mb-16 grid max-w-7xl items-center gap-10 px-5 md:px-8 lg:grid-cols-[minmax(0,360px)_1fr] lg:gap-16">
        <PortraitReveal className="mx-auto w-full max-w-sm lg:mx-0" />
        <Reveal>
          <h2 className="font-display text-3xl font-extrabold md:text-5xl">
            The creator behind <span className="text-flag-gradient">the work</span>
          </h2>
          <p className="mt-5 text-lg leading-relaxed text-muted-foreground">
            I&apos;m an {teamWork.role.toLowerCase()} on animated YouTube channels, and I run my
            own online printing, DTP and design services. Screens and print share one visual
            language, so everything I deliver feels consistent.
          </p>
          <p className="mt-4 leading-relaxed text-muted-foreground">
            Team projects are credited to the team, so I only link the public channels and one
            published reel.
          </p>
        </Reveal>
      </section>

      <div className="relative z-10 mx-auto grid max-w-7xl gap-6 px-5 md:grid-cols-2 md:px-8">
        <Reveal>
          <section className="h-full rounded-3xl border border-border bg-card p-8">
            <h2 className="font-display text-2xl font-bold text-flag-yellow">Skills</h2>
            <ul className="mt-5 space-y-3">
              {skills.map((s) => (
                <li key={s} className="flex gap-3">
                  <span className="mt-2 size-2 shrink-0 rotate-45 bg-flag-red" />
                  {s}
                </li>
              ))}
            </ul>
          </section>
        </Reveal>
        <Reveal delay={100}>
          <section className="h-full rounded-3xl border border-border bg-card p-8">
            <h2 className="font-display text-2xl font-bold text-flag-yellow">Tools</h2>
            <ul className="mt-5 flex flex-wrap gap-2">
              {tools.map((t) => (
                <li
                  key={t}
                  className="rounded-full border border-border bg-charcoal px-4 py-2 text-sm transition-colors hover:border-flag-yellow"
                >
                  {t}
                </li>
              ))}
            </ul>
          </section>
        </Reveal>
        <Reveal>
          <section className="h-full rounded-3xl border border-border bg-card p-8">
            <h2 className="font-display text-2xl font-bold text-flag-yellow">Education</h2>
            <ol className="mt-5 space-y-6 border-l border-border pl-6">
              {education.map((e) => (
                <li key={e.title} className="relative">
                  <span className="absolute -left-[31px] top-1.5 size-3 rounded-full bg-flag-yellow ring-4 ring-card" />
                  <p className="font-display text-lg font-bold">{e.title}</p>
                  {e.place && <p className="text-sm text-muted-foreground">{e.place}</p>}
                  <p className="text-sm text-flag-yellow">
                    {e.year}
                    {e.note && ` · ${e.note}`}
                  </p>
                </li>
              ))}
            </ol>
          </section>
        </Reveal>
        <Reveal delay={100}>
          <section className="h-full rounded-3xl border border-border bg-card p-8">
            <h2 className="font-display text-2xl font-bold text-flag-yellow">Experience</h2>
            <ul className="mt-5 space-y-3">
              {experience.map((x) => (
                <li key={x} className="flex gap-3">
                  <span className="mt-2 size-2 shrink-0 rotate-45 bg-flag-yellow" />
                  {x}
                </li>
              ))}
            </ul>
          </section>
        </Reveal>
      </div>

      <section className="relative z-10 mx-auto mt-16 max-w-7xl px-5 md:px-8">
        <h2 className="mb-5 font-display text-2xl font-bold">Find me online</h2>
        <SocialLinks />
      </section>
    </>
  )
}
