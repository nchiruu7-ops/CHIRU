CREATE TABLE "enquiries" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"name" text NOT NULL,
	"contact" text NOT NULL,
	"message" text NOT NULL,
	"services" text NOT NULL,
	"deadline" text NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
