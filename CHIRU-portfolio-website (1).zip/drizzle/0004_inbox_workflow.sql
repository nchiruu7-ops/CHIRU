ALTER TABLE "enquiries" ADD COLUMN "status" text DEFAULT 'new' NOT NULL;
ALTER TABLE "enquiries" ADD COLUMN "internal_notes" text DEFAULT '' NOT NULL;
